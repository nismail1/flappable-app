import { useState, useEffect, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Sparkles,
  FileText,
  LayoutDashboard,
  LogOut,
  Settings as SettingsIcon,
  Share2,
  Copy,
  Check,
  ArrowLeft,
  Phone,
  AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { supabaseFrom } from "@/lib/supabase-helper";
import Vapi from "@vapi-ai/web";
import type { User, Session } from "@supabase/supabase-js";
import { applyPatch } from "fast-json-patch";
import { ChatPanel } from "@/components/ChatPanel";
import { PreviewPanel } from "@/components/PreviewPanel";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useNavigation } from "@/contexts/NavigationContext";
import { saveDraft, loadDraft, clearDraft, backupDraftToSession, loadDraftFromEither, clearSessionDraft } from "@/lib/draft-manager";
import { TrialModeBanner } from "@/components/TrialModeBanner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";

const Index = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { getBackLabel, shouldShowBack } = useNavigation();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [brief, setBrief] = useState("");
  const [voiceAgent, setVoiceAgent] = useState<any>(null);
  const [deployedAgentId, setDeployedAgentId] = useState<string | null>(null);
  const [callStatus, setCallStatus] = useState<"idle" | "connecting" | "connected" | "muted" | "ended" | "failed">(
    "idle",
  );
  const [isMuted, setIsMuted] = useState(false);
  const [vapiInstance, setVapiInstance] = useState<any>(null);
  const [loadedAgentId, setLoadedAgentId] = useState<string | null>(null);
  const [isIterating, setIsIterating] = useState(false);
  const [iterationHistory, setIterationHistory] = useState<
    Array<{
      type: "user" | "system";
      content: string;
      timestamp: Date;
    }>
  >([]);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [showPublishDialog, setShowPublishDialog] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [isPublishing, setIsPublishing] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [agentLogoUrl, setAgentLogoUrl] = useState<string | null>(null);
  const [publishPhoneNumber, setPublishPhoneNumber] = useState<string | null>(null);
  const [assigningPublishPhone, setAssigningPublishPhone] = useState(false);
  const [unassigningPublishPhone, setUnassigningPublishPhone] = useState(false);
  const [showLogoAnimation, setShowLogoAnimation] = useState(false);
  const [callTranscript, setCallTranscript] = useState<Array<{ role: string; content: string }>>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [initialPrompt, setInitialPrompt] = useState<string | undefined>(undefined);
  const [initialIterationInput, setInitialIterationInput] = useState("");
  const [currentUserPrompt, setCurrentUserPrompt] = useState("");
  const [draftRestored, setDraftRestored] = useState(false);
  const [showAuthPromptDialog, setShowAuthPromptDialog] = useState(false);
  const [isMigrating, setIsMigrating] = useState(false);

  useEffect(() => {
    // Set up auth state listener FIRST
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);

      // Check for draft restoration and migration after authentication
      if (session?.user && event === "SIGNED_IN") {
        const draft = loadDraftFromEither();
        
        console.log("🔍 SIGNED_IN event fired", { 
          userId: session.user.id,
          hasDraft: !!draft, 
          hasVoiceAgent: !!draft?.voiceAgent, 
          hasDeployedId: !!draft?.deployedAgentId,
          draftSource: loadDraft() ? 'localStorage' : 'sessionStorage'
        });

        if (draft && draft.voiceAgent && draft.deployedAgentId) {
          // User just signed up with a trial agent - migrate it to database
          console.log("🚀 Starting trial agent migration...", {
            agentName: draft.voiceAgent.name,
            deployedId: draft.deployedAgentId,
            hasIterationHistory: !!draft.iterationHistory?.length
          });

          // Execute migration immediately (no setTimeout)
          (async () => {
            try {
              // Check if migration is already in progress
              if (isMigrating) {
                console.log("⏭️ Migration already in progress, skipping");
                return;
              }

              // Check if agent already exists in database
              const { data: existingAgent } = await supabaseFrom("voice_agent_versions")
                .select("id")
                .eq("vapi_agent_id", draft.deployedAgentId)
                .maybeSingle();

              if (existingAgent) {
                console.log("✅ Agent already migrated, using existing record");
                setLoadedAgentId(existingAgent.id);
                
                // Restore UI state
                setVoiceAgent(draft.voiceAgent);
                setBrief(draft.userPrompt || "");
                setAgentLogoUrl(draft.agentLogoUrl || null);
                setDeployedAgentId(draft.deployedAgentId);
                setInitialPrompt(draft.userPrompt);
                setCurrentUserPrompt(draft.userPrompt);
                setInitialIterationInput(draft.iterationInput || "");
                
                if (draft.iterationHistory && draft.iterationHistory.length > 0) {
                  const restoredHistory = draft.iterationHistory.map((msg) => ({
                    ...msg,
                    timestamp: new Date(msg.timestamp),
                  }));
                  setIterationHistory(restoredHistory);
                }
                
                setDraftRestored(true);
                clearDraft();
                clearSessionDraft();
                toast.success("Your agent has been restored!");
                return;
              }

              // Set migration flag
              setIsMigrating(true);
              console.log("🚀 Starting new agent migration...");

              const agentData = {
                user_id: session.user.id,
                vapi_agent_id: draft.deployedAgentId,
                version: draft.voiceAgent.version,
                agent_config: draft.voiceAgent,
                prompt: draft.userPrompt,
                logo_url: draft.agentLogoUrl,
              };

              console.log("💾 Saving agent to database...");
              const { data: savedAgent, error } = await supabaseFrom("voice_agent_versions")
                .insert(agentData)
                .select()
                .single();

              if (error) {
                console.error("❌ Error migrating trial agent:", error);
                
                // Handle duplicate key error gracefully
                if (error.message?.includes('duplicate key') || error.message?.includes('vapi_agent_id')) {
                  console.log("⚠️ Duplicate key error, loading existing agent");
                  const { data: existing } = await supabaseFrom("voice_agent_versions")
                    .select("*")
                    .eq("vapi_agent_id", draft.deployedAgentId)
                    .single();
                  
                  if (existing) {
                    setLoadedAgentId(existing.id);
                    setVoiceAgent(draft.voiceAgent);
                    setBrief(draft.userPrompt || "");
                    setAgentLogoUrl(draft.agentLogoUrl || null);
                    setDeployedAgentId(draft.deployedAgentId);
                    setDraftRestored(true);
                    clearDraft();
                    clearSessionDraft();
                    toast.success("Your agent has been restored!");
                    return;
                  }
                }
                
                toast.error("Failed to save your agent");
                return;
              }

              console.log("✅ Trial agent migrated to database, ID:", savedAgent.id);

              // Set loadedAgentId FIRST before any other state updates
              setLoadedAgentId(savedAgent.id);
              console.log("✅ loadedAgentId set to:", savedAgent.id);

              // Directly set UI state from saved agent and draft data
              setVoiceAgent(draft.voiceAgent);
              setBrief(draft.userPrompt || "");
              setAgentLogoUrl(draft.agentLogoUrl || null);
              setDeployedAgentId(draft.deployedAgentId);
              setInitialPrompt(draft.userPrompt);
              setCurrentUserPrompt(draft.userPrompt);
              setInitialIterationInput(draft.iterationInput || "");
              console.log("✅ All UI state set directly from draft");

              // Restore iteration history
              if (draft.iterationHistory && draft.iterationHistory.length > 0) {
                const restoredHistory = draft.iterationHistory.map((msg) => ({
                  ...msg,
                  timestamp: new Date(msg.timestamp),
                }));
                setIterationHistory(restoredHistory);
                console.log("✅ Iteration history restored:", restoredHistory.length, "messages");

                // Save conversation history to database
                const { error: convError } = await supabaseFrom("agent_conversations")
                  .insert({
                    user_id: session.user.id,
                    agent_id: savedAgent.id,
                    messages: draft.iterationHistory,
                  });

                if (convError) {
                  console.error("⚠️ Error saving conversation history:", convError);
                } else {
                  console.log("✅ Conversation history saved to database");
                }
              }

              // Mark draft as restored
              setDraftRestored(true);

              // Clear drafts from both storages AFTER all state is set
              clearDraft();
              clearSessionDraft();
              console.log("✅ Drafts cleared from storage");

              console.log("🎉 Migration complete! UI should show agent immediately");
              toast.success("Your agent has been saved to your account!");
            } catch (error) {
              console.error("❌ Error during agent migration:", error);
              toast.error("Failed to migrate your agent");
            } finally {
              setIsMigrating(false);
            }
          })();
        } else if (sessionStorage.getItem("shouldRestoreDraft") && draft) {
          // Just restoring a draft without migration
          requestAnimationFrame(() => {
            restoreDraft();
            sessionStorage.removeItem("shouldRestoreDraft");
            console.log("✅ Draft restored from flag");
          });
        } else {
          console.log("ℹ️ No trial agent to migrate");
        }
      }
    });

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Restore draft from localStorage
  const restoreDraft = useCallback(() => {
    const draft = loadDraft();
    if (!draft) {
      console.log("❌ No draft found to restore");
      return;
    }

    console.log("📦 Draft loaded:", {
      userPrompt: draft.userPrompt,
      hasVoiceAgent: !!draft.voiceAgent,
      hasBrief: !!draft.brief,
      hasLogo: !!draft.agentLogoUrl,
      hasDeployedId: !!draft.deployedAgentId,
    });

    // Only restore if user doesn't have a loaded agent (don't overwrite existing work)
    if (loadedAgentId) {
      console.log("Skipping draft restoration - user has loaded agent");
      return;
    }

    console.log("🔄 Restoring draft from localStorage");

    // Restore basic state
    console.log("📝 Setting initialPrompt to:", draft.userPrompt);
    setInitialPrompt(draft.userPrompt);
    setCurrentUserPrompt(draft.userPrompt);
    setInitialIterationInput(draft.iterationInput || "");

    console.log("✅ State updated - initialPrompt should now be:", draft.userPrompt);

    // Restore voice agent config
    if (draft.voiceAgent) {
      setVoiceAgent(draft.voiceAgent);
    }

    // Restore brief
    if (draft.brief) {
      setBrief(draft.brief);
    }

    // Restore logo
    if (draft.agentLogoUrl) {
      setAgentLogoUrl(draft.agentLogoUrl);
    }

    // Restore deployed agent ID
    if (draft.deployedAgentId) {
      setDeployedAgentId(draft.deployedAgentId);
    }

    // Restore iteration history - convert timestamp strings back to Date objects
    if (draft.iterationHistory && draft.iterationHistory.length > 0) {
      const restoredHistory = draft.iterationHistory.map((msg) => ({
        ...msg,
        timestamp: new Date(msg.timestamp),
      }));
      setIterationHistory(restoredHistory);
    }

    // Mark draft as restored
    setDraftRestored(true);

    console.log("🎉 Draft restoration complete. Final state:", {
      initialPrompt: draft.userPrompt,
      currentUserPrompt: draft.userPrompt,
    });

    // Show success toast
    toast.success("✅ Restored your previous session — continue where you left off!");
  }, [loadedAgentId]);

  // Separate effect to handle draft restoration on page load (after redirect from auth)
  useEffect(() => {
    // Only run if we have a user and haven't restored yet
    if (!user || draftRestored) return;

    // Check if we should restore the draft
    if (sessionStorage.getItem("shouldRestoreDraft")) {
      const draft = loadDraft();
      if (draft) {
        setTimeout(() => {
          restoreDraft();
          sessionStorage.removeItem("shouldRestoreDraft");
          console.log("✅ Draft restored after page load");
        }, 100);
      }
    }
  }, [user, draftRestored, restoreDraft]);

  // Clear draft after successful restoration and UI render
  useEffect(() => {
    if (!draftRestored || !user) return;

    // Clear only after everything is rendered
    requestAnimationFrame(() => {
      clearDraft();
      sessionStorage.removeItem("shadow-draft");
      sessionStorage.removeItem("shouldRestoreDraft");
      console.log("Draft cleared (final)");
    });
  }, [draftRestored, user]);

  // Load preloaded agent data if navigating from dashboard
  useEffect(() => {
    const loadAgentAndConversation = async () => {
      if (!user?.id) {
        console.log("User not loaded yet, skipping conversation load");
        return;
      }

      const agentData = location.state?.agentData;
      if (agentData && agentData.agent_config) {
        console.log("Loading agent from dashboard:", agentData.id);
        const config = agentData.agent_config;
        setVoiceAgent({
          id: agentData.id,
          name: config.name || "Untitled Agent",
          version: agentData.version || "v1.0",
          tone: config.tone,
          accent: config.accent,
          gender: config.gender,
          warmth: config.warmth,
          creativity: config.creativity,
          latency: config.latency,
          personality: config.personality,
          sampleLine: config.sampleLine,
          vapi_agent_id: agentData.vapi_agent_id,
        });
        if (agentData.prompt) {
          setBrief(agentData.prompt);
        }
        if (agentData.vapi_agent_id) {
          setDeployedAgentId(agentData.vapi_agent_id);
        }
        if (agentData.logo_url) {
          setAgentLogoUrl(agentData.logo_url);
        }
        if (agentData.id) {
          setLoadedAgentId(agentData.id);

          // Load conversation history for this agent
          console.log("Querying conversations for agent:", agentData.id, "user:", user.id);
          const { data: conversations, error } = await supabaseFrom("agent_conversations")
            .select("*")
            .eq("agent_id", agentData.id)
            .eq("user_id", user.id)
            .order("created_at", { ascending: false })
            .limit(1);

          console.log("Conversation query result:", { conversations, error });

          if (!error && conversations && conversations.length > 0) {
            const conversation = conversations[0];
            console.log("Found existing conversation:", conversation);
            setConversationId(conversation.id);

            // Parse messages and convert timestamp strings back to Date objects
            const messages = (conversation.messages || []).map((msg: any) => ({
              ...msg,
              timestamp: new Date(msg.timestamp),
            }));
            console.log("Loaded messages:", messages.length);
            setIterationHistory(messages);
          } else {
            console.log("No conversation found, creating new one");
            // Create new conversation for this agent
            const { data: newConversation, error: createError } = await supabaseFrom("agent_conversations")
              .insert({
                agent_id: agentData.id,
                user_id: user.id,
                messages: [],
              })
              .select()
              .single();

            console.log("Created new conversation:", { newConversation, createError });

            if (!createError && newConversation) {
              setConversationId(newConversation.id);
            }
          }
        }
        toast.success("Agent loaded from dashboard");
      }
    };

    loadAgentAndConversation();
  }, [location.state, user?.id]);

  const handleGoToDashboard = () => {
    navigate("/dashboard");
  };

  const handleGoToSettings = () => {
    navigate("/settings");
  };

  const handleCreateAgent = async (userPrompt: string) => {
    if (!userPrompt.trim()) {
      toast.error("Please describe your voice agent");
      return;
    }

    setIsGenerating(true);
    try {
      // Step 1: Generate brief with AI
      const messages = [
        {
          role: "assistant",
          content:
            "Hi! I'm here to help you design your voice agent. Tell me about what you want to create—what's the vibe, who's it for, and what should it do?",
        },
        { role: "user", content: userPrompt },
      ];

      const { data: briefData, error: briefError } = await supabase.functions.invoke("brief-maker", {
        body: { messages },
      });

      if (briefError) throw briefError;
      if (!briefData.briefMd || !briefData.agentDraft) throw new Error("Invalid response from brief-maker");

      const nameMatch = briefData.briefMd.match(/#\s*Build Brief\s*—\s*(.+?)(?:\n|$)/);
      const extractedName = nameMatch ? nameMatch[1].trim() : briefData.agentDraft.name;
      const agentDraft = { ...briefData.agentDraft, name: extractedName || "Untitled Voice Agent", version: "v1.0" };

      setBrief(briefData.briefMd);
      setVoiceAgent(agentDraft);

      // Step 2: Generate agent logo
      toast.loading("🎨 Creating your agent's logo...");
      const { data: logoData, error: logoError } = await supabase.functions.invoke("generate-agent-logo", {
        body: {
          agentName: agentDraft.name,
          agentPersonality: agentDraft.personality,
          tone: agentDraft.tone,
          accent: agentDraft.accent,
        },
      });

      let logoUrl = null;
      if (logoError || !logoData?.logoUrl) {
        console.error("Error generating logo:", logoError);
        // Continue without logo
      } else {
        logoUrl = logoData.logoUrl;
      }

      // Step 3: Create Vapi agent automatically
      toast.dismiss();
      toast.loading("🎙️ Deploying your voice agent...");
      const { data: vapiData, error: vapiError } = await supabase.functions.invoke("create-vapi-agent", {
        body: {
          agentDraft,
          briefMd: briefData.briefMd,
          deployedAgentId: null,
        },
      });

      if (vapiError) throw vapiError;
      if (!vapiData.success || !vapiData.agentId) throw new Error("Invalid response from create-vapi-agent");

      setDeployedAgentId(vapiData.agentId);
      toast.dismiss();

      // Step 4: Save to database if authenticated, otherwise save to localStorage
      if (user) {
        const agentRecord = {
          user_id: user.id,
          version: "v1.0",
          agent_config: {
            name: agentDraft.name,
            tone: agentDraft.tone,
            accent: agentDraft.accent,
            gender: agentDraft.gender,
            warmth: agentDraft.warmth,
            creativity: agentDraft.creativity,
            latency: agentDraft.latency,
            personality: agentDraft.personality,
            sampleLine: agentDraft.sampleLine,
          },
          prompt: briefData.briefMd,
          voice_name: vapiData.voiceName || agentDraft.name,
          voice_id: vapiData.voiceId,
          voice_provider: vapiData.voiceProvider,
          vapi_agent_id: vapiData.agentId,
          logo_url: logoUrl,
        };

        const { data: insertedAgent, error: dbError } = await supabaseFrom("voice_agent_versions")
          .insert(agentRecord)
          .select()
          .single();

        if (dbError) {
          console.error("Error saving to database:", dbError);
          toast.error("Agent created but failed to save to database");
        } else if (insertedAgent) {
          setLoadedAgentId((insertedAgent as any).id);

          // Update voiceAgent state with the database ID
          setVoiceAgent({
            ...agentDraft,
            id: (insertedAgent as any).id,
            vapi_agent_id: vapiData.agentId,
          });

          // Create conversation record for this new agent
          const { data: newConversation, error: convError } = await supabaseFrom("agent_conversations")
            .insert({
              agent_id: (insertedAgent as any).id,
              user_id: user.id,
              messages: [],
            })
            .select()
            .single();

          if (!convError && newConversation) {
            setConversationId((newConversation as any).id);
          }
        }
      } else {
        // For unauthenticated users, save to localStorage only
        saveDraft({
          userPrompt,
          voiceAgent: {
            ...agentDraft,
            vapi_agent_id: vapiData.agentId,
          },
          brief: briefData.briefMd,
          agentLogoUrl: logoUrl,
          deployedAgentId: vapiData.agentId,
        });
        console.log("✅ Agent saved to browser only (trial mode)");
      }

      // Show logo with animation
      if (logoUrl) {
        setAgentLogoUrl(logoUrl);
        setShowLogoAnimation(true);
        setTimeout(() => setShowLogoAnimation(false), 3000);
      }

      if (!user) {
        toast.success(`🎉 Agent created! Create a free account to save it permanently.`, {
          action: {
            label: "Create Account",
            onClick: () => {
              saveDraft({
                userPrompt,
                voiceAgent: {
                  ...agentDraft,
                  vapi_agent_id: vapiData.agentId,
                },
                brief: briefData.briefMd,
                agentLogoUrl: logoUrl,
                deployedAgentId: vapiData.agentId,
              });
              navigate("/auth?redirectTo=/");
            },
          },
        });
      } else {
        toast.success(`🎉 Voice agent "${agentDraft.name}" is ready to test!`);
      }
    } catch (error: any) {
      console.error("Error creating agent:", error);
      
      // Provide specific error messages
      if (error.message?.includes('duplicate') || error.message?.includes('vapi_agent_id')) {
        toast.error("This agent already exists. Please try refreshing the page.");
      } else if (error.message?.includes('brief')) {
        toast.error("Brief generation failed. Please try again.");
      } else if (error.message?.includes('vapi')) {
        toast.error("Voice agent deployment failed. Please check your connection.");
      } else {
        toast.error(error?.message || "Failed to create voice agent");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTestVoiceAgent = async () => {
    if (!deployedAgentId) {
      toast.error("Please accept and deploy the agent before testing.");
      return;
    }

    const publicKey = "6752f1de-13d3-4ed7-bb8d-ce7b033c9543";
    if (!publicKey) {
      toast.error("Missing public Vapi API key (pk-...).");
      return;
    }

    try {
      let assistantOverrides: any = {};
      
      // Only load memory for authenticated users with database-saved agents
      if (loadedAgentId) {
        // Load memory from previous conversations
        toast.loading("🧠 Loading memory...");
        const { data: memoryData } = await supabase.functions.invoke("load-agent-memory", {
          body: { agent_id: loadedAgentId },
        });

        if (memoryData?.hasMemory && memoryData?.summary) {
          console.log("🧠 Memory loaded:", memoryData.summary);
          console.log("✨ Using conversational opener:", memoryData.conversationalOpener);

          // Use the rephrased conversational opener
          assistantOverrides = {
            firstMessage: memoryData.conversationalOpener || memoryData.summary,
          };
          toast.dismiss();
          toast.success("🧠 Loaded memory from your last session");
        } else {
          toast.dismiss();
        }
      }

      toast.loading("🎙️ Connecting to your Voice Agent...");
      const vapi = new Vapi(publicKey);
      setVapiInstance(vapi);
      setCallStatus("connecting");

      // Generate session ID when call starts
      const sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      setCurrentSessionId(sessionId);

      // Use a local array to collect transcript (to avoid stale closure)
      const transcriptMessages: Array<{ role: string; content: string }> = [];
      setCallTranscript([]);

      vapi.on("call-start", () => {
        toast.dismiss();
        setCallStatus("connected");
        toast.success("🟢 Voice agent connected!");
      });

      vapi.on("message", (message: any) => {
        // Collect transcript messages in both local array and state
        if (message.type === "transcript" && message.transcriptType === "final") {
          const transcriptEntry = {
            role: message.role || "user",
            content: message.transcript || "",
          };
          transcriptMessages.push(transcriptEntry);
          setCallTranscript((prev) => [...prev, transcriptEntry]);
          console.log("📝 Transcript message collected:", transcriptEntry);
        }
      });

      vapi.on("call-end", async () => {
        console.log("🔴 Call ended. Transcript length:", transcriptMessages.length);

        // Save transcript in background using the local array
        if (transcriptMessages.length > 0) {
          try {
            console.log("💾 Invoking save-call-transcript with:", {
              agent_id: deployedAgentId,
              session_id: sessionId,
              transcript_length: transcriptMessages.length,
            });

            const { data, error } = await supabase.functions.invoke("save-call-transcript", {
              body: {
                agent_id: deployedAgentId,
                session_id: sessionId,
                transcript: transcriptMessages,
              },
            });

            if (error) {
              console.error("❌ Error saving transcript:", error);
            } else {
              console.log("✅ Transcript saved successfully:", data);

              // Send post-call summary text if user has it enabled
              if (data?.summary) {
                try {
                  const { data: summaryData, error: summaryError } = await supabase.functions.invoke(
                    "send-summary-text",
                    {
                      body: {
                        agent_id: loadedAgentId,
                        summary: data.summary,
                      },
                    },
                  );

                  if (summaryError) {
                    console.error("❌ Error sending summary text:", summaryError);
                  } else if (summaryData?.success) {
                    console.log("✅ Summary text sent successfully");
                  } else if (summaryData?.should_prompt) {
                    // User doesn't have verified phone
                    toast.info("💬 Add your phone in Settings to receive call summaries via text");
                  }
                } catch (error) {
                  console.error("❌ Failed to send summary text:", error);
                }
              }
            }
          } catch (error) {
            console.error("❌ Failed to save transcript:", error);
          }
        } else {
          console.log("⚠️ No transcript to save");
        }

        setCallStatus("idle");
        setCallTranscript([]);
        toast.info("🔴 Call ended");
      });

      vapi.on("error", (err: any) => {
        console.error("Vapi error:", err);
        setCallStatus("idle");
        toast.error("⚠️ Voice connection failed");
      });

      vapi.start(deployedAgentId, assistantOverrides);
    } catch (error) {
      console.error("Error starting web call:", error);
      toast.error("Failed to start voice session");
      setCallStatus("idle");
    }
  };

  const handleMuteToggle = () => {
    if (!vapiInstance) return;
    if (isMuted) {
      vapiInstance.unmute();
      toast.info("🔊 Unmuted");
    } else {
      vapiInstance.mute();
      toast.info("🤫 Muted");
    }
    setIsMuted(!isMuted);
  };

  const handleEndCall = () => {
    if (vapiInstance) vapiInstance.stop();
    // Status will be reset to "idle" by the call-end event
    toast.info("🔴 Ending call...");
  };

  const describePatch = (patch: any[]): string => {
    const descriptions: string[] = [];

    for (const operation of patch) {
      const field = operation.path.replace(/^\//, "").replace(/\/-$/, "");
      const value = operation.value;

      switch (field) {
        case "warmth":
          descriptions.push(`adjusted warmth to ${value}%`);
          break;
        case "creativity":
          descriptions.push(`set creativity to ${value}%`);
          break;
        case "tone":
          if (Array.isArray(value)) {
            descriptions.push(`changed tone to ${value.join(", ")}`);
          }
          break;
        case "accent":
          descriptions.push(`switched to ${value} accent`);
          break;
        case "gender":
          descriptions.push(`changed voice to ${value}`);
          break;
        case "latency":
          descriptions.push(`set response speed to ${value}`);
          break;
        case "consent":
          const consentMap: Record<string, string> = {
            strict: "strict consent checking",
            gentle: "gentle consent prompting",
            auto_proceed: "automatic progression",
          };
          descriptions.push(`set consent handling to ${consentMap[value] || value}`);
          break;
        case "sampleLine":
          descriptions.push(`updated opening line to "${value}"`);
          break;
        default:
          descriptions.push(`updated ${field}`);
      }
    }

    return descriptions.join(", ");
  };

  // Helper function to detect voice change requests
  const isVoiceChangeRequest = (instruction: string): boolean => {
    const voiceKeywords = [
      'accent', 'voice', 'sound like', 'speak', 'speaking',
      'male', 'female', 'man', 'woman', 'gender',
      'british', 'american', 'southern', 'australian', 'indian',
      'younger', 'older', 'age',
      'deep', 'high', 'low', 'pitch',
      'vocal', 'tone of voice'
    ];
    const lowerInstruction = instruction.toLowerCase();
    return voiceKeywords.some(keyword => lowerInstruction.includes(keyword));
  };

  const handleIterateAgent = async (instruction: string) => {
    if (!voiceAgent || !deployedAgentId) {
      toast.error("Agent must be created before iterating");
      return;
    }

    // Add user message to history
    const userMessage = {
      type: "user" as const,
      content: instruction,
      timestamp: new Date(),
    };
    const updatedHistoryWithUser = [...iterationHistory, userMessage];
    setIterationHistory(updatedHistoryWithUser);

    // Update conversation in database with user message immediately
    if (conversationId) {
      await supabaseFrom("agent_conversations")
        .update({
          messages: updatedHistoryWithUser.map((msg) => ({
            type: msg.type,
            content: msg.content,
            timestamp: msg.timestamp.toISOString(),
          })),
        })
        .eq("id", conversationId);
    }

    // End any active call before updating the agent
    if (vapiInstance && callStatus !== "idle" && callStatus !== "ended") {
      vapiInstance.stop();
    }
    // Always reset call status to idle when updating
    setCallStatus("idle");
    setIsMuted(false);

    setIsIterating(true);
    try {
      // Check if this is a voice change request
      const isVoiceChange = isVoiceChangeRequest(instruction);

      if (isVoiceChange) {
        // For voice changes, use brief-maker to regenerate brief with conversational context
        const conversationMessages = [
          {
            role: "assistant",
            content: "Hi! I'm here to help you design your voice agent. Tell me about what you want to create—what's the vibe, who's it for, and what should it do?",
          },
          ...iterationHistory
            .filter(msg => msg.type === "user" || msg.type === "system")
            .map(msg => ({
              role: msg.type === "user" ? "user" as const : "assistant" as const,
              content: msg.content,
            })),
          {
            role: "system",
            content: `CURRENT BUILD BRIEF (preserve all existing content unless the user explicitly asks to change specific aspects):\n\n${brief}`,
          },
          { role: "user", content: instruction },
        ];

        const { data: briefData, error: briefError } = await supabase.functions.invoke("brief-maker", {
          body: { messages: conversationMessages },
        });

        if (briefError) throw briefError;
        if (!briefData.briefMd || !briefData.agentDraft) {
          throw new Error("Invalid response from brief-maker");
        }

        // Extract name from brief
        const nameMatch = briefData.briefMd.match(/#\s*Build Brief\s*—\s*(.+?)(?:\n|$)/);
        const extractedName = nameMatch ? nameMatch[1].trim() : briefData.agentDraft.name;
        const updatedAgent = {
          ...briefData.agentDraft,
          name: extractedName || voiceAgent.name,
          version: voiceAgent.version,
        };

        // Update state
        setBrief(briefData.briefMd);
        setVoiceAgent(updatedAgent);

        // Update Vapi agent with new brief and agent draft
        const { data: vapiData, error: vapiError } = await supabase.functions.invoke("create-vapi-agent", {
          body: {
            agentDraft: updatedAgent,
            briefMd: briefData.briefMd,
            deployedAgentId: deployedAgentId,
          },
        });

        if (vapiError) throw vapiError;

        // Save changes
        if (loadedAgentId && user) {
          const { error: dbError } = await supabaseFrom("voice_agent_versions")
            .update({
              agent_config: {
                name: updatedAgent.name,
                tone: updatedAgent.tone,
                accent: updatedAgent.accent,
                gender: updatedAgent.gender,
                warmth: updatedAgent.warmth,
                creativity: updatedAgent.creativity,
                latency: updatedAgent.latency,
                personality: updatedAgent.personality,
                sampleLine: updatedAgent.sampleLine,
              },
              prompt: briefData.briefMd,
              voice_name: vapiData.voiceName || updatedAgent.name,
              voice_id: vapiData.voiceId,
              voice_provider: vapiData.voiceProvider,
            })
            .eq("id", loadedAgentId);

          if (dbError) {
            console.error("Error updating database:", dbError);
            toast.error("Agent updated but failed to save to database");
          }
        } else {
          // Trial mode: save to localStorage
          saveDraft({
            voiceAgent: updatedAgent,
            deployedAgentId,
            brief: briefData.briefMd,
            iterationHistory: updatedHistoryWithUser.map(msg => ({
              type: msg.type,
              content: msg.content,
              timestamp: msg.timestamp instanceof Date ? msg.timestamp.toISOString() : msg.timestamp,
            })),
          });
          console.log("💾 Trial mode: Saved updated agent with new brief to localStorage");
        }

        // Add system message response for voice update
        const systemMessage = {
          type: "system" as const,
          content: `Updated your agent's voice! The accent is now set to ${updatedAgent.accent}. Start a new call to hear the change.`,
          timestamp: new Date(),
        };
        const updatedHistoryWithSystem = [...updatedHistoryWithUser, systemMessage];
        setIterationHistory(updatedHistoryWithSystem);

        if (conversationId) {
          await supabaseFrom("agent_conversations")
            .update({
              messages: updatedHistoryWithSystem.map((msg) => ({
                type: msg.type,
                content: msg.content,
                timestamp: msg.timestamp.toISOString(),
              })),
            })
            .eq("id", conversationId);
        }

        toast.success("🎉 Voice updated! Start a new call to test.");
      } else {
        // For non-voice changes, use voice-tuner for efficient JSON patching
        const { data: patchData, error: patchError } = await supabase.functions.invoke("voice-tuner", {
          body: {
            editInstruction: instruction,
            currentAgent: voiceAgent,
          },
        });

        if (patchError) throw patchError;
        if (!patchData.patch || !Array.isArray(patchData.patch)) {
          throw new Error("Invalid patch response from voice-tuner");
        }

        // Generate human-readable description of changes
        const patchDescription = describePatch(patchData.patch);

        // Apply patch to current agent
        const updatedAgent = applyPatch(JSON.parse(JSON.stringify(voiceAgent)), patchData.patch).newDocument;
        setVoiceAgent(updatedAgent);


        // Update Vapi agent
        const { data: vapiData, error: vapiError } = await supabase.functions.invoke("create-vapi-agent", {
          body: {
            agentDraft: updatedAgent,
            briefMd: brief,
            deployedAgentId: deployedAgentId,
          },
        });

        if (vapiError) throw vapiError;

        // Save changes (database for authenticated users, localStorage for trial mode)
        if (loadedAgentId && user) {
          // Authenticated user: save to database
          const { error: dbError } = await supabaseFrom("voice_agent_versions")
            .update({
              agent_config: {
                name: updatedAgent.name,
                tone: updatedAgent.tone,
                accent: updatedAgent.accent,
                gender: updatedAgent.gender,
                warmth: updatedAgent.warmth,
                creativity: updatedAgent.creativity,
                latency: updatedAgent.latency,
                personality: updatedAgent.personality,
                sampleLine: updatedAgent.sampleLine,
              },
              voice_name: vapiData.voiceName || updatedAgent.name,
              voice_id: vapiData.voiceId,
              voice_provider: vapiData.voiceProvider,
            })
            .eq("id", loadedAgentId);

          if (dbError) {
            console.error("Error updating database:", dbError);
            toast.error("Agent updated in Vapi but failed to save to database");
            const errorMessage = {
              type: "system" as const,
              content: "Failed to save changes to database",
              timestamp: new Date(),
            };
            const updatedHistoryWithError = [...updatedHistoryWithUser, errorMessage];
            setIterationHistory(updatedHistoryWithError);

            // Update conversation with error message
            if (conversationId) {
              await supabaseFrom("agent_conversations")
                .update({
                  messages: updatedHistoryWithError.map((msg) => ({
                    type: msg.type,
                    content: msg.content,
                    timestamp: msg.timestamp.toISOString(),
                  })),
                })
                .eq("id", conversationId);
            }
            return;
          }
        } else {
          // Trial mode: save to localStorage
          saveDraft({
            voiceAgent: updatedAgent,
            deployedAgentId,
            iterationHistory: [...iterationHistory, userMessage].map(msg => ({
              type: msg.type,
              content: msg.content,
              timestamp: msg.timestamp instanceof Date ? msg.timestamp.toISOString() : msg.timestamp,
            })),
          });
          console.log("💾 Trial mode: Saved updated agent to localStorage");
        }

        // Success message
        const successMessage = {
          type: "system" as const,
          content: patchDescription
            ? `Updated your agent: ${patchDescription} Start a new call to test the changes.`
            : "Agent updated successfully! Start a new call to test the changes.",
          timestamp: new Date(),
        };
        const updatedHistoryWithSuccess = [...updatedHistoryWithUser, successMessage];
        setIterationHistory(updatedHistoryWithSuccess);

        // Update conversation with success message (authenticated users only)
        if (conversationId) {
          await supabaseFrom("agent_conversations")
            .update({
              messages: updatedHistoryWithSuccess.map((msg) => ({
                type: msg.type,
                content: msg.content,
                timestamp: msg.timestamp.toISOString(),
              })),
            })
            .eq("id", conversationId);
        }

        toast.success("🎉 Agent updated! Start a new call to test the changes.");
      }
    } catch (error: any) {
      console.error("Error iterating agent:", error);
      toast.error(error?.message || "Failed to update agent");
      const errorMessage = {
        type: "system" as const,
        content: `Error: ${error?.message || "Failed to update agent"}`,
        timestamp: new Date(),
      };
      const updatedHistoryWithError = [...updatedHistoryWithUser, errorMessage];
      setIterationHistory(updatedHistoryWithError);

      // Update conversation with error message
      if (conversationId) {
        await supabaseFrom("agent_conversations")
          .update({
            messages: updatedHistoryWithError.map((msg) => ({
              type: msg.type,
              content: msg.content,
              timestamp: msg.timestamp.toISOString(),
            })),
          })
          .eq("id", conversationId);
      }
    } finally {
      setIsIterating(false);
    }
  };

  // Track current prompt and debounced auto-save for draft
  const handlePromptChange = useCallback((prompt: string) => {
    setCurrentUserPrompt(prompt);
  }, []);

  // Debounced auto-save for unauthenticated users
  useEffect(() => {
    if (!user && currentUserPrompt.trim()) {
      const timeoutId = setTimeout(() => {
        saveDraft({
          userPrompt: currentUserPrompt,
          iterationInput: initialIterationInput,
          iterationHistory: iterationHistory.map((msg) => ({
            ...msg,
            timestamp: msg.timestamp.toISOString(),
          })),
          voiceAgent,
          brief,
          agentLogoUrl: agentLogoUrl || undefined,
          deployedAgentId: deployedAgentId || undefined,
        });
        console.log("Auto-saved draft for unauthenticated user");
      }, 1000); // 1 second debounce

      return () => clearTimeout(timeoutId);
    }
  }, [
    user,
    currentUserPrompt,
    initialIterationInput,
    iterationHistory,
    voiceAgent,
    brief,
    agentLogoUrl,
    deployedAgentId,
  ]);

  // Beforeunload warning for unauthenticated users with agents
  useEffect(() => {
    if (!user && deployedAgentId) {
      const handleBeforeUnload = (e: BeforeUnloadEvent) => {
        e.preventDefault();
        e.returnValue = "Your agent hasn't been saved to an account. Create a free account to save it permanently.";
        return e.returnValue;
      };

      window.addEventListener("beforeunload", handleBeforeUnload);
      return () => window.removeEventListener("beforeunload", handleBeforeUnload);
    }
  }, [user, deployedAgentId]);

  const handleIterationInputChange = useCallback(
    (input: string) => {
      setInitialIterationInput(input);

      if (!user) {
        // Auto-save draft for unauthenticated users
        saveDraft({
          userPrompt: currentUserPrompt,
          iterationInput: input,
          iterationHistory: iterationHistory.map((msg) => ({
            ...msg,
            timestamp: msg.timestamp.toISOString(),
          })),
          voiceAgent,
          brief,
          agentLogoUrl: agentLogoUrl || undefined,
          deployedAgentId: deployedAgentId || undefined,
        });
      }
    },
    [user, currentUserPrompt, iterationHistory, voiceAgent, brief, agentLogoUrl, deployedAgentId],
  );

  const handlePublishAgent = async () => {
    if (!voiceAgent) {
      toast.error("No agent to publish");
      return;
    }

    if (!user) {
      // Show auth prompt dialog for publishing
      setShowAuthPromptDialog(true);
      return;
    }

    setIsPublishing(true);
    try {
      const { data, error } = await supabase.functions.invoke("publish-agent", {
        body: {
          agentConfig: voiceAgent,
          vapiAgentId: deployedAgentId,
          brief: brief,
          logoUrl: agentLogoUrl,
        },
      });

      if (error) throw error;

      const fullUrl = `${window.location.origin}/agent/${data.shareId}`;
      setShareUrl(fullUrl);
      
      // Check if agent has phone number assigned
      setPublishPhoneNumber(voiceAgent.phone_number || null);
      
      setShowPublishDialog(true);
      toast.success("Agent published successfully!");
    } catch (error: any) {
      console.error("Error publishing agent:", error);
      toast.error(error?.message || "Failed to publish agent");
    } finally {
      setIsPublishing(false);
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedUrl(true);
    toast.success("Link copied to clipboard!");
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleAssignPublishPhoneNumber = async () => {
    if (!voiceAgent?.id) {
      toast.error("Agent not found");
      return;
    }

    setAssigningPublishPhone(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/assign-demo-phone-number`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            agentId: voiceAgent.id,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok || result.error) {
        throw new Error(result.error || "Failed to assign phone number");
      }

      setPublishPhoneNumber(result.phoneNumber);
      setVoiceAgent({ ...voiceAgent, phone_number: result.phoneNumber, phone_number_id: result.phoneNumberId });
      toast.success("Phone number assigned successfully!");
    } catch (error: any) {
      console.error("Error assigning phone number:", error);
      toast.error(error?.message || "Failed to assign phone number");
    } finally {
      setAssigningPublishPhone(false);
    }
  };

  const handleUnassignPublishPhoneNumber = async () => {
    if (!voiceAgent?.id) {
      toast.error("Agent not found");
      return;
    }

    setUnassigningPublishPhone(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/unassign-demo-phone-number`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            agentId: voiceAgent.id,
          }),
        }
      );

      const result = await response.json();

      if (!response.ok || result.error) {
        throw new Error(result.error || "Failed to unassign phone number");
      }

      setPublishPhoneNumber(null);
      setVoiceAgent({ ...voiceAgent, phone_number: null, phone_number_id: null });
      toast.success("Phone number unassigned successfully!");
    } catch (error: any) {
      console.error("Error unassigning phone number:", error);
      toast.error(error?.message || "Failed to unassign phone number");
    } finally {
      setUnassigningPublishPhone(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Trial Mode Banner */}
      {!user && (voiceAgent || deployedAgentId) && (
        <TrialModeBanner
          onCreateAccount={() => {
            // Save current state before navigating
            if (voiceAgent || deployedAgentId) {
              saveDraft({
                userPrompt: currentUserPrompt,
                voiceAgent,
                brief,
                agentLogoUrl: agentLogoUrl || undefined,
                deployedAgentId: deployedAgentId || undefined,
                iterationHistory: iterationHistory.map(item => ({
                  type: item.type,
                  content: item.content,
                  timestamp: item.timestamp.toISOString(),
                })),
              });
              
              // Backup to sessionStorage for auth flow persistence
              backupDraftToSession();
              console.log("🔄 Navigating to auth, draft backed up to sessionStorage");
            }
            navigate("/auth?redirectTo=/");
          }}
        />
      )}

      {/* Top Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md z-10 shadow-sm">
        <div className="px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/favicon.png" alt="Flappable" className="w-8 h-8" />
            <div>
              <h1 className="text-lg font-bold text-foreground">Flappable</h1>
              {user ? (
                <p className="text-xs text-muted-foreground">Build AI voice agents in minutes</p>
              ) : (
                <p className="text-xs text-muted-foreground">
                  ✨ Design your own voice agent — it starts with a conversation.
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <TooltipProvider>
              {false && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      onClick={() => {
                        if (window.history.length > 1) {
                          navigate(-1);
                        } else {
                          navigate("/dashboard");
                        }
                      }}
                      variant="ghost"
                      size="icon"
                      className="hover:bg-accent/50 transition-all duration-300"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      {getBackLabel()}
                    </Button>
                  </TooltipTrigger>
                </Tooltip>
              )}

              {deployedAgentId && user && (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      onClick={() => navigate("/configuration", { state: { voiceAgent, brief } })}
                      variant="ghost"
                      size="sm"
                      className="gap-2"
                    >
                      <FileText className="w-4 h-4" />
                      Configuration
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>View Agent Configuration</p>
                  </TooltipContent>
                </Tooltip>
              )}

              {user ? (
                <>
                  <Button onClick={handleGoToDashboard} variant="ghost" size="sm" className="gap-2">
                    <LayoutDashboard className="w-4 h-4" />
                    Dashboard
                  </Button>
                  <Button onClick={handleGoToSettings} variant="ghost" size="sm" className="gap-2">
                    <SettingsIcon className="w-4 h-4" />
                    Settings
                  </Button>

                  {deployedAgentId && (
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          onClick={handlePublishAgent}
                          disabled={isPublishing}
                          variant="default"
                          size="sm"
                          className="gap-2"
                        >
                          <Share2 className="w-4 h-4" />
                          {isPublishing ? "Publishing..." : "Publish"}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Publish & Share Agent</p>
                      </TooltipContent>
                    </Tooltip>
                  )}
                </>
              ) : (
                <Button onClick={() => navigate("/auth")} variant="default" size="sm" className="gap-2">
                  Sign In
                </Button>
              )}
            </TooltipProvider>
          </div>
        </div>
      </header>

      {/* Main Content */}
      {!deployedAgentId ? (
        // Clean landing page when no agent exists
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-3xl space-y-6">
            {/* Hero Section */}
            <div className="text-center space-y-3 mb-8">
              <h2 className="text-4xl font-bold text-foreground">Create a Voice Agent</h2>
              <p className="text-lg text-muted-foreground">
                Describe what you want your AI voice agent to do, and we'll build it for you
              </p>
            </div>

            {/* Main Input */}
            <ChatPanel
              onCreateAgent={handleCreateAgent}
              isGenerating={isGenerating}
              hasAgent={false}
              currentAgent={null}
              onUpdateAgent={handleIterateAgent}
              isUpdating={isIterating}
              iterationHistory={iterationHistory}
              user={user}
              onPromptChange={handlePromptChange}
              initialPrompt={initialPrompt}
              onIterationInputChange={handleIterationInputChange}
              initialIterationInput={initialIterationInput}
            />
          </div>
        </div>
      ) : (
        // Split view when agent exists
        <div className="flex-1 flex overflow-hidden">
          {/* Left Panel - Chat */}
          <div className="w-[400px] border-r border-border">
            <ChatPanel
              onCreateAgent={handleCreateAgent}
              isGenerating={isGenerating}
              hasAgent={!!deployedAgentId}
              currentAgent={voiceAgent}
              onUpdateAgent={handleIterateAgent}
              isUpdating={isIterating}
              iterationHistory={iterationHistory}
              user={user}
              onPromptChange={handlePromptChange}
              initialPrompt={initialPrompt}
              onIterationInputChange={handleIterationInputChange}
              initialIterationInput={initialIterationInput}
            />
          </div>

          {/* Right Panel - Preview */}
          <div className="flex-1">
            <PreviewPanel
              voiceAgent={voiceAgent}
              callStatus={callStatus}
              isMuted={isMuted}
              onTestVoice={handleTestVoiceAgent}
              onMuteToggle={handleMuteToggle}
              onEndCall={handleEndCall}
              logoUrl={agentLogoUrl}
              showLogoAnimation={showLogoAnimation}
              deployedAgentId={deployedAgentId}
            />
          </div>
        </div>
      )}

      {/* Publish Dialog */}
      <Dialog open={showPublishDialog} onOpenChange={setShowPublishDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Agent Published!</DialogTitle>
            <DialogDescription>
              Your voice agent is now live and ready to share. Anyone with this link can interact with it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Share URL */}
            <div className="flex items-center gap-2">
              <Input value={shareUrl} readOnly className="flex-1" />
              <Button onClick={handleCopyUrl} variant="outline" size="icon">
                {copiedUrl ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>

            <Separator />

            {/* Phone Line Section */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Phone Line</h4>
              
              {/* Demo Number Warning */}
              <Alert className="border-blue-500/50 bg-blue-500/10">
                <AlertCircle className="h-4 w-4 text-blue-500" />
                <AlertDescription className="text-foreground text-xs">
                  <strong>Demo Mode:</strong> This shared demo number can only route to one agent at a time.
                </AlertDescription>
              </Alert>

              {publishPhoneNumber ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-secondary/30 rounded-lg border border-border">
                    <Phone className="w-4 h-4 text-primary" />
                    <span className="text-sm font-semibold text-foreground flex-1">
                      {publishPhoneNumber.replace(/(\+1)(\d{3})(\d{3})(\d{4})/, '$1 ($2) $3-$4')}
                    </span>
                    <Button
                      onClick={() => {
                        navigator.clipboard.writeText(publishPhoneNumber);
                        toast.success("Phone number copied!");
                      }}
                      variant="ghost"
                      size="sm"
                      className="h-8"
                    >
                      Copy
                    </Button>
                  </div>
                  <Button
                    onClick={handleUnassignPublishPhoneNumber}
                    disabled={unassigningPublishPhone}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    {unassigningPublishPhone ? "Unassigning..." : "Unassign Phone Number"}
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={handleAssignPublishPhoneNumber}
                  disabled={assigningPublishPhone}
                  variant="default"
                  size="sm"
                  className="w-full"
                >
                  {assigningPublishPhone ? "Assigning..." : "Assign a Phone Number"}
                </Button>
              )}
            </div>

            <Separator />

            <div className="flex gap-2">
              <Button onClick={() => window.open(shareUrl, "_blank")} className="flex-1 gap-2">
                <Share2 className="w-4 h-4" />
                Open Shared Page
              </Button>
              <Button onClick={() => setShowPublishDialog(false)} variant="outline" className="flex-1">
                Done
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Auth Prompt Dialog for Publishing */}
      <Dialog open={showAuthPromptDialog} onOpenChange={setShowAuthPromptDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a Free Account to Publish</DialogTitle>
            <DialogDescription className="space-y-3">
              <p>Publishing lets you share your agent with anyone via a link.</p>
              <p className="font-medium">Create a free account to:</p>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Save your agents permanently</li>
                <li>Publish and share with anyone</li>
                <li>Access your agents from any device</li>
                <li>Track usage and analytics</li>
              </ul>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowAuthPromptDialog(false)}>
              Maybe Later
            </Button>
            <Button
              onClick={() => {
                // Save current state to draft
                saveDraft({
                  userPrompt: currentUserPrompt,
                  voiceAgent,
                  brief,
                  agentLogoUrl: agentLogoUrl || undefined,
                  deployedAgentId: deployedAgentId || undefined,
                });
                navigate("/auth?redirectTo=/");
              }}
            >
              Create Free Account
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Index;
