import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit2, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

interface AgentStatusCardProps {
  voiceName: string;
  voiceId: string;
  tone: string;
  accent: string;
  version: string;
  promptPreview: string;
  onEditPrompt: () => void;
}

export const AgentStatusCard = ({
  voiceName,
  voiceId,
  tone,
  accent,
  version,
  promptPreview,
  onEditPrompt,
}: AgentStatusCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card className="p-4 bg-card/80 backdrop-blur-sm border-primary/20">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-foreground">Agent Status</h3>
            <Badge variant="secondary" className="mt-1 text-xs">{version}</Badge>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onEditPrompt}
            className="h-8 w-8"
            title="Edit system prompt"
          >
            <Edit2 className="h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <span className="text-muted-foreground">Voice:</span>
            <p className="font-medium text-foreground">{voiceName}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Accent:</span>
            <p className="font-medium text-foreground">{accent}</p>
          </div>
          <div className="col-span-2">
            <span className="text-muted-foreground">Tone:</span>
            <p className="font-medium text-foreground">{tone}</p>
          </div>
        </div>

        <div className="border-t border-border pt-3">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center justify-between w-full text-left group"
          >
            <span className="text-xs text-muted-foreground">System Prompt</span>
            {isExpanded ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground group-hover:text-foreground transition-colors" />
            )}
          </button>
          
          {isExpanded ? (
            <p className="mt-2 text-xs text-muted-foreground whitespace-pre-wrap font-mono bg-muted/50 p-2 rounded">
              {promptPreview}
            </p>
          ) : (
            <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
              {promptPreview}
            </p>
          )}
        </div>
      </div>
    </Card>
  );
};
