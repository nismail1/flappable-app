import { useState, useEffect, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Sparkles, Phone, LogOut, LayoutDashboard } from "lucide-react";
import { toast } from "sonner";
import type { User } from "@supabase/supabase-js";
import { useNavigation } from "@/contexts/NavigationContext";

const Settings = () => {
  const navigate = useNavigate();
  const { getBackLabel, shouldShowBack } = useNavigation();
  const [searchParams] = useSearchParams();
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const [user, setUser] = useState<User | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [isVerified, setIsVerified] = useState(false);
  const [googleCalendarConnected, setGoogleCalendarConnected] = useState(false);
  const [codeSent, setCodeSent] = useState(false);
  const [loading, setLoading] = useState(false);

  // Focus phone input if navigated with focus=phone parameter
  useEffect(() => {
    if (searchParams.get('focus') === 'phone') {
      setTimeout(() => {
        phoneInputRef.current?.focus();
        phoneInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 100);
    }
  }, [searchParams]);

  // Capture Google tokens immediately after OAuth redirect
  useEffect(() => {
    const captureGoogleTokens = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.provider_token && session?.provider_refresh_token) {
        console.log('🔍 Detected OAuth tokens in session, storing...');
        
        try {
          const { error } = await supabase.functions.invoke('sync-google-tokens', {
            body: {
              access_token: session.provider_token,
              refresh_token: session.provider_refresh_token,
            },
          });
          
          if (error) {
            console.error('Failed to store tokens:', error);
            toast.error("Failed to store calendar tokens");
          } else {
            console.log('✅ Tokens stored successfully');
            setGoogleCalendarConnected(true);
            toast.success("Google Calendar connected successfully!");
            loadProfile();
          }
        } catch (err) {
          console.error('Error storing tokens:', err);
        }
      }
    };

    captureGoogleTokens();
  }, []);

  // Capture Google tokens immediately after OAuth redirect
  useEffect(() => {
    const captureGoogleTokens = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.provider_token && session?.provider_refresh_token) {
        console.log('🔍 Detected OAuth tokens in session, storing...');
        
        try {
          const { error } = await supabase.functions.invoke('sync-google-tokens', {
            body: {
              access_token: session.provider_token,
              refresh_token: session.provider_refresh_token,
            },
          });
          
          if (error) {
            console.error('Failed to store tokens:', error);
            toast.error("Failed to store calendar tokens");
          } else {
            console.log('✅ Tokens stored successfully');
            setGoogleCalendarConnected(true);
            toast.success("Google Calendar connected successfully!");
            loadProfile();
          }
        } catch (err) {
          console.error('Error storing tokens:', err);
        }
      }
    };

    captureGoogleTokens();
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        navigate("/auth");
      } else {
        loadProfile();
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('phone_number, phone_verified, google_calendar_connected')
        .eq('id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setPhoneNumber(data.phone_number || "");
        setIsVerified(data.phone_verified || false);
        setGoogleCalendarConnected(data.google_calendar_connected || false);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const handleSendCode = async () => {
    if (!phoneNumber.trim()) {
      toast.error("Please enter a phone number");
      return;
    }

    // Validate phone format (must start with + and contain only digits, spaces, or dashes)
    const phoneRegex = /^\+[0-9\s\-]+$/;
    if (!phoneRegex.test(phoneNumber)) {
      toast.error("Please enter a valid phone number in E.164 format (e.g., +1 415 555 2671)");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('verify-phone', {
        body: { action: 'send', phone_number: phoneNumber }
      });

      if (error) throw error;

      setCodeSent(true);
      toast.success("Verification code sent!");
    } catch (error) {
      console.error('Error sending code:', error);
      toast.error("Failed to send verification code");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    if (!verificationCode.trim()) {
      toast.error("Please enter the verification code");
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('verify-phone', {
        body: { action: 'verify', code: verificationCode }
      });

      if (error) throw error;

      if (data?.verified) {
        setIsVerified(true);
        setCodeSent(false);
        setVerificationCode("");
        toast.success("Phone number verified!");
        loadProfile();
      } else {
        toast.error("Invalid verification code");
      }
    } catch (error) {
      console.error('Error verifying code:', error);
      toast.error("Failed to verify code");
    } finally {
      setLoading(false);
    }
  };

  const handleConnectGoogleCalendar = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        scopes: 'openid email profile https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events',
        redirectTo: window.location.origin + '/settings',
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        }
      },
    });
    
    if (error) {
      toast.error("Failed to connect with Google");
    }
  };

  const handleDisconnectGoogleCalendar = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('disconnect-google-calendar');
      
      if (error) throw error;
      
      setGoogleCalendarConnected(false);
      toast.success("Google Calendar disconnected successfully");
      
      // Reload profile to get updated state
      await loadProfile();
    } catch (error) {
      console.error('Error disconnecting Google Calendar:', error);
      toast.error("Failed to disconnect Google Calendar");
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };


  return (
    <div className="min-h-screen bg-background">
      {/* Top Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md z-10 shadow-sm">
        <div className="px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/favicon.png" alt="Flappable" className="w-8 h-8" />
            <div>
              <h1 className="text-lg font-bold text-foreground">Flappable</h1>
              <p className="text-xs text-muted-foreground">Build AI voice agents in minutes</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button onClick={() => navigate("/")} variant="ghost" size="sm" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Home
            </Button>
            <Button onClick={() => navigate("/dashboard")} variant="ghost" size="sm" className="gap-2">
              <LayoutDashboard className="w-4 h-4" />
              Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8 max-w-2xl">
        <h2 className="text-2xl font-bold text-foreground mb-6">Settings</h2>
        
        {/* Phone Verification Card */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-primary" />
              <CardTitle>Phone Number</CardTitle>
            </div>
            <CardDescription>
              Add and verify your phone number to receive text messages
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <p className="text-xs text-muted-foreground mb-2">
                Use the correct format including your country code (for example, +1 415 555 2671 or +91 98765 43210).
              </p>
              <div className="flex gap-2">
                <Input
                  id="phone"
                  ref={phoneInputRef}
                  type="tel"
                  placeholder="+14155552671"
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value);
                    // Reset verification states when changing number
                    if (isVerified || codeSent) {
                      setIsVerified(false);
                      setCodeSent(false);
                      setVerificationCode("");
                    }
                  }}
                  disabled={loading}
                />
                {!codeSent && (
                  <Button 
                    onClick={handleSendCode} 
                    disabled={loading || !phoneNumber.trim()}
                  >
                    {loading ? "Sending..." : (isVerified ? "Re-verify" : "Send Code")}
                  </Button>
                )}
                {codeSent && (
                  <Button variant="outline" disabled className="gap-2">
                    Code Sent
                  </Button>
                )}
              </div>
            </div>

            {codeSent && !isVerified && (
              <div className="space-y-2">
                <Label htmlFor="code">Verification Code</Label>
                <div className="flex gap-2">
                  <Input
                    id="code"
                    type="text"
                    placeholder="Enter 6-digit code"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    disabled={loading}
                    maxLength={6}
                  />
                  <Button onClick={handleVerifyCode} disabled={loading || !verificationCode.trim()}>
                    {loading ? "Verifying..." : "Verify"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Check your phone for the verification code
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Google Calendar</CardTitle>
            <CardDescription>
              {googleCalendarConnected 
                ? "Your Google Calendar is connected. You can enable calendar integration per agent in the Configuration tab."
                : "Connect your Google account to automatically create calendar events from voice agent appointments."
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {googleCalendarConnected ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <span>✓ Google Calendar connected</span>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={async () => {
                      setLoading(true);
                      try {
                        // Force re-authentication to get fresh tokens
                        const { error } = await supabase.auth.signInWithOAuth({
                          provider: 'google',
                          options: {
                            redirectTo: `${window.location.origin}/settings`,
                            scopes: 'openid email profile https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events',
                            queryParams: {
                              access_type: 'offline',
                              prompt: 'consent',
                            },
                          },
                        });
                        
                        if (error) throw error;
                      } catch (error) {
                        console.error('Error refreshing connection:', error);
                        toast.error("Failed to refresh tokens. Please try reconnecting.");
                      } finally {
                        setLoading(false);
                      }
                    }}
                    disabled={loading}
                    variant="outline"
                    size="sm"
                  >
                    Refresh Connection
                  </Button>
                  <Button
                    onClick={handleDisconnectGoogleCalendar}
                    disabled={loading}
                    variant="outline"
                    size="sm"
                  >
                    {loading ? "Disconnecting..." : "Disconnect"}
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                onClick={handleConnectGoogleCalendar}
                disabled={loading}
                className="w-full"
              >
                {loading ? "Connecting..." : "Connect Google Calendar"}
              </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Account</CardTitle>
            <CardDescription>
              Manage your account settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <button
              onClick={async () => {
                await supabase.auth.signOut();
                toast.success("Signed out successfully");
                navigate("/auth");
              }}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </CardContent>
        </Card>

      </div>
    </div>
  );
};

export default Settings;
