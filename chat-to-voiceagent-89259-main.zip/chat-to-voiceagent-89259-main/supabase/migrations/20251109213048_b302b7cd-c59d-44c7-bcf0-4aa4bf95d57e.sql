-- Create agent_call_transcripts table for persistent memory
CREATE TABLE IF NOT EXISTS public.agent_call_transcripts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  agent_id UUID NOT NULL,
  user_id UUID NOT NULL,
  session_id TEXT NOT NULL,
  transcript JSONB NOT NULL DEFAULT '[]'::jsonb,
  summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.agent_call_transcripts ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own transcripts"
ON public.agent_call_transcripts
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own transcripts"
ON public.agent_call_transcripts
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own transcripts"
ON public.agent_call_transcripts
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own transcripts"
ON public.agent_call_transcripts
FOR DELETE
USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_agent_call_transcripts_user_agent 
ON public.agent_call_transcripts(user_id, agent_id, created_at DESC);