import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MessageCircle, Zap, Shield, TrendingUp } from "lucide-react";

interface VibeChipsProps {
  onSelect: (chip: string, value: string) => void;
}

export const VibeChips = ({ onSelect }: VibeChipsProps) => {
  const chips = [
    {
      label: "Tone",
      icon: MessageCircle,
      options: [
        "Warm and empathetic",
        "Upbeat and motivating",
        "Professional and concise",
        "Relaxed and playful",
        "Reflective and spacious",
      ],
    },
    {
      label: "Latency",
      icon: Zap,
      options: [
        "Fast (quick, energetic)",
        "Natural (balanced pacing)",
        "Slow (reflective, spacious)",
      ],
    },
    {
      label: "Consent",
      icon: Shield,
      options: [
        "Strict (always ask)",
        "Gentle (soft prompts)",
        "Auto-proceed (minimal friction)",
      ],
    },
    {
      label: "Growth",
      icon: TrendingUp,
      options: [
        "Light nudges",
        "Regular check-ins",
        "Pass-the-mic invites",
        "Minimal follow-up",
      ],
    },
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {chips.map((chip) => {
        const Icon = chip.icon;
        return (
          <DropdownMenu key={chip.label}>
            <DropdownMenuTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 hover:bg-primary/10 hover:border-primary transition-all"
              >
                <Icon className="w-3.5 h-3.5" />
                {chip.label}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              {chip.options.map((option) => (
                <DropdownMenuItem
                  key={option}
                  onClick={() => onSelect(chip.label, option)}
                  className="cursor-pointer"
                >
                  {option}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        );
      })}
    </div>
  );
};
