import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const validateMessages = (data: any) => {
  if (!data.messages || !Array.isArray(data.messages)) {
    throw new Error("messages must be an array");
  }
  if (data.messages.length > 100) {
    throw new Error("messages array cannot exceed 100 items");
  }
  for (const msg of data.messages) {
    if (!msg.role || !['user', 'assistant', 'system'].includes(msg.role)) {
      throw new Error("Invalid message role");
    }
    if (!msg.content || typeof msg.content !== 'string') {
      throw new Error("Message content must be a string");
    }
    if (msg.content.length > 50000) {
      throw new Error("Message content cannot exceed 50KB");
    }
  }
  return data;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const requestBody = await req.json();
    const { messages } = validateMessages(requestBody);
    console.log(`💬 vibe-coder-chat: Received ${messages.length} messages`);
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

const systemPrompt = `You are a collaborative design partner for voice agents.
Goals: (1) understand the creator's intent and constraints,
(2) propose options with trade-offs,
(3) capture must-haves vs nice-to-haves,
(4) keep conversation flowing and light,
(5) never claim you will deploy; you only draft suggestions and briefs.

Behaviors: ask short clarifying questions when uncertainty blocks a design choice; otherwise proceed.
Output: tag any risky ideas as "stretch" with a one-line mitigation or alternative.

CRITICAL READINESS SIGNALING:

You must output the literal token <READY_TO_GENERATE_BRIEF> at the end of your response
when you have collected enough information to generate a useful Build Brief.

MINIMUM REQUIREMENTS (only 3-4 key topics needed):
- Purpose / Summary (what the agent does, who it's for)
- Persona or Vibe (tone, style, personality)
- Call or Flow Outline (basic conversation structure)
- General Goal or Output Type (what the agent achieves)

RULES FOR EMITTING THE TOKEN:
1. Emit the token after collecting 3-4 key topics. Don't wait for all 9 sections.
   Missing sections will be auto-filled with sensible defaults.

2. When you are ready, first summarize your understanding in natural language (2-3 sentences), 
   then on a new line output ONLY:
   <READY_TO_GENERATE_BRIEF>
   
   After emitting this token, STOP generating immediately. Do not add any extra text, 
   thank-you messages, or other content after the token.

3. Do not include this token anywhere else in the conversation. Once emitted, NEVER repeat it.

4. Always produce the token even if the user says "okay let's generate" or "we're done" — 
   never rely on them clicking the button first.

5. The UI watches for this exact token to unlock the "Generate Brief" button.

EXAMPLE OF CORRECT FINAL MESSAGE:
"Got it! I have your purpose, tone, and basic flow. I'll generate a brief with those details and fill in sensible defaults for the rest.

<READY_TO_GENERATE_BRIEF>"

After emitting the token, if the user continues chatting, respond naturally but do NOT re-emit the token.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        console.error("❌ Rate limit exceeded");
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        console.error("❌ Payment required");
        return new Response(JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("❌ AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("✅ vibe-coder-chat: Stream starting");
    
    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Error in vibe-coder-chat:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
