import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_VERIFY_SERVICE_SID = Deno.env.get('TWILIO_VERIFY_SERVICE_SID');

// Normalize phone number for Twilio (remove spaces and dashes, keep + and digits)
const normalizePhone = (phone: string): string => {
  return phone.replace(/[\s\-]/g, '');
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { action, phone_number, code } = await req.json();

    if (action === 'send') {
      // Send verification code via Twilio Verify
      const normalizedPhone = normalizePhone(phone_number);
      console.log(`📤 Sending verification to normalized: ${normalizedPhone}`);
      
      const twilioUrl = `https://verify.twilio.com/v2/Services/${TWILIO_VERIFY_SERVICE_SID}/Verifications`;
      
      const twilioResponse = await fetch(twilioUrl, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          To: normalizedPhone,
          Channel: 'sms',
        }),
      });

      if (!twilioResponse.ok) {
        const errorText = await twilioResponse.text();
        console.error('❌ Twilio Verify error:', errorText);
        throw new Error('Failed to send verification code');
      }

      console.log(`📤 Sent verification code to ${phone_number}`);

      // Store phone number (unverified) in profile
      await supabaseClient
        .from('profiles')
        .update({ 
          phone_number,
          phone_verified: false 
        })
        .eq('id', user.id);

      return new Response(
        JSON.stringify({ success: true, message: 'Verification code sent' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else if (action === 'verify') {
      // Verify the code
      const { data: profile } = await supabaseClient
        .from('profiles')
        .select('phone_number')
        .eq('id', user.id)
        .maybeSingle();

      if (!profile?.phone_number) {
        throw new Error('Phone number not found. Please send a verification code first.');
      }

      const normalizedPhone = normalizePhone(profile.phone_number);
      console.log(`🔍 Verifying code for normalized: ${normalizedPhone}`);

      const twilioUrl = `https://verify.twilio.com/v2/Services/${TWILIO_VERIFY_SERVICE_SID}/VerificationCheck`;
      
      const twilioResponse = await fetch(twilioUrl, {
        method: 'POST',
        headers: {
          'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          To: normalizedPhone,
          Code: code,
        }),
      });

      const result = await twilioResponse.json();

      if (result.status === 'approved') {
        // Mark phone as verified
        await supabaseClient
          .from('profiles')
          .update({ phone_verified: true })
          .eq('id', user.id);

        console.log(`✅ Phone verified: ${profile.phone_number}`);

        return new Response(
          JSON.stringify({ success: true, verified: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      } else {
        return new Response(
          JSON.stringify({ success: false, verified: false, message: 'Invalid code' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    } else {
      throw new Error('Invalid action');
    }
  } catch (error) {
    console.error('❌ Error in verify-phone:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
