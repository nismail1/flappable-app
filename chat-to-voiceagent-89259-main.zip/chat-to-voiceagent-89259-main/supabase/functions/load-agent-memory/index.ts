import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      console.error('❌ Authentication error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { agent_id } = await req.json();

    if (!agent_id) {
      console.error('❌ Missing agent_id');
      return new Response(
        JSON.stringify({ error: 'Missing agent_id' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`🧠 Loading memory for agent ${agent_id}, user ${user.id}`);

    // Fetch the most recent transcript
    const { data: transcripts, error } = await supabaseClient
      .from('agent_call_transcripts')
      .select('*')
      .eq('agent_id', agent_id)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) {
      console.error('❌ Database error:', error);
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!transcripts || transcripts.length === 0) {
      console.log('ℹ️ No previous conversations found');
      return new Response(
        JSON.stringify({ hasMemory: false }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const latestTranscript = transcripts[0];
    console.log(`✅ Found previous conversation: ${latestTranscript.summary}`);

    // Fetch agent config to get tone/personality
    const { data: agentData, error: agentError } = await supabaseClient
      .from('voice_agent_versions')
      .select('voice_name, agent_config')
      .eq('id', agent_id)
      .single();

    if (agentError) {
      console.error('❌ Error fetching agent config:', agentError);
    }

    // Rephrase the summary into a natural conversation opener
    let conversationalOpener = latestTranscript.summary;
    
    if (agentData) {
      try {
        const agentPersonality = agentData.agent_config?.personality || 'friendly and professional';
        const agentTone = agentData.agent_config?.tone || 'warm and conversational';
        
        const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
        
        const rephraseResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              {
                role: 'system',
                content: `You are rephrasing conversation summaries into natural, warm conversation openers. The agent's personality is: ${agentPersonality}. The agent's tone is: ${agentTone}. Transform the structured summary into a first-person, conversational greeting that sounds human and matches this personality. Keep it short (1-2 sentences).`
              },
              {
                role: 'user',
                content: `Rephrase this summary into a natural conversation opener: "${latestTranscript.summary}"`
              }
            ],
            temperature: 0.8,
            max_tokens: 100
          }),
        });

        if (rephraseResponse.ok) {
          const rephraseData = await rephraseResponse.json();
          conversationalOpener = rephraseData.choices[0]?.message?.content || latestTranscript.summary;
          console.log(`✨ Rephrased opener: ${conversationalOpener}`);
        } else {
          console.error('❌ Error rephrasing summary:', await rephraseResponse.text());
        }
      } catch (error) {
        console.error('❌ Failed to rephrase summary:', error);
      }
    }

    return new Response(
      JSON.stringify({
        hasMemory: true,
        summary: latestTranscript.summary,
        conversationalOpener: conversationalOpener,
        transcript: latestTranscript.transcript,
        created_at: latestTranscript.created_at,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Error in load-agent-memory:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
