import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Phone, Mic, MicOff, XCircle, Edit2, Check, X, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface PreviewPanelProps {
  voiceAgent: any;
  callStatus: "idle" | "connecting" | "connected" | "muted" | "ended" | "failed";
  isMuted: boolean;
  onTestVoice: () => void;
  onMuteToggle: () => void;
  onEndCall: () => void;
  logoUrl?: string | null;
  showLogoAnimation?: boolean;
  deployedAgentId: string | null;
}

export const PreviewPanel = ({
  voiceAgent,
  callStatus,
  isMuted,
  onTestVoice,
  onMuteToggle,
  onEndCall,
  logoUrl,
  showLogoAnimation,
  deployedAgentId,
}: PreviewPanelProps) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [editedName, setEditedName] = useState("");
  const [isSavingName, setIsSavingName] = useState(false);

  const handleSaveName = async () => {
    if (!editedName.trim()) {
      toast.error("Name cannot be empty");
      return;
    }
    setIsSavingName(true);
    try {
      // Get current session and validate it with the server
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        // Sign out and clear invalid session
        await supabase.auth.signOut();
        toast.error("Your session has expired. Please log in again.");
        window.location.href = '/auth';
        return;
      }

      // Try to verify the session is actually valid by making a test query
      const { error: testError } = await supabase.from('profiles').select('id').limit(1);
      
      if (testError?.message?.includes('JWT')) {
        // Session is invalid on server side
        await supabase.auth.signOut();
        toast.error("Your session has expired. Please log in again.");
        window.location.href = '/auth';
        return;
      }

      // Fetch existing agent_config from database first
      const { data: existingAgent, error: fetchError } = await supabase
        .from('voice_agent_versions')
        .select('agent_config')
        .eq('id', voiceAgent.id)
        .single();

      if (fetchError) {
        console.error("Error fetching existing config:", fetchError);
        throw fetchError;
      }

      const existingConfig = (existingAgent?.agent_config || {}) as any;

      // Construct full agent config with all required properties
      const updatedAgentDraft = {
        name: editedName.trim(),
        tone: existingConfig.tone || voiceAgent.tone,
        accent: existingConfig.accent || voiceAgent.accent,
        gender: existingConfig.gender || voiceAgent.gender,
        warmth: existingConfig.warmth || voiceAgent.warmth,
        creativity: existingConfig.creativity || voiceAgent.creativity,
        latency: existingConfig.latency || voiceAgent.latency,
        personality: existingConfig.personality || voiceAgent.personality,
        sampleLine: existingConfig.sampleLine || voiceAgent.sampleLine,
      };

      // Call edge function to update Vapi with the correct deployedAgentId
      const { data, error } = await supabase.functions.invoke('create-vapi-agent', {
        body: {
          agentDraft: updatedAgentDraft,
          briefMd: voiceAgent.prompt,
          deployedAgentId: deployedAgentId // Use prop instead of voiceAgent.vapi_agent_id
        }
      });

      if (error) {
        if (error.message?.includes('Unauthorized') || error.message?.includes('401')) {
          await supabase.auth.signOut();
          toast.error("Your session has expired. Please log in again.");
          window.location.href = '/auth';
          return;
        }
        throw error;
      }

      // Update Supabase with merged config (preserving all fields)
      const mergedConfig = {
        ...existingConfig,
        ...updatedAgentDraft
      };

      const { error: dbError } = await supabase
        .from('voice_agent_versions')
        .update({ agent_config: mergedConfig })
        .eq('id', voiceAgent.id);

      if (dbError) throw dbError;

      // Update local voiceAgent object
      voiceAgent.name = editedName.trim();
      setIsEditingName(false);
      toast.success("Agent name updated successfully");
    } catch (error) {
      console.error("Error updating name:", error);
      toast.error("Failed to update name. Please try again.");
    } finally {
      setIsSavingName(false);
    }
  };
  if (!voiceAgent) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/30">
        <div className="text-center space-y-4 p-8 max-w-md">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center mx-auto">
            <Phone className="w-10 h-10 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">No Agent Yet</h3>
            <p className="text-sm text-muted-foreground">
              Create a voice agent to see the preview and test it here
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-br from-background to-muted/30">
      {/* Logo Animation Overlay */}
      {showLogoAnimation && logoUrl && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-in">
          <div className="text-center space-y-6 animate-scale-in">
            <div className="relative">
              <div className="absolute inset-0 animate-ping">
                <div className="w-48 h-48 rounded-full bg-primary/20" />
              </div>
              <div className="relative w-48 h-48 rounded-full overflow-hidden bg-card shadow-2xl border-4 border-primary/20 animate-[spin_3s_ease-in-out]" style={{ animationIterationCount: 1 }}>
                <img 
                  src={logoUrl} 
                  alt={`${voiceAgent.name} logo`}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            <div className="space-y-2 animate-fade-in" style={{ animationDelay: '0.5s' }}>
              <h2 className="text-3xl font-bold text-foreground">{voiceAgent.name}</h2>
              <p className="text-lg text-muted-foreground">Your agent is ready!</p>
            </div>
          </div>
        </div>
      )}

      {/* Preview Header */}
      <div className="p-6 border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="text-center space-y-3">
          {logoUrl ? (
            <div className="inline-flex p-1 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10">
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-card shadow-lg">
                <img 
                  src={logoUrl} 
                  alt={`${voiceAgent.name} logo`}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          ) : (
            <div className="inline-flex p-3 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10">
              <Phone className="w-6 h-6 text-primary" />
            </div>
          )}
          
          {/* Agent Name with Inline Editing */}
          <div>
            {!isEditingName ? (
              <div className="flex items-center justify-center gap-2">
                <h2 className="text-xl font-bold text-foreground">{voiceAgent.name}</h2>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setEditedName(voiceAgent.name || "");
                    setIsEditingName(true);
                  }}
                  className="h-6 px-2 gap-1"
                >
                  <Edit2 className="w-3 h-3" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2">
                <Input
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className="h-8 max-w-xs text-sm text-center"
                  placeholder="Enter agent name"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleSaveName();
                    if (e.key === 'Escape') {
                      setIsEditingName(false);
                      setEditedName("");
                    }
                  }}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleSaveName}
                  disabled={isSavingName}
                  className="h-8 px-2"
                >
                  {isSavingName ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setIsEditingName(false);
                    setEditedName("");
                  }}
                  disabled={isSavingName}
                  className="h-8 px-2"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            )}
            {isEditingName && (
              <p className="text-xs text-muted-foreground mt-1">
                Saving the name will also update the name inside Vapi
              </p>
            )}
          </div>

          {/* Persona Info */}
          {voiceAgent.personality && (
            <div className="pt-2 space-y-1">
              <p className="text-xs font-medium text-muted-foreground">About this agent:</p>
              <p className="text-sm text-foreground italic">
                {voiceAgent.personality}
              </p>
            </div>
          )}
          
          {voiceAgent.sampleLine && (
            <div className="pt-2 space-y-1">
              <p className="text-xs font-medium text-muted-foreground">Opening Line:</p>
              <p className="text-sm text-foreground">
                "{voiceAgent.sampleLine}"
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Agent Details */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-md mx-auto space-y-6">
          {/* Test Controls */}
          <div className="space-y-3">
            <Button
              onClick={onTestVoice}
              disabled={callStatus !== "idle"}
              className="w-full gap-2 bg-gradient-to-r from-accent to-primary hover:shadow-lg transition-all h-14 text-base"
            >
              <Phone className="w-5 h-5" />
              Talk to Your Voice Agent
            </Button>

            {callStatus !== "idle" && (
              <Card className="p-4 bg-card/80 backdrop-blur-sm border-border">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">
                    {callStatus === "connecting" && "🎙️ Connecting..."}
                    {callStatus === "connected" && "🟢 Connected"}
                    {callStatus === "muted" && "🤫 Muted"}
                    {callStatus === "ended" && "🔴 Ended"}
                    {callStatus === "failed" && "⚠️ Failed"}
                  </span>
                  <div className="flex gap-2">
                    <Button onClick={onMuteToggle} variant="outline" size="sm">
                      {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                    <Button onClick={onEndCall} variant="destructive" size="sm">
                      <XCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
