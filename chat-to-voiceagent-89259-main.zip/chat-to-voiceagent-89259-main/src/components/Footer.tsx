const Footer = () => {
  return (
    <footer className="w-full border-t border-border/50 bg-background py-4 px-4 mt-auto">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-sm text-muted-foreground">
          <div className="text-center md:text-left">
            <p>© 2025 Bell AI Fellowship. Building the future of voice-first AI.</p>
            <p className="text-xs mt-1">Powered by Vapi, Twilio, and SimpleTexting.</p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <a 
              href="mailto:contact@bellaifellow.com" 
              className="hover:text-foreground transition-colors"
            >
              contact@bellaifellow.com
            </a>
            <span className="hidden md:inline">|</span>
            <a 
              href="https://www.aughthour.com/privacy.html" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-foreground transition-colors"
            >
              Privacy
            </a>
            <a 
              href="https://www.aughthour.com/terms.html" 
              target="_blank" 
              rel="noopener noreferrer"
              className="hover:text-foreground transition-colors"
            >
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
