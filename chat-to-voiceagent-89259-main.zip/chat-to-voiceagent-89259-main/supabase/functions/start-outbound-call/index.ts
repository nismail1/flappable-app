import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🚀 Starting outbound call request');

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Authenticate user
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      console.error('❌ Authentication failed:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ User authenticated:', user.id);

    // Parse request body
    const { agent_id } = await req.json();

    if (!agent_id) {
      return new Response(
        JSON.stringify({ error: 'Missing agent_id' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('📞 Initiating call for agent:', agent_id);

    // Get user's verified phone number from profiles
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('phone_number, phone_verified')
      .eq('id', user.id)
      .single();

    if (profileError || !profile) {
      console.error('❌ Error fetching profile:', profileError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch user profile' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const hasVerifiedPhone = profile.phone_verified && profile.phone_number;

    // Get agent's vapi_agent_id and phone_number_id from voice_agent_versions
    const { data: agentVersion, error: agentError } = await supabaseClient
      .from('voice_agent_versions')
      .select('vapi_agent_id, phone_number_id')
      .eq('id', agent_id)
      .eq('user_id', user.id)
      .single();

    if (agentError || !agentVersion) {
      console.log('⚠️ Missing configuration for outbound call: Agent not found');
      console.error('❌ Error fetching agent version:', agentError);
      return new Response(
        JSON.stringify({ 
          error: 'Please verify your phone number in Settings and assign a phone number to this agent in Vapi before testing outbound calls.' 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if all required configuration exists
    if (!hasVerifiedPhone) {
      console.log('⚠️ Phone number not verified');
      return new Response(
        JSON.stringify({ 
          error: 'Please verify your phone number in Settings before testing outbound calls. Click "Verify Phone in Settings" to get started.',
          action: 'verify_phone'
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!agentVersion.vapi_agent_id) {
      console.log('⚠️ Vapi agent ID missing');
      return new Response(
        JSON.stringify({ 
          error: 'This agent has not been created in Vapi yet. Please try regenerating the agent.' 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!agentVersion.phone_number_id) {
      console.log('⚠️ Phone number not assigned to agent');
      return new Response(
        JSON.stringify({ 
          error: 'Please assign a phone number to this agent in the Configuration page before testing outbound calls.' 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Phone number verified:', profile.phone_number);
    console.log('✅ Vapi agent ID:', agentVersion.vapi_agent_id);
    console.log('✅ Phone number ID:', agentVersion.phone_number_id);

    // Call Vapi Create Call API
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      console.error('❌ VAPI_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'Vapi API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const vapiCallPayload = {
      assistantId: agentVersion.vapi_agent_id,
      phoneNumberId: agentVersion.phone_number_id,
      customer: {
        number: profile.phone_number,
      },
    };

    console.log('📤 Calling Vapi API with payload:', vapiCallPayload);

    const vapiResponse = await fetch('https://api.vapi.ai/call/phone', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(vapiCallPayload),
    });

    const vapiResult = await vapiResponse.json();

    if (!vapiResponse.ok) {
      console.error('❌ Vapi API error:', vapiResult);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to initiate call via Vapi', 
          details: vapiResult 
        }),
        { status: vapiResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Call initiated successfully:', vapiResult);

    return new Response(
      JSON.stringify({ 
        success: true, 
        call_id: vapiResult.id,
        message: 'Outbound call initiated successfully'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('❌ Error in start-outbound-call function:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
