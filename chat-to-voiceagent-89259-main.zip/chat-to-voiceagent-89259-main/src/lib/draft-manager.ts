export interface DraftData {
  timestamp: number;
  userPrompt: string;
  iterationInput?: string;
  iterationHistory: Array<{
    type: "user" | "system";
    content: string;
    timestamp: string; // ISO string format
  }>;
  voiceAgent?: {
    name: string;
    tone: string | string[];
    accent: string;
    gender?: string;
    warmth: number;
    creativity: number;
    latency: string;
    personality: string;
    sampleLine: string;
    version: string;
  };
  brief?: string;
  agentLogoUrl?: string;
  deployedAgentId?: string;
}

const DRAFT_KEY = "voice-agent-draft";
const DRAFT_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

export const saveDraft = (draftData: Partial<DraftData>): boolean => {
  try {
    const draft: DraftData = {
      timestamp: Date.now(),
      userPrompt: draftData.userPrompt || "",
      iterationInput: draftData.iterationInput,
      iterationHistory: draftData.iterationHistory || [],
      voiceAgent: draftData.voiceAgent,
      brief: draftData.brief,
      agentLogoUrl: draftData.agentLogoUrl,
      deployedAgentId: draftData.deployedAgentId,
    };

    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    return true;
  } catch (error) {
    console.error("Failed to save draft:", error);
    if (error instanceof Error && error.name === "QuotaExceededError") {
      console.error("localStorage quota exceeded");
    }
    return false;
  }
};

export const loadDraft = (): DraftData | null => {
  try {
    const draftJson = localStorage.getItem(DRAFT_KEY);
    if (!draftJson) return null;

    const draft: DraftData = JSON.parse(draftJson);

    // Check if draft has expired
    const age = Date.now() - draft.timestamp;
    if (age > DRAFT_EXPIRY_MS) {
      clearDraft();
      return null;
    }

    return draft;
  } catch (error) {
    console.error("Failed to load draft:", error);
    clearDraft(); // Clear corrupted draft
    return null;
  }
};

export const clearDraft = (): void => {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch (error) {
    console.error("Failed to clear draft:", error);
  }
};

export const hasDraft = (): boolean => {
  return !!loadDraft();
};

// SessionStorage backup for auth flow persistence
const SESSION_DRAFT_KEY = "voice-agent-session-draft";

export const backupDraftToSession = (): boolean => {
  try {
    const draft = loadDraft();
    if (draft) {
      sessionStorage.setItem(SESSION_DRAFT_KEY, JSON.stringify(draft));
      console.log("✅ Draft backed up to sessionStorage");
      return true;
    }
    return false;
  } catch (error) {
    console.error("Failed to backup draft to sessionStorage:", error);
    return false;
  }
};

export const loadDraftFromSession = (): DraftData | null => {
  try {
    const draftJson = sessionStorage.getItem(SESSION_DRAFT_KEY);
    if (!draftJson) return null;

    const draft: DraftData = JSON.parse(draftJson);
    console.log("✅ Draft loaded from sessionStorage");
    return draft;
  } catch (error) {
    console.error("Failed to load draft from sessionStorage:", error);
    return null;
  }
};

export const clearSessionDraft = (): void => {
  try {
    sessionStorage.removeItem(SESSION_DRAFT_KEY);
    console.log("✅ Session draft cleared");
  } catch (error) {
    console.error("Failed to clear session draft:", error);
  }
};

export const loadDraftFromEither = (): DraftData | null => {
  return loadDraft() || loadDraftFromSession();
};
