-- Add calendar_enabled column to voice_agent_versions
ALTER TABLE voice_agent_versions
ADD COLUMN IF NOT EXISTS calendar_enabled boolean NOT NULL DEFAULT false;

-- Add google_calendar_connected column to profiles
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS google_calendar_connected boolean NOT NULL DEFAULT false;