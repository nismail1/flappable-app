import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fixed demo phone number
const DEMO_PHONE_NUMBER_ID = "49736548-f65c-46b5-a4e7-ac19ba4ed995";

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const authHeader = req.headers.get('Authorization')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    // Get the user from the auth header
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      console.error('❌ Auth error:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ User authenticated:', user.id);

    const { agentId } = await req.json();

    if (!agentId) {
      return new Response(
        JSON.stringify({ error: 'Missing agentId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('📞 Unassigning demo phone number from agent:', agentId);

    // Verify the agent belongs to this user
    const { data: agentData, error: fetchError } = await supabase
      .from('voice_agent_versions')
      .select('id, phone_number_id')
      .eq('id', agentId)
      .eq('user_id', user.id)
      .maybeSingle();

    if (fetchError || !agentData) {
      console.error('❌ Agent not found or unauthorized:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Agent not found or unauthorized' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (agentData.phone_number_id !== DEMO_PHONE_NUMBER_ID) {
      console.log('⚠️ Agent does not have the demo phone number assigned');
      return new Response(
        JSON.stringify({ error: 'Agent does not have a phone number assigned' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Remove the phone number from Vapi by setting assistantId to null
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      console.error('❌ VAPI_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'Vapi API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('📞 Removing assistant from Vapi phone number');

    const vapiResponse = await fetch(
      `https://api.vapi.ai/phone-number/${DEMO_PHONE_NUMBER_ID}`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${vapiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          assistantId: null,
        }),
      }
    );

    if (!vapiResponse.ok) {
      const vapiError = await vapiResponse.json();
      console.error('❌ Vapi phone number update failed:', vapiError);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to unassign phone number in Vapi',
          details: vapiError 
        }),
        { status: vapiResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Phone number unassigned in Vapi');

    // Remove the phone number from the agent in the database
    const { error: updateError } = await supabase
      .from('voice_agent_versions')
      .update({
        phone_number_id: null,
        phone_number: null,
      })
      .eq('id', agentId)
      .eq('user_id', user.id);

    if (updateError) {
      console.error('❌ Failed to update agent:', updateError);
      return new Response(
        JSON.stringify({ error: 'Failed to unassign phone number' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Demo phone number unassigned successfully');

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Phone number unassigned successfully'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in unassign-demo-phone-number function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
