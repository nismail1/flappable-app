import { useState, useMemo, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, RefreshCw, Upload } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

interface AgentIterationProps {
  currentAgent: {
    id?: string;
    name: string;
    tone: string | string[];
    accent: string;
    warmth: number;
    creativity: number;
    latency: string;
    personality: string;
    sampleLine: string;
    gender?: string;
    vapi_agent_id?: string;
  };
  onUpdateAgent: (instruction: string) => Promise<void>;
  isUpdating?: boolean;
  onIterationInputChange?: (input: string) => void;
  initialIterationInput?: string;
}

const generateDynamicSuggestions = (agent: AgentIterationProps['currentAgent']): string[] => {
  const suggestions: string[] = [];
  
  // Warmth-based suggestions
  if (agent.warmth < 50) {
    suggestions.push("Make the agent more warm and empathetic");
  } else if (agent.warmth > 80) {
    suggestions.push("Make the tone more professional and less casual");
  }
  
  // Creativity-based suggestions
  if (agent.creativity < 50) {
    suggestions.push("Increase creativity for more dynamic responses");
  } else if (agent.creativity > 80) {
    suggestions.push("Make responses more structured and predictable");
  }
  
  // Latency-based suggestions
  if (agent.latency === "natural" || agent.latency === "slow") {
    suggestions.push("Speed up response time for faster interactions");
  } else if (agent.latency === "fast") {
    suggestions.push("Make responses more thoughtful with natural pacing");
  }
  
  // Gender-based suggestions
  if (agent.gender === "male") {
    suggestions.push("Switch to a female voice");
  } else if (agent.gender === "female") {
    suggestions.push("Switch to a male voice");
  }
  
  // Accent suggestions based on current accent
  const currentAccent = agent.accent?.toLowerCase() || "";
  if (!currentAccent.includes("british") && !currentAccent.includes("uk")) {
    suggestions.push("Add a British accent");
  }
  if (!currentAccent.includes("australian")) {
    suggestions.push("Try an Australian accent");
  }
  if (!currentAccent.includes("american") && !currentAccent.includes("neutral")) {
    suggestions.push("Switch to American accent");
  }
  
  // Tone-based suggestions
  const tones = Array.isArray(agent.tone) ? agent.tone : [agent.tone];
  if (!tones.some(t => t?.toLowerCase().includes("confident"))) {
    suggestions.push("Make the agent sound more confident and authoritative");
  }
  if (!tones.some(t => t?.toLowerCase().includes("friendly"))) {
    suggestions.push("Add a more friendly and approachable tone");
  }
  
  // Always include some general suggestions
  suggestions.push("Make the opening line more engaging");
  suggestions.push("Adjust personality to be more conversational");
  
  // Return up to 6 suggestions
  return suggestions.slice(0, 6);
};

export const AgentIteration = ({ 
  currentAgent, 
  onUpdateAgent, 
  isUpdating = false,
  onIterationInputChange,
  initialIterationInput = "",
}: AgentIterationProps) => {
  const [iterationInput, setIterationInput] = useState(initialIterationInput);
  const [dailyReminderEnabled, setDailyReminderEnabled] = useState(false);
  const [postCallSummaryEnabled, setPostCallSummaryEnabled] = useState(false);
  const [calendarEnabled, setCalendarEnabled] = useState(false);
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Update local state when initialIterationInput changes (e.g., from draft restoration)
  useEffect(() => {
    if (initialIterationInput) {
      setIterationInput(initialIterationInput);
    }
  }, [initialIterationInput]);
  
  const suggestions = useMemo(() => 
    generateDynamicSuggestions(currentAgent), 
    [currentAgent]
  );

  // Load agent notification settings
  useEffect(() => {
    const loadAgentSettings = async () => {
      if (!currentAgent.id) return;
      
      const { data: agentData } = await supabase
        .from('voice_agent_versions')
        .select('daily_reminder_enabled, post_call_summary_enabled, calendar_enabled')
        .eq('id', currentAgent.id)
        .single();
      
      if (agentData) {
        setDailyReminderEnabled(agentData.daily_reminder_enabled || false);
        setPostCallSummaryEnabled(agentData.post_call_summary_enabled || false);
        setCalendarEnabled(agentData.calendar_enabled || false);
      }
    };
    
    loadAgentSettings();
  }, [currentAgent.id]);

  const handleIterate = async () => {
    if (!iterationInput.trim()) {
      toast.error("Please describe what you'd like to change");
      return;
    }

    await onUpdateAgent(iterationInput);
    setIterationInput("");
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const vapiAgentId = currentAgent.vapi_agent_id;
    if (!vapiAgentId) {
      toast.error("Agent not deployed yet. Please create the agent first.");
      return;
    }

    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/csv',
      'text/markdown'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast.error("Please upload a PDF, DOCX, TXT, CSV, or Markdown file");
      return;
    }

    setIsUploadingFile(true);
    
    try {
      // Step 1: Upload file to Vapi
      const formData = new FormData();
      formData.append('file', file);

      console.log('📤 Uploading file to Vapi...');
      const uploadResponse = await fetch(
        `${SUPABASE_URL}/functions/v1/upload-knowledge-file`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
          },
          body: formData
        }
      );

      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text();
        console.error('❌ Upload error response:', errorText);
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { error: 'Upload failed' };
        }
        throw new Error(errorData.error || 'Upload failed');
      }

      const uploadData = await uploadResponse.json();
      const { fileId } = uploadData;
      console.log('✅ File uploaded to Vapi:', fileId);

      // Step 2: Create knowledge base tool
      console.log('🔧 Creating knowledge base tool...');
      const toolResponse = await supabase.functions.invoke('create-kb-tool', {
        body: {
          fileIds: [fileId],
          kbName: `${currentAgent.name || 'Agent'} Knowledge Base`,
          kbDescription: `Knowledge base for ${currentAgent.name || 'agent'} containing uploaded documents`
        }
      });

      if (toolResponse.error) {
        console.error('❌ Tool creation error:', toolResponse.error);
        throw new Error(toolResponse.error.message);
      }

      const { toolId } = toolResponse.data;
      console.log('✅ Tool created:', toolId);

      // Step 3: Attach tool to assistant
      console.log('🔗 Attaching tool to assistant...');
      const attachResponse = await supabase.functions.invoke('attach-kb-tool', {
        body: {
          assistantId: vapiAgentId,
          toolId: toolId
        }
      });

      if (attachResponse.error) {
        console.error('❌ Tool attachment error:', attachResponse.error);
        throw new Error(attachResponse.error.message);
      }

      console.log('✅ Tool attached to assistant');

      // Step 4: Save file metadata to database
      console.log('💾 Saving file metadata to database...');
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) {
        throw new Error('User not authenticated');
      }

      const { error: dbError } = await supabase.from('knowledge_files').insert({
        user_id: userData.user.id,
        agent_id: currentAgent.id,
        vapi_file_id: fileId,
        vapi_tool_id: toolId,
        file_name: file.name,
        file_size: file.size,
        file_type: file.type
      });

      if (dbError) {
        console.error('❌ Database error:', dbError);
        throw new Error('Failed to save file metadata');
      }

      console.log('✅ File metadata saved to database');
      toast.success(`✨ ${file.name} uploaded! Your agent can now answer questions using this document.`);

    } catch (error) {
      console.error('❌ File upload error:', error);
      toast.error("Failed to upload file. Please try again.");
    } finally {
      setIsUploadingFile(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setIterationInput(suggestion);
  };

  const handleNotificationChipClick = async (type: 'reminders' | 'summaries') => {
    // Check if user is authenticated
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Not available in trial mode");
      return;
    }
    
    if (!currentAgent.id) {
      toast.error("Agent configuration not found");
      return;
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('phone_number, phone_verified')
      .eq('id', user.id)
      .single();

    const hasVerifiedPhone = profile?.phone_verified && profile?.phone_number;

    if (!hasVerifiedPhone) {
      // Navigate to settings page if no verified phone
      window.location.href = '/settings?focus=phone';
      return;
    }

    // If verified phone exists, enable the feature on this agent
    if (type === 'reminders') {
      const { error } = await supabase
        .from('voice_agent_versions')
        .update({ daily_reminder_enabled: true })
        .eq('id', currentAgent.id);
      
      if (!error) {
        toast.success("Daily reminder enabled for 12:00 PM PT.");
        setDailyReminderEnabled(true);
      }
    } else {
      const { error } = await supabase
        .from('voice_agent_versions')
        .update({ post_call_summary_enabled: true })
        .eq('id', currentAgent.id);
      
      if (!error) {
        toast.success("We'll text you a summary after each call.");
        setPostCallSummaryEnabled(true);
      }
    }
  };

  const handleCalendarChipClick = async () => {
    // Check if user is authenticated
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Not available in trial mode");
      return;
    }
    
    if (!currentAgent.id) {
      toast.error("Agent configuration not found");
      return;
    }

    // Check if user is logged in with Google
    const { data: { session } } = await supabase.auth.getSession();
    const isGoogleUser = session?.user?.app_metadata?.provider === 'google' || 
                         session?.user?.app_metadata?.providers?.includes('google');

    if (!isGoogleUser) {
      // Prompt to sign in with Google
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          scopes: 'openid email profile https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events',
          redirectTo: window.location.origin + window.location.pathname,
        },
      });
      
      if (error) {
        toast.error("Failed to connect with Google");
      }
      return;
    }

    // Enable calendar for this agent
    try {
      const { error } = await supabase.functions.invoke('enable-agent-calendar', {
        body: { agentId: currentAgent.id }
      });

      if (error) {
        toast.error("Failed to enable Google Calendar");
      } else {
        toast.success("Google Calendar enabled ✓");
        setCalendarEnabled(true);
      }
    } catch (error) {
      toast.error("Failed to enable Google Calendar");
    }
  };

  return (
    <Card className="p-6 bg-card border border-border rounded-2xl shadow-lg space-y-6">
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-gradient-to-br from-primary/10 to-accent/10">
            <RefreshCw className="w-5 h-5 text-primary" />
          </div>
          <h3 className="text-xl font-bold text-foreground">Refine Your Agent</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          Describe how you'd like to improve your agent
        </p>
      </div>

      {/* Suggestions - Horizontally Scrollable */}
      <div className="relative">
        <div className="overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent">
          <div className="flex gap-2 min-w-max">
            {/* Static notification chips - show if not enabled */}
            {!dailyReminderEnabled && (
              <Badge
                variant="outline"
                className="cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-all px-3 py-1.5 whitespace-nowrap text-xs font-normal"
                onClick={() => handleNotificationChipClick('reminders')}
              >
                Set up a daily reminder
              </Badge>
            )}
            {!postCallSummaryEnabled && (
              <Badge
                variant="outline"
                className="cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-all px-3 py-1.5 whitespace-nowrap text-xs font-normal"
                onClick={() => handleNotificationChipClick('summaries')}
              >
                Enable post-call text summary
              </Badge>
            )}
            {!calendarEnabled && (
              <Badge
                variant="outline"
                className="cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-all px-3 py-1.5 whitespace-nowrap text-xs font-normal"
                onClick={handleCalendarChipClick}
              >
                Connect Google Calendar
              </Badge>
            )}
            
            {/* Dynamic suggestions */}
            {suggestions.map((suggestion, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer hover:bg-primary/10 hover:border-primary/40 transition-all px-3 py-1.5 whitespace-nowrap text-xs font-normal"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                {suggestion}
              </Badge>
            ))}
          </div>
        </div>
      </div>

      {/* Iteration Input */}
      <div className="space-y-3">
        <Textarea
          value={iterationInput}
          onChange={(e) => {
            setIterationInput(e.target.value);
            onIterationInputChange?.(e.target.value);
          }}
          placeholder="Example: Make the agent sound more enthusiastic and energetic, with a faster response time..."
          className="min-h-[120px] resize-none"
          disabled={isUpdating}
        />

        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.docx,.txt,.csv,.md"
            onChange={handleFileUpload}
            className="hidden"
          />
          <Button
            onClick={() => fileInputRef.current?.click()}
            variant="outline"
            disabled={isUploadingFile || isUpdating}
            className="gap-2"
            title="Upload business file to agent knowledge base"
          >
            {isUploadingFile ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                Upload File
              </>
            )}
          </Button>
          <Button
            onClick={handleIterate}
            disabled={isUpdating || !iterationInput.trim()}
            className="flex-1 gap-2 bg-gradient-to-r from-primary to-accent hover:shadow-md transition-all shadow-sm"
          >
            {isUpdating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Updating Agent...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Apply Changes
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
};
