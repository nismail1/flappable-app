import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Loader2, Sparkles, Send } from "lucide-react";
import { AgentIteration } from "./AgentIteration";
import { HeadAssemblyAnimation } from "./HeadAssemblyAnimation";
import { InspirationAgents } from "./InspirationAgents";
import type { User } from "@supabase/supabase-js";

interface ChatPanelProps {
  onCreateAgent: (prompt: string) => void;
  isGenerating: boolean;
  hasAgent: boolean;
  currentAgent: any;
  onUpdateAgent: (instruction: string) => Promise<void>;
  isUpdating: boolean;
  iterationHistory?: Array<{
    type: "user" | "system";
    content: string;
    timestamp: Date;
  }>;
  user?: User | null;
  onPromptChange?: (prompt: string) => void;
  initialPrompt?: string;
  onIterationInputChange?: (input: string) => void;
  initialIterationInput?: string;
}

export const ChatPanel = ({
  onCreateAgent,
  isGenerating,
  hasAgent,
  currentAgent,
  onUpdateAgent,
  isUpdating,
  iterationHistory = [],
  user,
  onPromptChange,
  initialPrompt = "",
  onIterationInputChange,
  initialIterationInput = "",
}: ChatPanelProps) => {
  const [userPrompt, setUserPrompt] = useState(initialPrompt);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const userHasEditedRef = useRef(false);

  // Sync initialPrompt changes into the textarea (for draft restoration)
  useEffect(() => {
    console.log("🔍 ChatPanel initialPrompt changed:", {
      initialPrompt,
      currentUserPrompt: userPrompt,
      userHasEdited: userHasEditedRef.current,
      isEmpty: !initialPrompt || initialPrompt.trim().length === 0
    });

    // Only update if user hasn't manually edited and initialPrompt is non-empty
    if (!userHasEditedRef.current && initialPrompt && initialPrompt.trim().length > 0) {
      console.log("✨ Setting userPrompt to:", initialPrompt);
      setUserPrompt(initialPrompt);
      console.log("✅ userPrompt updated successfully");
    } else {
      console.log("⏭️ Skipping update - userHasEdited:", userHasEditedRef.current, "isEmpty:", !initialPrompt || initialPrompt.trim().length === 0);
    }
  }, [initialPrompt]);
  
  console.log("📊 ChatPanel render - initialPrompt:", initialPrompt, "userPrompt:", userPrompt);

  const allSuggestionPrompts = [
    "Create a friendly customer support agent for an e-commerce store",
    "Build a personal fitness coach that motivates and tracks workouts",
    "Design a professional receptionist for a medical office",
    "Create a storytelling agent that tells bedtime stories for kids",
    "Make a calm and patient technical support specialist",
    "Design a meal planning assistant that suggests recipes based on preferences",
    "Create a scheduling assistant for a busy consultancy",
    "Build a mental health check-in companion with an empathetic tone",
    "Design an enthusiastic sales agent for a tech startup",
    "Create a travel planning companion that helps book trips",
    "Make a language learning tutor that practices conversations",
    "Design a meditation guide with a soothing, calming voice",
    "Build a book recommendation agent that discusses literature",
    "Create a homework helper for middle school students",
    "Build a personal stylist that gives fashion advice",
    "Design a nutrition advisor that answers diet questions",
    "Make a movie and TV show recommendation expert",
    "Create a sleep coach that helps establish better sleep habits",
    "Build a science explainer that makes complex topics simple",
    "Create a gaming buddy that discusses strategies and tips",
    "Design a history storyteller that brings events to life",
    "Make a daily motivation and affirmation speaker",
    "Make a math tutor that explains problems step-by-step",
  ];

  // Select 4 random suggestions on component mount or when switching to landing mode
  useEffect(() => {
    if (!hasAgent) {
      const shuffled = [...allSuggestionPrompts].sort(() => Math.random() - 0.5);
      setSuggestions(shuffled.slice(0, 4));
    }
  }, [hasAgent]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [iterationHistory]);

  const handleSubmit = () => {
    if (!userPrompt.trim()) return;
    onCreateAgent(userPrompt);
    setUserPrompt("");
  };

  const handleSuggestionClick = (suggestion: string) => {
    setUserPrompt(suggestion);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Landing page mode - clean and centered
  if (!hasAgent) {
    // Show animation while generating
    if (isGenerating) {
      return <HeadAssemblyAnimation />;
    }

    return (
      <div className="space-y-6">
        {/* Show inspiration agents for non-authenticated users */}
        {!user && <InspirationAgents />}

        {/* Large input area */}
        <Card className="p-6 bg-card/80 backdrop-blur-sm border-border shadow-lg">
          <Textarea
            value={userPrompt}
            onChange={(e) => {
              setUserPrompt(e.target.value);
              userHasEditedRef.current = true; // Mark as manually edited
              onPromptChange?.(e.target.value);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Describe your ideal voice agent... What's the vibe? Who's it for? What should it do?"
            className="min-h-[120px] text-base resize-none bg-background border-border"
            disabled={isGenerating}
          />
          <div className="mt-4 flex justify-end">
            <Button
              onClick={handleSubmit}
              disabled={isGenerating || !userPrompt.trim()}
              size="lg"
              className="gap-2 bg-gradient-to-r from-primary to-accent hover:shadow-lg transition-all"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Creating Your Agent...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Create Agent
                </>
              )}
            </Button>
          </div>
        </Card>

        {/* Suggestion buttons */}
        {!isGenerating && suggestions.length > 0 && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground text-center">Or try one of these:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {suggestions.map((suggestion, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-auto py-4 px-4 text-left justify-start hover:bg-primary/10 hover:border-primary hover:text-foreground transition-all"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  <div className="flex items-start gap-3 w-full">
                    <Sparkles className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
                    <span className="text-sm font-normal whitespace-normal break-words">{suggestion}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Split view mode - when agent exists
  return (
    <div className="h-full flex flex-col bg-muted/30">
      {/* Chat Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Show iteration history */}
        <div className="space-y-3">
          {iterationHistory.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"} animate-fade-in`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-4 shadow-sm ${
                  message.type === "user"
                    ? "bg-primary text-primary-foreground rounded-tr-sm"
                    : "bg-card border border-border text-foreground rounded-tl-sm"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>
                <p className={`text-xs mt-2 ${message.type === "user" ? "opacity-80" : "text-muted-foreground"}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Agent Iteration Component */}
        <AgentIteration
          currentAgent={currentAgent}
          onUpdateAgent={onUpdateAgent}
          isUpdating={isUpdating}
          onIterationInputChange={onIterationInputChange}
          initialIterationInput={initialIterationInput}
        />
      </div>
    </div>
  );
};
