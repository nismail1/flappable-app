import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";

export const HeadAssemblyAnimation = () => {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setStep((prev) => (prev + 1) % 5);
    }, 800);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center space-y-6 py-12">
      <h2 className="text-2xl font-bold text-foreground">Creating Your Voice Agent</h2>
      
      {/* Head Assembly Animation */}
      <div className="relative w-48 h-48 flex items-center justify-center">
        {/* Base Circle - Face */}
        <div
          className={`absolute w-32 h-32 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 border-2 border-primary/30 transition-all duration-500 ${
            step >= 0 ? "opacity-100 scale-100" : "opacity-0 scale-50"
          }`}
        />

        {/* Eyes */}
        <div
          className={`absolute top-12 left-10 w-3 h-3 rounded-full bg-primary transition-all duration-500 ${
            step >= 1 ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
          }`}
        />
        <div
          className={`absolute top-12 right-10 w-3 h-3 rounded-full bg-primary transition-all duration-500 ${
            step >= 1 ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
          }`}
        />

        {/* Nose */}
        <div
          className={`absolute top-16 left-1/2 -translate-x-1/2 w-1.5 h-4 bg-primary/60 rounded-full transition-all duration-500 ${
            step >= 2 ? "opacity-100 scale-100" : "opacity-0 scale-0"
          }`}
        />

        {/* Mouth - smile curve */}
        <div
          className={`absolute bottom-14 left-1/2 -translate-x-1/2 w-12 h-6 border-b-2 border-primary rounded-b-full transition-all duration-500 ${
            step >= 3 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        />

        {/* Headphones/Audio waves */}
        <div
          className={`absolute -left-6 top-8 w-8 h-16 border-4 border-accent rounded-l-full transition-all duration-500 ${
            step >= 4 ? "opacity-100 -translate-x-0" : "opacity-0 -translate-x-4"
          }`}
        />
        <div
          className={`absolute -right-6 top-8 w-8 h-16 border-4 border-accent rounded-r-full transition-all duration-500 ${
            step >= 4 ? "opacity-100 translate-x-0" : "opacity-0 translate-x-4"
          }`}
        />

        {/* Sound waves animation */}
        {step >= 4 && (
          <>
            <div className="absolute -left-12 top-12 w-2 h-6 bg-accent/40 rounded-full animate-pulse" />
            <div className="absolute -left-16 top-10 w-2 h-10 bg-accent/30 rounded-full animate-pulse delay-100" />
            <div className="absolute -right-12 top-12 w-2 h-6 bg-accent/40 rounded-full animate-pulse delay-75" />
            <div className="absolute -right-16 top-10 w-2 h-10 bg-accent/30 rounded-full animate-pulse delay-150" />
          </>
        )}

        {/* Sparkles */}
        {step >= 4 && (
          <>
            <div className="absolute top-2 left-8 w-1 h-1 bg-primary rounded-full animate-ping" />
            <div className="absolute top-4 right-6 w-1 h-1 bg-accent rounded-full animate-ping delay-200" />
            <div className="absolute bottom-6 left-12 w-1 h-1 bg-primary rounded-full animate-ping delay-300" />
          </>
        )}
      </div>

      {/* Progress Text */}
      <div className="space-y-2 text-center">
        <p className="text-sm text-muted-foreground animate-pulse">
          {step === 0 && "Building personality..."}
          {step === 1 && "Configuring voice..."}
          {step === 2 && "Tuning tone..."}
          {step === 3 && "Adding character..."}
          {step === 4 && "Almost ready..."}
        </p>
        
        {/* Progress dots */}
        <div className="flex gap-2 justify-center">
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                i <= step ? "bg-primary scale-100" : "bg-border scale-75"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
