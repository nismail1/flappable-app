import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Play, Check, RefreshCw, Loader2, Send } from "lucide-react";

interface VoiceAgentPreviewProps {
  version: string;
  name: string;
  tone: string;
  accent: string;
  warmth: number;
  creativity: number;
  latency: string;
  personality: string;
  sampleLine: string;
  onAccept?: () => void;
  onRegenerate?: () => void;
  onPlaySample?: () => void;
  onEditVoice?: (instruction: string) => void;
  isGenerating?: boolean;
  isPlayingAudio?: boolean;
}

export const VoiceAgentPreview = ({
  version,
  name,
  tone,
  accent,
  warmth,
  creativity,
  latency,
  personality,
  sampleLine,
  onAccept,
  onRegenerate,
  onPlaySample,
  onEditVoice,
  isGenerating = false,
  isPlayingAudio = false,
}: VoiceAgentPreviewProps) => {
  const [editInstruction, setEditInstruction] = useState("");

  const handleSubmitEdit = () => {
    if (editInstruction.trim() && onEditVoice) {
      onEditVoice(editInstruction);
      setEditInstruction("");
    }
  };

  return (
    <Card className="p-6 bg-gradient-to-br from-card to-secondary border-2 border-primary/20 shadow-lg">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-2xl font-bold text-foreground">{name}</h3>
              <Badge variant="outline" className="text-xs">
                {version}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{personality}</p>
          </div>
        </div>

        {/* Voice Characteristics */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Tone</p>
            <p className="text-sm font-medium">{tone}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Accent</p>
            <p className="text-sm font-medium">{accent}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Warmth</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                  style={{ width: `${warmth}%` }}
                />
              </div>
              <span className="text-sm font-medium">{warmth}/100</span>
            </div>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Creativity</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-primary to-accent transition-all"
                  style={{ width: `${creativity}%` }}
                />
              </div>
              <span className="text-sm font-medium">{creativity}/100</span>
            </div>
          </div>
        </div>

        <div>
          <p className="text-xs text-muted-foreground mb-1">Latency</p>
          <p className="text-sm font-medium">{latency}</p>
        </div>

        {/* Sample Line */}
        <div className="p-4 bg-secondary/50 rounded-lg border border-border">
          <p className="text-xs text-muted-foreground mb-2">Opening line</p>
          <p className="text-sm italic">"{sampleLine}"</p>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={onAccept}
            className="flex-1 gap-2 bg-gradient-to-r from-primary to-primary-glow hover:shadow-glow"
            disabled={isGenerating}
          >
            {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Save Voice Agent
          </Button>
          <Button onClick={onRegenerate} variant="outline" size="icon" disabled={isGenerating}>
            <RefreshCw className={`w-4 h-4 ${isGenerating ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </div>
    </Card>
  );
};
