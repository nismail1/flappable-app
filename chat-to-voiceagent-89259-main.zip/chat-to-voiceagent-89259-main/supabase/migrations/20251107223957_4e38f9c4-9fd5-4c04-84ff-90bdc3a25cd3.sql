-- Create published_agents table for shareable voice agents
CREATE TABLE public.published_agents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  share_id TEXT NOT NULL UNIQUE,
  user_id UUID NOT NULL,
  agent_config JSONB NOT NULL,
  vapi_agent_id TEXT,
  brief TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  views_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX idx_published_agents_share_id ON public.published_agents(share_id);
CREATE INDEX idx_published_agents_user_id ON public.published_agents(user_id);

-- Enable Row Level Security
ALTER TABLE public.published_agents ENABLE ROW LEVEL SECURITY;

-- Anyone can view active published agents
CREATE POLICY "Published agents are viewable by everyone"
ON public.published_agents
FOR SELECT
USING (is_active = true);

-- Users can insert their own published agents
CREATE POLICY "Users can publish their own agents"
ON public.published_agents
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own published agents
CREATE POLICY "Users can update their own published agents"
ON public.published_agents
FOR UPDATE
USING (auth.uid() = user_id);

-- Users can delete their own published agents
CREATE POLICY "Users can delete their own published agents"
ON public.published_agents
FOR DELETE
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_published_agents_updated_at
BEFORE UPDATE ON public.published_agents
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();