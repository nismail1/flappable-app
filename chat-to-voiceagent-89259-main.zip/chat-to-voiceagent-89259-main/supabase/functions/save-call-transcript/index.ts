import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    // For trial mode users, allow the request but skip database save
    const isAuthenticated = !authError && user;

    const requestBody = await req.json();
    
    // Handle both direct transcript format (web) and Vapi webhook format (phone)
    let transcript;
    let effectiveAgentId;
    let session_id;
    
    if (requestBody.message?.type === 'end-of-call-report') {
      // Vapi webhook format
      console.log('📞 Processing Vapi webhook end-of-call-report');
      effectiveAgentId = requestBody.message.call?.assistantId;
      session_id = requestBody.message.call?.id;
      
      // Vapi sends messages with "message" field, map to "content"
      transcript = requestBody.message.artifact?.messages?.map((msg: any) => ({
        role: msg.role,
        content: msg.message || msg.content // Support both formats
      })) || [];
    } else {
      // Direct format (web interface)
      const { agent_id, vapi_agent_id, session_id: sid, transcript: trans } = requestBody;
      effectiveAgentId = agent_id || vapi_agent_id;
      session_id = sid;
      transcript = trans;
    }

    console.log(`📦 Webhook payload type: ${requestBody.message?.type || 'direct'}`);
    console.log(`📝 Transcript messages count: ${transcript?.length || 0}`);

    if (!effectiveAgentId || !session_id || !transcript || !Array.isArray(transcript)) {
      console.error('❌ Missing required fields');
      return new Response(
        JSON.stringify({ error: 'Missing agent_id/vapi_agent_id, session_id, or transcript' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`💾 Processing transcript for agent ${effectiveAgentId}, session ${session_id}`);
    console.log(`🔐 Authentication status: ${isAuthenticated ? 'authenticated' : 'trial mode'}`);

    // Generate summary using Lovable AI
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    const transcriptText = transcript
      .map((msg: any) => `${msg.role}: ${msg.content}`)
      .join('\n');

    console.log('🤖 Generating summary with AI...');
    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          {
            role: 'system',
            content: 'You are a conversation summarizer. Create a concise 2-3 sentence summary of the conversation that captures the main topics and outcomes. Keep it brief and natural.'
          },
          {
            role: 'user',
            content: `Summarize this voice conversation:\n\n${transcriptText}`
          }
        ],
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('❌ AI Gateway error:', aiResponse.status, errorText);
      throw new Error('Failed to generate summary');
    }

    const aiData = await aiResponse.json();
    const summary = aiData.choices?.[0]?.message?.content || 'Conversation completed.';

    console.log(`📝 Summary generated: ${summary.substring(0, 100)}...`);

    // Save to database only if user is authenticated
    let transcriptId = null;
    let calendarEventLink = null;
    
    if (isAuthenticated && user) {
      const { data, error } = await supabaseClient
        .from('agent_call_transcripts')
        .insert({
          agent_id: effectiveAgentId,
          user_id: user.id,
          session_id,
          transcript,
          summary,
        })
        .select()
        .single();

      if (error) {
        console.error('❌ Database error:', error);
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log('✅ Transcript saved to database, ID:', data.id);
      transcriptId = data.id;
      
      // Check if calendar is enabled for this agent
      try {
        const { data: agentData } = await supabaseClient
          .from('voice_agent_versions')
          .select('calendar_enabled, id, user_id')
          .or(`id.eq.${effectiveAgentId},vapi_agent_id.eq.${effectiveAgentId}`)
          .maybeSingle();

        if (agentData?.calendar_enabled) {
          console.log('📅 Calendar enabled, checking for appointment...');
          
          // Detect appointment from transcript
          const appointmentResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${LOVABLE_API_KEY}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              model: 'google/gemini-2.5-flash',
              messages: [
                {
                  role: 'system',
                  content: 'You are an appointment detector. Extract whether the user and agent agreed on a specific appointment. Return strictly JSON with no markdown formatting.'
                },
                {
                  role: 'user',
                  content: `Extract appointment details from this conversation. 

CURRENT DATE AND TIME CONTEXT:
- Today is ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'America/Chicago' })}
- Current year is 2025
- If a date is mentioned without a year, assume it refers to 2025
- If a date appears to be in the past based on current date, interpret it as the next future occurrence

Return JSON like:
{
  "hasAppointment": boolean,
  "summary": string,
  "startDateTime": string (ISO format) or null,
  "endDateTime": string (ISO format) or null,
  "description": string or null
}

IMPORTANT: 
- Always use year 2025 unless explicitly specified otherwise
- If you detect an appointment, you MUST provide both startDateTime AND endDateTime
- If the user mentions a duration (e.g., "30 minutes", "an hour", "2 hours"), calculate endDateTime as startDateTime + duration
- If NO duration is mentioned, default to 1 hour (endDateTime = startDateTime + 1 hour)
- Both dates must be in ISO 8601 format (e.g., "2025-11-20T13:00:00")
- Never return null for endDateTime if hasAppointment is true

Conversation:
${transcriptText}`
                }
              ],
            }),
          });

          if (appointmentResponse.ok) {
            const appointmentData = await appointmentResponse.json();
            const appointmentText = appointmentData.choices?.[0]?.message?.content || '{}';
            console.log('🤖 AI appointment detection response:', appointmentText.substring(0, 300));
            
            try {
              // Parse JSON, removing markdown code blocks if present
              const cleanedText = appointmentText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
              const appointment = JSON.parse(cleanedText);
              console.log('📋 Parsed appointment:', JSON.stringify(appointment));

              if (appointment.hasAppointment && appointment.startDateTime && appointment.endDateTime) {
                console.log('📅 Appointment detected, creating calendar event...');
                
                // Create calendar event
                const calendarResponse = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/add-calendar-event`, {
                  method: 'POST',
                  headers: {
                    'Authorization': req.headers.get('Authorization')!,
                    'Content-Type': 'application/json',
                  },
                  body: JSON.stringify({
                    summary: appointment.summary,
                    description: appointment.description,
                    startDateTime: appointment.startDateTime,
                    endDateTime: appointment.endDateTime,
                    agentId: agentData.id || effectiveAgentId,
                    userId: agentData.user_id,
                  }),
                });

                if (calendarResponse.ok) {
                  const calendarData = await calendarResponse.json();
                  console.log('✅ Calendar event created:', calendarData.eventId);
                  calendarEventLink = calendarData.htmlLink;
                } else {
                  const errorText = await calendarResponse.text();
                  console.log('❌ Failed to create calendar event:', errorText);
                }
              } else {
                console.log('ℹ️ No appointment detected or missing required fields:', {
                  hasAppointment: appointment.hasAppointment,
                  hasStartTime: !!appointment.startDateTime,
                  hasEndTime: !!appointment.endDateTime
                });
              }
            } catch (parseError) {
              const errorMsg = parseError instanceof Error ? parseError.message : String(parseError);
              console.log('❌ Failed to parse appointment JSON:', errorMsg, 'Raw text:', appointmentText);
            }
          } else {
            const errorText = await appointmentResponse.text();
            console.log('❌ Appointment detection AI call failed:', appointmentResponse.status, errorText);
          }
        }
      } catch (calendarError) {
        console.error('❌ Error handling calendar event:', calendarError);
        // Don't fail the whole request if calendar fails
      }

      console.log('✅ Transcript and summary saved to database');
      return new Response(
        JSON.stringify({ 
          success: true, 
          summary, 
          transcript_id: transcriptId,
          calendarEventLink
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else {
      // Trial mode: return summary without saving to database
      console.log('✅ Summary generated for trial mode user (not saved to database)');
      return new Response(
        JSON.stringify({ success: true, summary, transcript_id: null }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    console.error('❌ Error in save-call-transcript:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
