import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Get the authenticated user
    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      console.error('❌ Authentication error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { agent_id, messages } = await req.json();

    if (!agent_id || !messages || !Array.isArray(messages)) {
      console.error('❌ Missing required fields:', { agent_id, messages: !!messages });
      return new Response(
        JSON.stringify({ error: 'Missing agent_id or messages' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`💾 Saving conversation for agent ${agent_id}, user ${user.id}, ${messages.length} messages`);

    // Check if conversation exists
    const { data: existingConversation } = await supabaseClient
      .from('agent_conversations')
      .select('id')
      .eq('agent_id', agent_id)
      .eq('user_id', user.id)
      .maybeSingle();

    let result;
    if (existingConversation) {
      // Update existing conversation
      console.log(`📝 Updating conversation ${existingConversation.id}`);
      result = await supabaseClient
        .from('agent_conversations')
        .update({
          messages,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existingConversation.id)
        .select()
        .single();
    } else {
      // Create new conversation
      console.log('✨ Creating new conversation');
      result = await supabaseClient
        .from('agent_conversations')
        .insert({
          agent_id,
          user_id: user.id,
          messages,
        })
        .select()
        .single();
    }

    if (result.error) {
      console.error('❌ Database error:', result.error);
      return new Response(
        JSON.stringify({ error: result.error.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Conversation saved successfully');
    return new Response(
      JSON.stringify({ success: true, conversation_id: result.data.id }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Error in save-agent-conversation:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
