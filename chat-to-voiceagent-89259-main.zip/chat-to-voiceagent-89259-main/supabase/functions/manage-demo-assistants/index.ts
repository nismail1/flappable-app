import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const DEMO_ASSISTANTS = [
  {
    name: "Morning Coach",
    voiceId: "Lily",
    systemMessage: "You are the Morning Coach — a warm, upbeat voice that motivates users to start their day strong. Keep responses brief and encouraging.",
    firstMessage: "Hi there! I'm your Morning Coach — ready to start strong today?"
  },
  {
    name: "Focus Companion",
    voiceId: "Paige",
    systemMessage: "You are the Focus Companion — a calm, grounding voice that helps users stay centered and productive throughout their day. Keep responses brief and calming.",
    firstMessage: "Take a deep breath. I'm your Focus Companion, here to help you stay centered."
  },
  {
    name: "Travel Planner",
    voiceId: "Spencer",
    systemMessage: "You are the Travel Planner — a witty, upbeat voice that suggests exciting travel ideas and helps plan adventures. Keep responses brief and enthusiastic.",
    firstMessage: "Hey there! I'm your Travel Planner — ready to explore somewhere amazing?"
  }
];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const VAPI_API_KEY = Deno.env.get('VAPI_API_KEY');
    if (!VAPI_API_KEY) {
      throw new Error('VAPI_API_KEY not configured');
    }

    console.log('Fetching existing assistants from Vapi...');
    
    // Get all existing assistants
    const listResponse = await fetch('https://api.vapi.ai/assistant', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${VAPI_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!listResponse.ok) {
      throw new Error(`Failed to list assistants: ${listResponse.statusText}`);
    }

    const existingAssistants = await listResponse.json();
    console.log(`Found ${existingAssistants.length} existing assistants`);

    const results = [];

    // For each demo assistant, check if it exists or create it
    for (const demo of DEMO_ASSISTANTS) {
      const existing = existingAssistants.find((a: any) => a.name === demo.name);

      if (existing) {
        console.log(`Demo assistant "${demo.name}" already exists with ID: ${existing.id}`);
        results.push({
          name: demo.name,
          assistantId: existing.id,
          created: false,
        });
      } else {
        console.log(`Creating demo assistant "${demo.name}"...`);
        
        const createResponse = await fetch('https://api.vapi.ai/assistant', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${VAPI_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: demo.name,
            model: {
              provider: 'openai',
              model: 'gpt-4o-mini',
              messages: [
                {
                  role: 'system',
                  content: demo.systemMessage,
                },
              ],
            },
            voice: {
              provider: 'vapi',
              voiceId: demo.voiceId,
            },
            firstMessage: demo.firstMessage,
          }),
        });

        if (!createResponse.ok) {
          const errorText = await createResponse.text();
          throw new Error(`Failed to create assistant "${demo.name}": ${errorText}`);
        }

        const created = await createResponse.json();
        console.log(`Created demo assistant "${demo.name}" with ID: ${created.id}`);
        
        results.push({
          name: demo.name,
          assistantId: created.id,
          created: true,
        });
      }
    }

    return new Response(
      JSON.stringify({ success: true, assistants: results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error managing demo assistants:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
