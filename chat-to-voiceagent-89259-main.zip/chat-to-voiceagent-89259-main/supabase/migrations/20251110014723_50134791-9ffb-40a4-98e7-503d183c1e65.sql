-- Add phone verification fields to profiles
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS phone_number TEXT,
ADD COLUMN IF NOT EXISTS phone_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS receive_daily_reminders BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS receive_post_call_summaries BOOLEAN DEFAULT false;

-- Create reminders table
CREATE TABLE IF NOT EXISTS public.reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  agent_id UUID REFERENCES public.voice_agent_versions(id) ON DELETE CASCADE NOT NULL,
  time_of_day TEXT DEFAULT '12:00' NOT NULL,
  frequency TEXT DEFAULT 'daily' NOT NULL,
  is_active BOOLEAN DEFAULT true NOT NULL,
  last_sent_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE(user_id, agent_id)
);

-- Enable RLS on reminders
ALTER TABLE public.reminders ENABLE ROW LEVEL SECURITY;

-- RLS policies for reminders
CREATE POLICY "Users can view their own reminders"
ON public.reminders
FOR SELECT
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE id = user_id));

CREATE POLICY "Users can insert their own reminders"
ON public.reminders
FOR INSERT
WITH CHECK (auth.uid() IN (SELECT id FROM public.profiles WHERE id = user_id));

CREATE POLICY "Users can update their own reminders"
ON public.reminders
FOR UPDATE
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE id = user_id));

CREATE POLICY "Users can delete their own reminders"
ON public.reminders
FOR DELETE
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE id = user_id));