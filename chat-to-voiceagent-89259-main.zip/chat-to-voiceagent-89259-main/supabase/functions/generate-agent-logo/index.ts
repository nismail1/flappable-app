import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract user from JWT token (optional for trial mode)
    const authHeader = req.headers.get('Authorization');
    let userId = null;

    if (authHeader) {
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      
      const supabase = createClient(supabaseUrl, supabaseServiceKey, {
        global: {
          headers: { Authorization: authHeader },
        },
      });

      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (!userError && user) {
        userId = user.id;
        console.log(`👤 Authenticated User ID: ${userId}`);
      }
    } else {
      console.log("🌐 Anonymous user - trial mode");
    }

    const { agentName, agentPersonality, tone, accent } = await req.json();

    if (!agentName) {
      return new Response(
        JSON.stringify({ error: 'Agent name is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create a detailed prompt for logo generation
    const logoPrompt = `Create a modern, minimalist logo icon for an AI voice agent named "${agentName}". 
The logo should be:
- Simple and iconic, suitable for a voice assistant
- Professional and friendly
- Use soft, vibrant colors with gradients
- Abstract representation of voice, AI, or communication
- Style: ${tone?.join(', ') || 'professional, friendly'}
- Personality: ${agentPersonality || 'helpful and engaging'}
- Accent/theme: ${accent || 'universal'}
- NO text or letters, just the icon
- Clean, modern design suitable for app icon
- Centered on white or transparent background
- Round or circular composition`;

    console.log('Generating logo with prompt:', logoPrompt);

    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!lovableApiKey) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    // Call Lovable AI to generate the image
    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash-image-preview',
        messages: [
          {
            role: 'user',
            content: logoPrompt
          }
        ],
        modalities: ['image', 'text']
      })
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('Lovable AI error:', errorText);
      throw new Error(`Failed to generate logo: ${aiResponse.statusText}`);
    }

    const aiData = await aiResponse.json();
    console.log('Lovable AI response received');

    const logoBase64 = aiData.choices?.[0]?.message?.images?.[0]?.image_url?.url;

    if (!logoBase64) {
      throw new Error('No image generated from AI');
    }

    console.log('Logo generated successfully');

    return new Response(
      JSON.stringify({ 
        success: true,
        logoUrl: logoBase64
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in generate-agent-logo:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
