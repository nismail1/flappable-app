-- Add logo_url field to store agent logos
ALTER TABLE public.voice_agent_versions
ADD COLUMN IF NOT EXISTS logo_url TEXT;

ALTER TABLE public.published_agents
ADD COLUMN IF NOT EXISTS logo_url TEXT;