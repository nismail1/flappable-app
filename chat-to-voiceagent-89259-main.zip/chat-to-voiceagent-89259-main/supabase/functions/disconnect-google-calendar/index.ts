import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    console.log(`🔓 Disconnecting Google Calendar for user: ${user.id}`);

    // Get user's Google provider token to revoke it
    const { data: userData } = await supabaseAdmin.auth.admin.getUserById(user.id);
    const googleIdentity = userData?.user?.identities?.find(
      (identity: any) => identity.provider === 'google'
    );

    if (googleIdentity?.identity_data?.provider_token) {
      const accessToken = googleIdentity.identity_data.provider_token;
      
      // Revoke the Google token
      try {
        const revokeResponse = await fetch(
          `https://oauth2.googleapis.com/revoke?token=${accessToken}`,
          { method: 'POST' }
        );
        
        if (revokeResponse.ok) {
          console.log('✅ Google token revoked successfully');
        } else {
          console.log('⚠️ Failed to revoke Google token, but continuing...');
        }
      } catch (revokeError) {
        console.error('Error revoking Google token:', revokeError);
        // Continue anyway to update database
      }
    }

    // Delete stored tokens from database
    const { error: deleteError } = await supabaseAdmin
      .from('user_google_tokens')
      .delete()
      .eq('user_id', user.id);

    if (deleteError) {
      console.error('Error deleting stored tokens:', deleteError);
    } else {
      console.log('✅ Stored tokens deleted from database');
    }

    // Update profile to mark Google Calendar as disconnected
    const { error: profileError } = await supabase
      .from('profiles')
      .update({ google_calendar_connected: false })
      .eq('id', user.id);

    if (profileError) {
      throw new Error('Failed to update profile');
    }

    // Disable calendar for all user's agents
    const { error: agentsError } = await supabase
      .from('voice_agent_versions')
      .update({ calendar_enabled: false })
      .eq('user_id', user.id);

    if (agentsError) {
      console.error('Error disabling calendar for agents:', agentsError);
      // Don't throw, this is non-critical
    }

    console.log('✅ Google Calendar disconnected successfully');

    return new Response(
      JSON.stringify({ success: true, message: 'Google Calendar disconnected' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in disconnect-google-calendar:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
