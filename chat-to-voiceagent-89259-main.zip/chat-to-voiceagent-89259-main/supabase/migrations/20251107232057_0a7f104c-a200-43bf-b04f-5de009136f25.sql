-- Fix profile data exposure by restricting RLS policy
-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON public.profiles;

-- Create restricted policy: users can only view their own profile
CREATE POLICY "Users can view own profile" ON public.profiles
FOR SELECT 
USING (auth.uid() = id);

-- Add author_display_name to published_agents so we don't need to query profiles
ALTER TABLE public.published_agents 
ADD COLUMN IF NOT EXISTS author_display_name TEXT;

-- Backfill existing published agents with display names
UPDATE public.published_agents pa
SET author_display_name = p.display_name
FROM public.profiles p
WHERE pa.user_id = p.id AND pa.author_display_name IS NULL;