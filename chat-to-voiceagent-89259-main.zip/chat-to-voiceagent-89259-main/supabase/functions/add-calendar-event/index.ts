import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    {
      global: {
        headers: { Authorization: req.headers.get('Authorization')! },
      },
    }
  );

    const { summary, description, startDateTime, endDateTime, agentId, userId, timezone = 'America/Chicago' } = await req.json();
    
    console.log(`📥 Received calendar event request for agentId: ${agentId}, userId: ${userId}`);
    
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'Missing userId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!summary || !startDateTime || !endDateTime || !agentId) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: summary, startDateTime, endDateTime, agentId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify calendar is enabled for this agent
    // Support both database UUID and Vapi agent ID
    const { data: agentData, error: agentError } = await supabase
      .from('voice_agent_versions')
      .select('calendar_enabled')
      .or(`id.eq.${agentId},vapi_agent_id.eq.${agentId}`)
      .maybeSingle();

    console.log('🔍 Agent lookup result:', { agentData, agentError, searchedAgentId: agentId });
    
    if (agentError) {
      console.error('❌ Agent lookup error:', agentError);
    }
    if (!agentData) {
      console.log(`❌ No agent found with id or vapi_agent_id matching: ${agentId}`);
    }
    if (agentData) {
      console.log(`✅ Found agent with calendar_enabled: ${agentData.calendar_enabled}`);
    }

    if (agentError || !agentData) {
      return new Response(
        JSON.stringify({ error: 'Agent not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!agentData.calendar_enabled) {
      return new Response(
        JSON.stringify({ error: 'Calendar not enabled for this agent' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Use Admin API to access user_google_tokens
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );
    
    // Retrieve stored Google tokens
    const { data: tokenData, error: tokenError } = await supabaseAdmin
      .from('user_google_tokens')
      .select('access_token, refresh_token, token_expiry')
      .eq('user_id', userId)
      .maybeSingle();

    if (tokenError || !tokenData) {
      console.error('Failed to retrieve Google tokens:', tokenError);
      return new Response(
        JSON.stringify({ error: 'No Google access token available. Please reconnect your Google account.' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let accessToken = tokenData.access_token;
    const refreshToken = tokenData.refresh_token;
    const tokenExpiry = tokenData.token_expiry ? new Date(tokenData.token_expiry) : null;

    console.log('✅ Retrieved Google tokens from database');

    // Check if token is expired and refresh if needed
    if (tokenExpiry && tokenExpiry < new Date()) {
      console.log('🔄 Access token expired, refreshing...');
      
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: Deno.env.get('GOOGLE_CLIENT_ID'),
          client_secret: Deno.env.get('GOOGLE_CLIENT_SECRET'),
          refresh_token: refreshToken,
          grant_type: 'refresh_token',
        }),
      });

      if (!tokenResponse.ok) {
        const errorText = await tokenResponse.text();
        console.error('Token refresh failed:', errorText);
        throw new Error('Failed to refresh access token');
      }

      const newTokenData = await tokenResponse.json();
      accessToken = newTokenData.access_token;
      
      // Update stored token
      await supabaseAdmin
        .from('user_google_tokens')
        .update({
          access_token: newTokenData.access_token,
          token_expiry: new Date(Date.now() + 3600 * 1000).toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', userId);
      
      console.log('✅ Access token refreshed and updated in database');
    }

    // Create Google Calendar event
    // Validate dates before attempting to create event
    const startDate = new Date(startDateTime);
    const endDate = new Date(endDateTime);
    const now = new Date();

    if (startDate < now) {
      console.error('❌ Start date is in the past:', startDateTime);
      return new Response(
        JSON.stringify({ 
          error: 'Cannot create calendar event in the past',
          startDateTime,
          currentTime: now.toISOString()
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (endDate <= startDate) {
      console.error('❌ End date is not after start date');
      return new Response(
        JSON.stringify({ error: 'End date must be after start date' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const calendarEvent = {
      summary,
      description: description || '',
      start: {
        dateTime: startDateTime,
        timeZone: timezone,
      },
      end: {
        dateTime: endDateTime,
        timeZone: timezone,
      },
    };

    console.log('Creating calendar event:', calendarEvent);

    const calendarResponse = await fetch(
      'https://www.googleapis.com/calendar/v3/calendars/primary/events',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(calendarEvent),
      }
    );

    // If we get a 401, try refreshing the token once
    if (calendarResponse.status === 401 && refreshToken) {
      console.log('Access token expired, refreshing...');
      const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          client_id: Deno.env.get('GOOGLE_CLIENT_ID'),
          client_secret: Deno.env.get('GOOGLE_CLIENT_SECRET'),
          refresh_token: refreshToken,
          grant_type: 'refresh_token',
        }),
      });

      if (tokenResponse.ok) {
        const tokenData = await tokenResponse.json();
        accessToken = tokenData.access_token;

        // Retry the calendar request with new token
        const retryResponse = await fetch(
          'https://www.googleapis.com/calendar/v3/calendars/primary/events',
          {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${accessToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(calendarEvent),
          }
        );

        if (!retryResponse.ok) {
          const errorText = await retryResponse.text();
          console.error('Calendar event creation failed after token refresh:', errorText);
          throw new Error('Failed to create calendar event');
        }

        const eventData = await retryResponse.json();
        return new Response(
          JSON.stringify({
            success: true,
            eventId: eventData.id,
            htmlLink: eventData.htmlLink,
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    if (!calendarResponse.ok) {
      const errorText = await calendarResponse.text();
      console.error('❌ Calendar event creation failed');
      console.error('Status:', calendarResponse.status);
      console.error('Error body:', errorText);
      
      // Try to parse error for more details
      try {
        const errorJson = JSON.parse(errorText);
        console.error('Parsed error:', JSON.stringify(errorJson, null, 2));
      } catch (e) {
        // Error is not JSON, already logged as text
      }
      
      throw new Error(`Failed to create calendar event: ${errorText}`);
    }

    const eventData = await calendarResponse.json();

    return new Response(
      JSON.stringify({
        success: true,
        eventId: eventData.id,
        htmlLink: eventData.htmlLink,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in add-calendar-event:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
