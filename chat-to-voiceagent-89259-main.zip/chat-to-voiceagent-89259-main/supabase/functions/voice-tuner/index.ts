import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { editInstruction, currentAgent } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    console.log('Tuning voice with instruction:', editInstruction);

    const systemPrompt = `You are a voice agent parameter tuner. Given the current agent and edit instruction, return ONLY a JSON Patch array in a code fence.

Available fields:
- tone (array): ["warm", "playful", "friendly", "casual", "formal", "energetic", "calm", "empathetic", "professional"]
- accent (string): "american", "british", "canadian", "australian", "indian american", "asian american", "southern american"
- gender (string): "male" or "female"
- warmth (number 0-100): friendliness/approachability (higher = friendlier)
- creativity (number 0-100): conversational variety (higher = more creative)
- latency (string): "fast" or "natural" or "slow"
- consent (string): "strict" or "gentle" or "auto_proceed"
- sampleLine (string): opening line
- personality (string): description of personality/behavior
- startSpeakingPlan.waitSeconds (number 0.1-3.0): how long to wait before responding (higher = less interruption)

Current: ${JSON.stringify(currentAgent)}

Natural language interpretation rules:

RESPONSE TIMING (affects startSpeakingPlan.waitSeconds only, NOT voice or personality):
- "wait longer", "pause more", "don't interrupt", "be slower to respond", "let me finish" → increase startSpeakingPlan/waitSeconds by 0.3-0.5
- "respond faster", "be quicker", "don't wait so long" → decrease startSpeakingPlan/waitSeconds by 0.3-0.5

PERSONALITY/BEHAVIOR (affects tone/personality only, NOT voice):
- "be more supportive", "more encouraging" → add "empathetic" to tone, update personality
- "act like a mentor", "be more guiding" → update personality field
- "sound more curious", "ask more questions" → update personality field
- "be more professional", "more formal" → add "professional"/"formal" to tone
- "be more friendly", "warmer" → increase warmth by 15-20, add "friendly" to tone

VOICE CHARACTERISTICS (only change if explicitly requested):
- "British accent", "English accent" → set accent to "british"
- "American accent", "US accent" → set accent to "american"
- "female voice", "woman's voice" → set gender to "female"
- "male voice", "man's voice" → set gender to "male"

IMPORTANT:
- Only change fields that match the user's request
- For timing feedback ("wait longer", "don't interrupt"), ONLY change startSpeakingPlan/waitSeconds
- For personality feedback ("be more supportive"), ONLY change tone/personality, NOT voice/gender/accent
- Don't change voice characteristics unless explicitly requested

Return ONLY a JSON Patch array. Use "replace" for existing fields:
\`\`\`json
[
  { "op": "replace", "path": "/startSpeakingPlan/waitSeconds", "value": 1.2 },
  { "op": "replace", "path": "/personality", "value": "A supportive mentor who..." }
]
\`\`\`

No other text.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: editInstruction }
        ],
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const completion = await response.json();
    const content = completion.choices[0]?.message?.content || "[]";
    
    // Extract JSON patch array from markdown code fence
    const patchRegex = /```json([\s\S]*?)```/m;
    const match = patchRegex.exec(content);
    
    if (!match) {
      console.error('❌ No JSON patch found in text:', content);
      return new Response(JSON.stringify({ error: 'No JSON patch found' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let patch;
    try {
      patch = JSON.parse(match[1].trim());
    } catch (err) {
      console.error('❌ Invalid JSON patch syntax:', err);
      return new Response(JSON.stringify({ error: 'Invalid JSON patch' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Validate patch is an array
    if (!Array.isArray(patch)) {
      console.error('❌ Patch must be a JSON array of operations');
      return new Response(JSON.stringify({ error: 'Patch must be an array' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Applied patch:', JSON.stringify(patch));

    return new Response(JSON.stringify({ patch }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error tuning voice:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
