import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Fixed demo phone number for all agents
const DEMO_PHONE_NUMBER_ID = "49736548-f65c-46b5-a4e7-ac19ba4ed995";
const DEMO_PHONE_NUMBER = "+19842419653";

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const authHeader = req.headers.get('Authorization')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    // Get the user from the auth header
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      console.error('❌ Auth error:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ User authenticated:', user.id);

    const { agentId } = await req.json();

    if (!agentId) {
      return new Response(
        JSON.stringify({ error: 'Missing agentId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('📞 Assigning demo phone number to agent:', agentId);

    // Verify the agent belongs to this user and fetch vapi_agent_id
    const { data: agentData, error: fetchError } = await supabase
      .from('voice_agent_versions')
      .select('id, vapi_agent_id')
      .eq('id', agentId)
      .eq('user_id', user.id)
      .maybeSingle();

    if (fetchError || !agentData) {
      console.error('❌ Agent not found or unauthorized:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Agent not found or unauthorized' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!agentData.vapi_agent_id) {
      console.error('❌ Agent not deployed to Vapi yet');
      return new Response(
        JSON.stringify({ error: 'Agent must be deployed before assigning a phone number' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update the phone number in Vapi to route to this assistant
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      console.error('❌ VAPI_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'Vapi API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('📞 Updating Vapi phone number to route to assistant:', agentData.vapi_agent_id);

    const vapiResponse = await fetch(
      `https://api.vapi.ai/phone-number/${DEMO_PHONE_NUMBER_ID}`,
      {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${vapiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          assistantId: agentData.vapi_agent_id,
        }),
      }
    );

    if (!vapiResponse.ok) {
      const vapiError = await vapiResponse.json();
      console.error('❌ Vapi phone number update failed:', vapiError);
      return new Response(
        JSON.stringify({ 
          error: 'Failed to configure phone number in Vapi',
          details: vapiError 
        }),
        { status: vapiResponse.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Phone number configured in Vapi');

    // Update the agent with the demo phone number
    const { error: updateError } = await supabase
      .from('voice_agent_versions')
      .update({
        phone_number_id: DEMO_PHONE_NUMBER_ID,
        phone_number: DEMO_PHONE_NUMBER,
      })
      .eq('id', agentId)
      .eq('user_id', user.id);

    if (updateError) {
      console.error('❌ Failed to update agent:', updateError);
      return new Response(
        JSON.stringify({ error: 'Failed to assign phone number' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Demo phone number assigned successfully');

    return new Response(
      JSON.stringify({
        phoneNumberId: DEMO_PHONE_NUMBER_ID,
        phoneNumber: DEMO_PHONE_NUMBER,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in assign-demo-phone-number function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
