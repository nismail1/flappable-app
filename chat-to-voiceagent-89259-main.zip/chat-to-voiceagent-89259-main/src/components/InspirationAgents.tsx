import { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Play, Loader2 } from "lucide-react";
import { toast } from "sonner";
import Vapi from "@vapi-ai/web";
import { supabase } from "@/integrations/supabase/client";
interface InspirationAgent {
  name: string;
  description: string;
  tone: string;
  sampleLine: string;
}
interface DemoAssistant {
  name: string;
  assistantId?: string;
}
const inspirationAgents: InspirationAgent[] = [{
  name: "Morning Coach",
  description: "Helps you start your day with affirmations and motivation",
  tone: "warm, encouraging, confident",
  sampleLine: "Good morning! Today is going to be amazing. Let's set some intentions together."
}, {
  name: "Focus Companion",
  description: "Helps users stay centered and productive throughout the day",
  tone: "calm, minimalist, grounding",
  sampleLine: "Take a deep breath. Let's focus on what matters most right now."
}, {
  name: "Travel Planner",
  description: "Suggests new travel ideas and helps plan adventures",
  tone: "witty, upbeat, adventurous",
  sampleLine: "Ready to explore somewhere new? I've got some exciting destinations in mind!"
}];
export const InspirationAgents = () => {
  const [demoAssistants, setDemoAssistants] = useState<DemoAssistant[]>([]);
  const [loadingAssistants, setLoadingAssistants] = useState(false);
  const [playingAgent, setPlayingAgent] = useState<string | null>(null);
  const vapiRef = useRef<Vapi | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  useEffect(() => {
    // Initialize demo assistants on mount
    initializeDemoAssistants();
    return () => {
      // Cleanup on unmount
      if (vapiRef.current) {
        vapiRef.current.stop();
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);
  const initializeDemoAssistants = async () => {
    setLoadingAssistants(true);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('manage-demo-assistants');
      if (error) throw error;
      if (data?.success && data?.assistants) {
        setDemoAssistants(data.assistants);
        console.log('Demo assistants initialized:', data.assistants);
      }
    } catch (error) {
      console.error('Error initializing demo assistants:', error);
      toast.error('Could not load demo assistants');
    } finally {
      setLoadingAssistants(false);
    }
  };
  const handlePreviewVoice = async (agent: InspirationAgent) => {
    if (playingAgent) {
      toast.info('Please wait for the current preview to finish');
      return;
    }

    // Find the assistant ID for this agent
    const demoAssistant = demoAssistants.find(da => da.name === agent.name || da.name === `The ${agent.name}`);
    if (!demoAssistant?.assistantId) {
      toast.error('Preview not available yet — please refresh the page');
      return;
    }
    console.log('🎧 Preview starting for', agent.name, 'with ID:', demoAssistant.assistantId);
    setPlayingAgent(agent.name);
    try {
      // Get the public key - try both possible env var names
      const publicKey = import.meta.env.VITE_VAPI_PUBLIC_KEY || import.meta.env.VITE_VAPI_API_KEY;
      if (!publicKey) {
        console.error('❌ No Vapi public key found in environment variables');
        throw new Error('Vapi public key not configured. Please add VITE_VAPI_PUBLIC_KEY to your environment.');
      }
      console.log('✅ Vapi public key found, initializing SDK...');

      // Create new Vapi instance for this preview
      vapiRef.current = new Vapi(publicKey);

      // Add event listeners for debugging
      vapiRef.current.on('call-start', () => {
        console.log('✅ Call started successfully');
      });
      vapiRef.current.on('speech-start', () => {
        console.log('🔊 Speech started');
      });
      vapiRef.current.on('speech-end', () => {
        console.log('🔇 Speech ended');
      });
      vapiRef.current.on('error', (error: any) => {
        console.error('❌ Vapi error:', error);
      });

      // Start the call with proper configuration
      console.log('Starting call with assistant:', demoAssistant.assistantId);
      await vapiRef.current.start(demoAssistant.assistantId);
      console.log('✅ Preview playback success for:', agent.name);

      // Auto-stop after 10 seconds
      timeoutRef.current = setTimeout(() => {
        console.log('⏱️ Auto-stopping preview after timeout');
        if (vapiRef.current) {
          vapiRef.current.stop();
          setPlayingAgent(null);
          toast.success('✨ Want your own voice agent like this? Click Create Agent to start.', {
            duration: 5000
          });
        }
      }, 10000);
    } catch (error: any) {
      console.error('❌ Error playing preview:', error);
      console.error('Error details:', {
        message: error?.message,
        stack: error?.stack,
        response: error?.response
      });
      const errorMessage = error?.message || "Couldn't load preview — please try again";
      toast.error(errorMessage);
      setPlayingAgent(null);
      if (vapiRef.current) {
        try {
          vapiRef.current.stop();
        } catch (stopError) {
          console.error('Error stopping Vapi:', stopError);
        }
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    }
  };
  return <div className="space-y-4">
      
      
      
    </div>;
};
