-- Add per-agent notification settings to voice_agent_versions
ALTER TABLE voice_agent_versions 
ADD COLUMN IF NOT EXISTS daily_reminder_enabled boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS post_call_summary_enabled boolean DEFAULT false;