-- Add phone number columns to voice_agent_versions table
ALTER TABLE voice_agent_versions
ADD COLUMN IF NOT EXISTS phone_number TEXT,
ADD COLUMN IF NOT EXISTS phone_number_id TEXT;