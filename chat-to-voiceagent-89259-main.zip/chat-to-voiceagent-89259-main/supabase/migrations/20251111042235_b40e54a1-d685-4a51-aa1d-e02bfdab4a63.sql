-- Add vapi_phone_number_id column to voice_agent_versions table
ALTER TABLE voice_agent_versions 
ADD COLUMN IF NOT EXISTS vapi_phone_number_id text;