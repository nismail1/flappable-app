import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Input validation
const validateMessages = (data: any) => {
  if (!data.messages || !Array.isArray(data.messages)) {
    throw new Error("messages must be an array");
  }
  if (data.messages.length > 100) {
    throw new Error("messages array cannot exceed 100 items");
  }
  for (const msg of data.messages) {
    if (!msg.role || !['user', 'assistant', 'system'].includes(msg.role)) {
      throw new Error("Invalid message role");
    }
    if (!msg.content || typeof msg.content !== 'string') {
      throw new Error("Message content must be a string");
    }
    if (msg.content.length > 50000) {
      throw new Error("Message content cannot exceed 50KB");
    }
  }
  return data;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract user from JWT token (optional for trial mode)
    const authHeader = req.headers.get("Authorization");
    let userId = null;

    if (authHeader) {
      try {
        const supabaseClient = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_ANON_KEY") ?? "",
          { global: { headers: { Authorization: authHeader } } }
        );

        const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
        if (!authError && user) {
          userId = user.id;
          console.log(`👤 Authenticated User ID: ${userId}`);
        } else {
          console.log("🌐 Anonymous user - auth header present but no valid user session");
        }
      } catch (authError) {
        console.log("🌐 Anonymous user - auth error:", authError instanceof Error ? authError.message : String(authError));
      }
    } else {
      console.log("🌐 Anonymous user - no auth header");
    }

    // Parse and validate request body
    const requestBody = await req.json();
    const { messages } = validateMessages(requestBody);
    
    console.log(`📨 brief-maker: Received ${messages.length} messages from frontend`);
    
    // Log first and last message for debugging
    if (messages.length > 0) {
      console.log(`📝 First message: ${messages[0].role} - ${messages[0].content?.substring(0, 100)}...`);
      console.log(`📝 Last message: ${messages[messages.length - 1].role} - ${messages[messages.length - 1].content?.substring(0, 100)}...`);
    }
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are a Voice Agent Brief Generator.

Your job is to analyze the user's conversation and produce:
1. A complete Build Brief (briefMd)
2. An agentDraft that includes tone, personality, and other key fields

In addition, you must detect and incorporate ANY "meta feedback" or "functional instructions" the user gives about how the voice agent should behave.

---------------------------------------------
TYPES OF USER FEEDBACK YOU MUST INTERPRET
---------------------------------------------

### 1. Behavioral Adjustments (HOW the agent should speak)
These include natural-language instructions such as:
- "Be more confident."
- "Speak more concisely."
- "Use active listening."
- "Summarize what I say before replying."
- "Talk slower."
- "Sound friendlier."
- "Ask only one question at a time."
- "Reflect back what I said."

You MUST:
- Identify these instructions.
- Convert them into generalized behavioral rules expressed in natural language.
- Insert them into the Build Brief under:

  **Prompts (Vapi instructions) → Behavior & Style Adjustments**

- Reflect them in agentDraft fields:
  - tone (array of adjectives)
  - personality (append behavioral style descriptions)
  - pacing, summarization style, listening style (expressed in personality)

NO hardcoded keyword matching.
Interpret natural language meaningfully and flexibly.

---------------------------------------------
### 2. Functional / Scope Adjustments (WHAT the agent should do)
The user may specify rules about the agent's domain, tasks, or constraints.
Examples include:
- "Only give advice about clothing and accessories."
- "Do not answer questions about makeup."
- "Always begin by asking the user how they describe their personal style."
- "Only provide outfit ideas that match the user's stated budget."
- "Suggest two options every time."
- "Focus only on AWS Lambda questions, nothing else."
- "Before giving advice, ask clarifying questions."

You MUST:
- Detect ANY functional instruction.
- Convert it into clear operational rules.
- Add those rules inside:

  **Prompts (Vapi instructions) → Functional Rules & Constraints**

- Also incorporate them into:
  - The "Call/Conversation Flow" section
  - The "Outcomes & Success" section (if relevant)
  - The agentDraft personality (only if it affects how the agent behaves)
  - The agentDraft domain fields (if applicable to tone or scope)

These rules should shape the assistant's actual capabilities, domain limits, and conversation logic.

---------------------------------------------
### HOW TO EXPRESS ADJUSTMENTS
---------------------------------------------
Always translate unconstrained user feedback into clear, structured, reusable rules.

Behavioral example:
- "Be more confident" → "Use an assured, confident tone."
- "Summarize what I say" → "Begin responses with a one-sentence reflection of the user's message."
- "Talk slower" → "Maintain a slower, more deliberate speaking pace."

Functional example:
- "Only talk about clothing and accessories" → "The assistant must restrict advice strictly to clothing and accessories, and decline unrelated topics."
- "Ask them about their personal style first" → "The first step of the onboarding flow is to ask: 'How would you describe your personal style?'"

ALWAYS generalize the rule so it works as a policy, not a one-off response.

---------------------------------------------
### CRITICAL RULES FOR MODIFYING THE BRIEF
---------------------------------------------

**SECTION SEPARATION RULES (STRICTLY ENFORCE):**

1. **Title & Summary / About This Agent**
   - MUST be 1-3 sentences ONLY
   - Describe WHO the agent is and its general purpose
   - Example: "A warm, professional medical receptionist that helps patients schedule appointments efficiently."
   - NEVER include:
     ❌ Operational rules (e.g., "only suggests recipes that...")
     ❌ Domain restrictions (e.g., "declines makeup questions")
     ❌ Flow steps (e.g., "asks about dietary preferences first")
     ❌ Behavioral instructions (e.g., "summarizes user input before responding")
     ❌ Task constraints or safety rules
   - Keep it stable, short, and human-readable

2. **agentDraft.personality**
   - MUST describe communication style and emotional vibe ONLY
   - Examples: "warm, thoughtful, confident", "playful and encouraging", "calm and patient"
   - NEVER include:
     ❌ Functional constraints (e.g., "only suggests recipes matching dietary needs")
     ❌ Domain limits (e.g., "declines non-fashion topics")
     ❌ Task instructions (e.g., "asks clarifying questions before suggesting")
     ❌ Recipe rules, safety restrictions, or flow logic
   - Keep it SHORT and stylistic, not procedural

3. **Prompts (Vapi instructions) → Functional Rules & Constraints**
   - This is where ALL operational rules, domain limits, and task constraints go
   - Examples:
     • "Only suggest recipes that match the user's stated dietary preferences"
     • "Decline questions outside of clothing and accessories"
     • "Always verify budget before suggesting outfit options"
   - Use clear bullet points

4. **Prompts (Vapi instructions) → Behavior & Style Adjustments**
   - This is where ALL communication-style rules go
   - Examples:
     • "Use an assured, confident tone"
     • "Begin responses with a one-sentence reflection of user input"
     • "Ask only one question at a time"
   - Use clear bullet points

5. **Call/Conversation Flow**
   - Integrate functional rules that change the conversation sequence
   - Example: "Step 1: Ask the user to describe their dietary preferences"

6. **Persona & Vibe**
   - Add personality implications (e.g., "warm, stylish, confident fashion advisor")
   - Keep focused on tone and vibe, not detailed rules or constraints

7. **Outcomes & Success**
   - Reflect functional rules that define success metrics
   - Example: "Provide two outfit options within stated budget"

**RULE PLACEMENT SUMMARY:**
- Short summaries (About This Agent, agentDraft.personality) = WHO and communication style only
- All functional/operational rules → Prompts (Vapi instructions) → Functional Rules & Constraints
- All behavioral adjustments → Prompts (Vapi instructions) → Behavior & Style Adjustments
- Do NOT copy long rule blocks into summary sections or agentDraft.personality

---------------------------------------------
### IMPORTANT CONSTRAINTS
---------------------------------------------
- Do NOT say "not enough information" — fill missing content using defaults.
- If there are conflicting rules, the most recent user message wins.
- Keep directives crisp, structured, and suitable for a system prompt inside Vapi.
- **CRITICAL:** Keep "Title & Summary" and "About This Agent" to 1-3 sentences, persona-focused ONLY
- **CRITICAL:** Keep agentDraft.personality SHORT and stylistic (communication vibe only), NO procedural rules
- **CRITICAL:** Put ALL detailed operational rules in "Prompts (Vapi instructions) → Functional Rules & Constraints"
- **CRITICAL:** Put ALL behavioral adjustments in "Prompts (Vapi instructions) → Behavior & Style Adjustments"
- Do NOT copy long rule blocks into summary sections, Persona & Vibe, or agentDraft.personality
- **CRITICAL VOICE HANDLING:** When the user requests a voice change (accent, gender, age, speaking style, vocal identity like "Southern accent", "British voice", "female voice", "younger voice"):
  - ALWAYS update agentDraft.accent to the requested accent (e.g., "en-US (Southern)", "en-GB (British)", "en-US (neutral)")
  - Update agentDraft.tone or personality adjectives if they relate to the voice identity
  - Do NOT place accent or voice rules into "About This Agent"
  - Do NOT bury voice/accent preferences only inside the Build Brief
  - Voice and accent preferences MUST be reflected in agentDraft fields so the voice selection logic can use them
- NEVER output anything except the JSON tool call result.

---------------------------------------------
CRITICAL INSTRUCTION: Always generate a complete brief, even if information is missing.
For any missing sections, use these defaults:

DEFAULT VALUES:
- Agent Name: "Friendly Voice Agent"
- Purpose: "A warm, conversational voice assistant that helps users naturally"
- Tone: ["warm", "professional", "friendly"]
- Accent: "en-US (neutral)"
- Warmth: 80
- Creativity: 65
- Sample Line: "Hey there! What's on your mind today?"
- Personality: "A warm, thoughtful voice assistant"

Return ONLY a JSON object in a markdown code fence:

\`\`\`json
{
  "briefMd": "# Build Brief — [Name]\\n\\n## Title & Summary\\n...",
  "agentDraft": {
    "name": "string",
    "tone": ["warm", "playful"],
    "accent": "en-US (Midwest)",
    "warmth": 80,
    "creativity": 70,
    "latency": "natural",
    "consent": "gentle",
    "sampleLine": "Opening line from flow",
    "personality": "Brief personality description"
  }
}
\`\`\`

Brief structure (ALL sections required - use defaults if not mentioned):
# Build Brief — [Name]
## Title & Summary
• SHORT, HIGH-LEVEL description (1-3 sentences): agent persona, purpose, target user
• DO NOT include detailed behavioral or functional rules here
• **Confidence:** high/medium/low (based on conversation detail)
## Outcomes & Success
• Primary outcomes, metrics. **Confidence:** ...
## Persona & Vibe
• Tone adjectives, pacing, 2-3 opener lines. **Confidence:** ...
## Call/Conversation Flow
• Golden path (5-8 steps), branches, closing. **Confidence:** ...
## Prompts (Vapi instructions)
• Identity, goals, style (≤200 words). **Confidence:** ...
### Behavior & Style Adjustments
• Clear bullet points of how the agent should speak/behave
• ALL specific behavioral constraints go here
### Functional Rules & Constraints
• Clear bullet points of what the agent should/shouldn't do
• ALL specific functional constraints and domain limits go here
## I/O & Data Notes
• Fields to capture, storage, consent. **Confidence:** ...
## Telephony & Latency
• Entry method, latency, recording. **Confidence:** ...
## Growth & Follow-ups
• Nudge cadence, invite copy. **Confidence:** ...
## Handoffs & Ops
• Issue routing, hours, risks. **Confidence:** ...
## Open Questions
• 3-8 questions (or state "None" if complete)
## Stretch / Not Yet
• R&D ideas, alternatives

FILLING MISSING SECTIONS:
- If user mentioned 3-4 key topics (purpose, vibe, flow, goal), use those and fill rest with defaults
- Mark any auto-filled content with "**Confidence: low (auto-filled)**"
- For complete sections from conversation, use "**Confidence: high**"
- NEVER return "Not enough information" - always generate a complete brief

Agent draft (use defaults for missing fields):
- name: from Brief Title or "Friendly Voice Agent"
- tone: 2-3 adjectives ["warm", "professional"] - ADD behavioral cues from user feedback
- accent: "en-US (Midwest)" or "en-US (neutral)" or "en-GB (British)"
- warmth: 0-100 (default: 80)
- creativity: 0-100 (default: 65)
- latency: "fast" | "natural" | "slow" (default: "natural")
- consent: "strict" | "gentle" | "auto_proceed" (default: "gentle")
- sampleLine: first caller-facing line from flow or default
- personality: **CRITICAL** - brief communication style ONLY (e.g., "warm, confident, concise") - NO functional constraints, NO domain limits, NO task instructions, NO procedural rules - keep it SHORT and stylistic

Return valid JSON only. Use double quotes, escape special chars, no trailing commas.`;

    console.log(`🤖 Calling AI Gateway with model: google/gemini-2.5-flash`);
    console.log(`📊 Total messages (including system): ${messages.length + 1}`);
    
    const aiRequestBody = {
      model: "google/gemini-2.5-flash",
      messages: [
        { role: "system", content: systemPrompt },
        ...messages,
      ],
      tools: [{
        type: "function",
        function: {
          name: "generate_brief",
          description: "Generate a structured voice agent brief with all required sections",
          parameters: {
            type: "object",
            properties: {
              briefMd: {
                type: "string",
                description: "Complete markdown brief with all sections"
              },
              agentDraft: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  tone: { type: "array", items: { type: "string" } },
                  accent: { type: "string" },
                  warmth: { type: "number" },
                  creativity: { type: "number" },
                  latency: { type: "string" },
                  consent: { type: "string" },
                  sampleLine: { type: "string" },
                  personality: { type: "string" }
                },
                required: ["name", "tone", "accent", "warmth", "creativity", "latency", "sampleLine", "personality"]
              }
            },
            required: ["briefMd", "agentDraft"]
          }
        }
      }],
      tool_choice: { type: "function", function: { name: "generate_brief" } },
    };
    
    console.log(`📤 Request body size: ${JSON.stringify(aiRequestBody).length} characters`);

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(aiRequestBody),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("❌ AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`✅ AI Gateway response status: ${response.status}`);
    const data = await response.json();
    console.log(`📦 Response structure:`, {
      hasChoices: !!data.choices,
      choicesLength: data.choices?.length,
      hasMessage: !!data.choices?.[0]?.message,
      hasToolCalls: !!data.choices?.[0]?.message?.tool_calls,
    });
    
    // Extract result from tool call
    const toolCalls = data.choices?.[0]?.message?.tool_calls;
    if (!toolCalls || toolCalls.length === 0) {
      console.error('❌ No tool calls in response');
      return new Response(JSON.stringify({ error: "AI did not generate a brief" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let result;
    try {
      const toolCall = toolCalls[0];
      console.log('📦 Tool call function:', toolCall.function.name);
      console.log('📦 Arguments length:', toolCall.function.arguments.length);
      
      result = JSON.parse(toolCall.function.arguments);
      
      // Validate required fields
      if (!result.briefMd || typeof result.briefMd !== 'string') {
        throw new Error('Missing or invalid briefMd field');
      }
      if (!result.agentDraft || typeof result.agentDraft !== 'object') {
        throw new Error('Missing or invalid agentDraft field');
      }
      
      console.log('✅ brief-maker: Successfully parsed tool call result');
      console.log('📄 Brief length:', result.briefMd.length, 'characters');
      console.log('🤖 Agent draft:', result.agentDraft.name || '(unnamed)');
    } catch (parseError) {
      console.error('❌ Tool call parse error:', parseError);
      return new Response(JSON.stringify({ 
        error: `Invalid tool call result: ${parseError instanceof Error ? parseError.message : 'Unknown error'}` 
      }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    // Clean up the briefMd markdown
    if (result.briefMd) {
      result.briefMd = result.briefMd
        // Remove excessive hashes (more than 3)
        .replace(/#{4,}/g, '###')
        // Remove redundant asterisks (more than 2)
        .replace(/\*{3,}/g, '**')
        // Remove multiple consecutive empty lines
        .replace(/\n{3,}/g, '\n\n')
        // Trim whitespace around headings
        .replace(/\n\s*#/g, '\n#')
        // Remove trailing whitespace from lines
        .replace(/[ \t]+$/gm, '')
        // Standardize bullet points
        .replace(/^[•·]/gm, '•')
        .trim();
    }
    
    // Final safety check and serialization
    const safeResponse = {
      briefMd: result.briefMd,
      agentDraft: result.agentDraft
    };
    
    console.log('✅ Returning brief with length:', safeResponse.briefMd.length);
    console.log('✅ brief-maker: Returning successful response');
    
    return new Response(JSON.stringify(safeResponse), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("❌ brief-maker error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
