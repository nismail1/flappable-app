import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { FileText, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface KnowledgeFile {
  id: string;
  file_name: string;
  file_size: number;
  uploaded_at: string;
  file_type: string | null;
}

interface KnowledgeBaseDisplayProps {
  agentId?: string;
}

const formatFileSize = (bytes: number): string => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

export const KnowledgeBaseDisplay = ({ agentId }: KnowledgeBaseDisplayProps) => {
  const [files, setFiles] = useState<KnowledgeFile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!agentId) {
      setLoading(false);
      return;
    }

    const fetchFiles = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('knowledge_files')
        .select('id, file_name, file_size, uploaded_at, file_type')
        .eq('agent_id', agentId)
        .order('uploaded_at', { ascending: false });

      if (error) {
        console.error('Error fetching knowledge files:', error);
      } else {
        setFiles(data || []);
      }
      setLoading(false);
    };

    fetchFiles();

    // Set up real-time subscription for new file uploads
    const channel = supabase
      .channel('knowledge-files-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'knowledge_files',
          filter: `agent_id=eq.${agentId}`
        },
        (payload) => {
          setFiles((current) => [payload.new as KnowledgeFile, ...current]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [agentId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (files.length === 0) {
    return (
      <div className="text-center py-8">
        <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
        <p className="text-sm text-muted-foreground">
          No files uploaded yet. Upload documents to give your agent knowledge.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {files.map((file) => (
        <Card key={file.id} className="p-4 bg-background/50 border-border hover:bg-background/80 transition-colors">
          <div className="flex items-start gap-3">
            <FileText className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {file.file_name}
              </p>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-xs text-muted-foreground">
                  {formatFileSize(file.file_size)}
                </span>
                <span className="text-xs text-muted-foreground">•</span>
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(file.uploaded_at), { addSuffix: true })}
                </span>
              </div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};
