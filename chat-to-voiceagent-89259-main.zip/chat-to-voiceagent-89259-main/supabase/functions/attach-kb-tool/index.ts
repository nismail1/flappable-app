import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      throw new Error('VAPI_API_KEY not configured');
    }

    const { assistantId, toolId } = await req.json();

    if (!assistantId || !toolId) {
      return new Response(
        JSON.stringify({ error: 'assistantId and toolId are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`🔗 Attaching tool ${toolId} to assistant ${assistantId}`);

    // First, get the current assistant configuration
    const getResponse = await fetch(`https://api.vapi.ai/assistant/${assistantId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
      },
    });

    if (!getResponse.ok) {
      const errorText = await getResponse.text();
      console.error('❌ Error fetching assistant:', errorText);
      throw new Error(`Failed to fetch assistant: ${getResponse.status} - ${errorText}`);
    }

    const currentAssistant = await getResponse.json();
    console.log('📋 Current assistant config retrieved');

    // Merge the new toolId with existing toolIds
    const existingToolIds = currentAssistant.model?.toolIds || [];
    const updatedToolIds = [...existingToolIds, toolId];

    // Patch the assistant with the updated toolIds
    const patchPayload = {
      model: {
        ...currentAssistant.model,
        toolIds: updatedToolIds
      }
    };

    const patchResponse = await fetch(`https://api.vapi.ai/assistant/${assistantId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(patchPayload),
    });

    if (!patchResponse.ok) {
      const errorText = await patchResponse.text();
      console.error('❌ Vapi assistant patch error:', errorText);
      throw new Error(`Vapi assistant patch failed: ${patchResponse.status} - ${errorText}`);
    }

    const updatedAssistant = await patchResponse.json();
    console.log('✅ Tool attached to assistant');

    // Now update the system prompt to mention the knowledge base
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Find the agent_id from voice_agent_versions using vapi_agent_id
    const { data: agentData } = await supabaseClient
      .from('voice_agent_versions')
      .select('id, user_id')
      .eq('vapi_agent_id', assistantId)
      .single();

    if (agentData) {
      // Query knowledge files for this agent
      const { data: knowledgeFiles } = await supabaseClient
        .from('knowledge_files')
        .select('file_name')
        .eq('agent_id', agentData.id);

      if (knowledgeFiles && knowledgeFiles.length > 0) {
        // Get current system prompt
        const currentPrompt = currentAssistant.model?.messages?.[0]?.content || '';
        
        // Check if KB instructions already exist
        const hasKBInstructions = currentPrompt.includes('Knowledge Base Access') || 
                                 currentPrompt.includes('uploaded documents');

        if (!hasKBInstructions) {
          const fileList = knowledgeFiles.map(f => f.file_name).join(', ');
          const kbInstructions = `\n\n## Knowledge Base Access\n\nYou have access to uploaded documents: ${fileList}.\n\n**IMPORTANT**: When users ask questions that might be answered by the uploaded documents, you MUST use the search_knowledge_base tool to find the information before answering. Always cite which document the information came from.\n\nExample usage: If asked about any topic covered in the documents, call search_knowledge_base with a relevant query first.`;
          
          const updatedPrompt = currentPrompt + kbInstructions;
          
          // Update the system prompt
          const promptUpdateResponse = await fetch(`https://api.vapi.ai/assistant/${assistantId}`, {
            method: 'PATCH',
            headers: {
              'Authorization': `Bearer ${vapiApiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              model: {
                ...updatedAssistant.model,
                messages: [
                  {
                    role: 'system',
                    content: updatedPrompt
                  }
                ]
              }
            }),
          });

          if (promptUpdateResponse.ok) {
            console.log('✅ System prompt updated with knowledge base instructions');
          } else {
            console.error('⚠️ Failed to update system prompt, but tool was attached successfully');
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        assistantId: updatedAssistant.id,
        toolIds: updatedAssistant.model?.toolIds
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in attach-kb-tool:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
