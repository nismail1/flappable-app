
-- Migration: 20251029065544
-- Create table for tracking voice agent versions and iterations
CREATE TABLE public.voice_agent_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  version TEXT NOT NULL,
  voice_name TEXT,
  voice_id TEXT,
  prompt TEXT,
  vapi_agent_id TEXT,
  agent_config JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.voice_agent_versions ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to insert (since there's no auth yet)
CREATE POLICY "Anyone can insert agent versions"
ON public.voice_agent_versions
FOR INSERT
WITH CHECK (true);

-- Create policy to allow anyone to view agent versions
CREATE POLICY "Anyone can view agent versions"
ON public.voice_agent_versions
FOR SELECT
USING (true);

-- Create index on vapi_agent_id for faster lookups
CREATE INDEX idx_voice_agent_versions_vapi_id ON public.voice_agent_versions(vapi_agent_id);

-- Create index on created_at for sorting
CREATE INDEX idx_voice_agent_versions_created_at ON public.voice_agent_versions(created_at DESC);

-- Migration: 20251105000305
-- Create profiles table for user data
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  display_name text,
  avatar_url text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles are viewable by everyone
CREATE POLICY "Profiles are viewable by everyone" 
ON public.profiles 
FOR SELECT 
USING (true);

-- Users can update their own profile
CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id);

-- Users can insert their own profile
CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = id);

-- Create function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username, display_name)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  );
  RETURN new;
END;
$$;

-- Trigger to create profile on user signup
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Add user_id column to voice_agent_versions
ALTER TABLE public.voice_agent_versions 
ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;

-- Create index for better query performance
CREATE INDEX idx_voice_agent_versions_user_id ON public.voice_agent_versions(user_id);

-- Drop existing permissive policies
DROP POLICY IF EXISTS "Anyone can view agent versions" ON public.voice_agent_versions;
DROP POLICY IF EXISTS "Anyone can insert agent versions" ON public.voice_agent_versions;

-- Create new RLS policies for voice_agent_versions
CREATE POLICY "Users can view their own agent versions" 
ON public.voice_agent_versions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own agent versions" 
ON public.voice_agent_versions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own agent versions" 
ON public.voice_agent_versions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own agent versions" 
ON public.voice_agent_versions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Migration: 20251105052547
-- Add unique constraint to vapi_agent_id to support upsert operations
ALTER TABLE voice_agent_versions 
ADD CONSTRAINT voice_agent_versions_vapi_agent_id_key 
UNIQUE (vapi_agent_id);

-- Migration: 20251105054311
-- Create function for updating updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create agent_conversations table for persistent chat history
CREATE TABLE public.agent_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES public.voice_agent_versions(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  messages JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.agent_conversations ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own conversations"
ON public.agent_conversations
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own conversations"
ON public.agent_conversations
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own conversations"
ON public.agent_conversations
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own conversations"
ON public.agent_conversations
FOR DELETE
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_agent_conversations_updated_at
BEFORE UPDATE ON public.agent_conversations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Migration: 20251105054401
-- Fix function search path security warning
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
