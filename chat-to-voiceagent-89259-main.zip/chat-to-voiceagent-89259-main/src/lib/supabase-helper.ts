import { supabase } from "@/integrations/supabase/client";

// Temporary helper to bypass type checking until Supabase types sync
export const supabaseFrom = (tableName: string) => {
  return (supabase as any).from(tableName);
};
