import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Input validation
const validateAgentInput = (data: any) => {
  if (!data.agentDraft || typeof data.agentDraft !== "object") {
    throw new Error("agentDraft is required and must be an object");
  }

  if (data.briefMd && typeof data.briefMd !== "string") {
    throw new Error("briefMd must be a string");
  }

  if (data.briefMd && data.briefMd.length > 100000) {
    throw new Error("briefMd cannot exceed 100KB");
  }

  if (data.deployedAgentId && typeof data.deployedAgentId !== "string") {
    throw new Error("deployedAgentId must be a string");
  }

  // Validate agentDraft fields
  const draft = data.agentDraft;
  const stringFields = ["name", "accent", "personality", "sampleLine", "voiceId"];
  for (const field of stringFields) {
    if (draft[field] && typeof draft[field] !== "string") {
      throw new Error(`agentDraft.${field} must be a string`);
    }
    if (draft[field] && draft[field].length > 1000) {
      throw new Error(`agentDraft.${field} cannot exceed 1000 characters`);
    }
  }

  return data;
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Extract user from JWT token (optional for trial mode)
    const authHeader = req.headers.get("Authorization");
    let userId = null;

    if (authHeader) {
      const supabaseClient = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
        global: { headers: { Authorization: authHeader } },
      });

      const {
        data: { user },
        error: authError,
      } = await supabaseClient.auth.getUser();
      if (!authError && user) {
        userId = user.id;
        console.log(`👤 Authenticated User ID: ${userId}`);
      }
    } else {
      console.log("🌐 Anonymous user - trial mode");
    }

    // Parse and validate request body
    const requestBody = await req.json();
    const { agentDraft, briefMd, deployedAgentId } = validateAgentInput(requestBody);
    const VAPI_API_KEY = Deno.env.get("VAPI_API_KEY");
    if (!VAPI_API_KEY) throw new Error("VAPI_API_KEY is not configured");
    if (!agentDraft) throw new Error("Missing agentDraft in request body");

    console.log("🆕 create-vapi-agent v7 deployed at 2025-10-29T16:45Z");

    const isUpdate = !!deployedAgentId;
    if (isUpdate) {
      console.log("🔄 Updating existing agent:", deployedAgentId);
    } else {
      console.log("🧠 Creating new agent", agentDraft);
    }

    // 🎙️ Expanded voice database with Vapi and ElevenLabs voices
    const voiceProfiles = [
      // Vapi Voices
      {
        id: "Rohan",
        provider: "vapi",
        gender: "male",
        accent: "indian american",
        keywords: ["bright", "optimistic", "cheerful", "energetic", "upbeat", "positive", "friendly", "engaging"],
      },
      {
        id: "Neha",
        provider: "vapi",
        gender: "female",
        accent: "indian american",
        keywords: ["professional", "charming", "confident", "articulate", "polished"],
      },
      {
        id: "Hana",
        provider: "vapi",
        gender: "female",
        accent: "american",
        keywords: ["soft", "soothing", "gentle", "calm", "kind", "comforting"],
      },
      {
        id: "Harry",
        provider: "vapi",
        gender: "male",
        accent: "american",
        keywords: ["clear", "energetic", "assertive", "confident", "dynamic", "professional"],
      },
      {
        id: "Elliot",
        provider: "vapi",
        gender: "male",
        accent: "canadian",
        keywords: ["soothing", "friendly", "professional", "approachable", "relaxed", "trustworthy"],
      },
      {
        id: "Lily",
        provider: "vapi",
        gender: "female",
        accent: "asian american",
        keywords: ["bright", "bubbly", "cheerful", "lively", "expressive", "youthful"],
      },
      {
        id: "Paige",
        provider: "vapi",
        gender: "female",
        accent: "american",
        keywords: ["deep", "calming", "professional", "grounded", "thoughtful", "steady"],
      },
      {
        id: "Cole",
        provider: "vapi",
        gender: "male",
        accent: "american",
        keywords: ["deep", "calming", "grounded", "composed", "sincere", "professional"],
      },
      {
        id: "Savannah",
        provider: "vapi",
        gender: "female",
        accent: "southern american",
        keywords: ["southern", "warm", "charming", "regional", "expressive"],
      },
      {
        id: "Spencer",
        provider: "vapi",
        gender: "female",
        accent: "american",
        keywords: ["energetic", "quippy", "lighthearted", "cheeky", "amused", "playful", "humorous", "witty"],
      },

      // ElevenLabs Voices
      {
        id: "Matilda",
        provider: "11labs",
        voiceId: "NihRgaLj2HWAjvZ5XNxl",
        gender: "female",
        accent: "australian",
        keywords: ["casual", "calm", "alto", "young", "story-telling", "narration"],
      },
      {
        id: "Heather",
        provider: "11labs",
        voiceId: "4XHqIi1c86s718fjqNEF",
        gender: "female",
        accent: "british",
        keywords: ["mature", "refined", "posh", "fancy", "elegant", "experienced"],
      },
      {
        id: "James",
        provider: "11labs",
        voiceId: "qHjTmW2eGRTuNVwP3Rsi",
        gender: "male",
        accent: "british",
        keywords: ["presenter", "polished", "professional", "news", "broadcaster", "refined"],
      },
      {
        id: "Daniel R",
        provider: "11labs",
        voiceId: "ZMK5OD2jmsdse3EKE4W5",
        gender: "male",
        accent: "american",
        keywords: ["deep", "resonant", "calming", "strong", "mature", "masculine"],
      },
      {
        id: "Alex",
        provider: "11labs",
        voiceId: "JGIWhSd306fVRtZfD1OA",
        gender: "male",
        accent: "australian",
        keywords: ["casual", "young", "energetic", "personable", "friendly"],
      },
      {
        id: "Ivanna",
        provider: "11labs",
        voiceId: "yM93hbw8Qtvdma2wCnJG",
        gender: "female",
        accent: "american",
        keywords: ["casual", "conversational", "young", "witty", "playful", "modern"],
      },
    ];

    // Combine all descriptive text to search through
    const description = [
      agentDraft.name,
      agentDraft.accent,
      agentDraft.tone,
      agentDraft.personality,
      agentDraft.sampleLine,
      briefMd,
    ]
      .join(" ")
      .toLowerCase();

    // Helper: find voice with most keyword matches
    let bestVoice = voiceProfiles[0]; // Default to Rohan
    let bestScore = 0;

    for (const voice of voiceProfiles) {
      let score = 0;

      // Strong preference for explicit gender match
      if (agentDraft.gender && agentDraft.gender.toLowerCase() === voice.gender) {
        score += 10;
      }

      // Strong preference for explicit accent match
      if (agentDraft.accent && voice.accent) {
        const requestedAccent = agentDraft.accent.toLowerCase();
        if (voice.accent.includes(requestedAccent) || requestedAccent.includes(voice.accent)) {
          score += 10;
        }
      }

      // Legacy matching from description
      if (description.includes(voice.gender)) score += 2;
      if (description.includes(voice.accent)) score += 2;

      // Keyword matching
      for (const kw of voice.keywords) {
        if (description.includes(kw)) score += 1;
      }

      // Bonus for ElevenLabs voices with mature/professional keywords
      if (
        ["mature", "deep", "refined", "narration", "broadcaster"].some((t) => description.includes(t)) &&
        voice.provider === "11labs"
      ) {
        score += 3;
      }

      if (score > bestScore) {
        bestVoice = voice;
        bestScore = score;
      }
    }

    // Default to Elliot if no meaningful match
    if (bestScore === 0) {
      bestVoice = voiceProfiles.find((v) => v.id === "Elliot") || voiceProfiles[0];
    }

    console.log("🎙️ Selected Voice:", bestVoice.id);
    console.log("🧩 Provider:", bestVoice.provider);
    console.log("🗣️ Gender:", bestVoice.gender, "Accent:", bestVoice.accent);
    console.log("📊 Score:", bestScore);

    const toneStr = Array.isArray(agentDraft.tone) ? agentDraft.tone.join(", ") : agentDraft.tone;

    // Check if agent has knowledge base files
    let kbInstructions = '';
    if (userId && deployedAgentId) {
      const supabaseClient = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      );
      
      // Find the agent's database ID
      const { data: agentData } = await supabaseClient
        .from('voice_agent_versions')
        .select('id')
        .eq('vapi_agent_id', deployedAgentId)
        .single();
        
      if (agentData) {
        const { data: knowledgeFiles } = await supabaseClient
          .from('knowledge_files')
          .select('file_name')
          .eq('agent_id', agentData.id);
          
        if (knowledgeFiles && knowledgeFiles.length > 0) {
          const fileList = knowledgeFiles.map(f => f.file_name).join(', ');
          kbInstructions = `\n\n## Knowledge Base Access\n\nYou have access to a knowledge base containing: ${fileList}. Use the knowledge base tool to answer questions based on these documents. Always cite the source when providing information from the knowledge base.`;
        }
      }
    }

    // Build system prompt from the brief if provided
    const systemPrompt = briefMd?.trim()
      ? `You are a voice assistant configured according to the following Build Brief:\n\n${briefMd}\n\nFollow the structure, tone, and behavior described above.${kbInstructions}`
      : `You are ${agentDraft.name || "a helpful voice assistant"}.\nYour tone is ${
          toneStr || "friendly and conversational"
        }.\n${agentDraft.personality || "Speak clearly, respond naturally, and stay concise."}\nExample opening: "${
          agentDraft.sampleLine || "Hi there! How can I help today?"
        }"${kbInstructions}`;

    // Determine API endpoint and method
    const apiUrl = isUpdate ? `https://api.vapi.ai/assistant/${deployedAgentId}` : "https://api.vapi.ai/assistant";
    const apiMethod = isUpdate ? "PATCH" : "POST";

    // When updating, fetch existing agent config first to preserve all settings
    let existingAgent = null;
    if (isUpdate) {
      const fetchResponse = await fetch(apiUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${VAPI_API_KEY}`,
          "Content-Type": "application/json",
        },
      });
      if (fetchResponse.ok) {
        existingAgent = await fetchResponse.json();
        console.log("📥 Fetched existing agent config for merge");
      }
    }

    // Build the payload, merging with existing config if updating
    const payload: any = {
      name: `Wizard Agent — ${agentDraft.name || "Untitled Voice Agent"}`.slice(0, 40),
      model: {
        provider: "openai",
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
        ],
      },
      voice: {
        provider: bestVoice.provider,
        voiceId: bestVoice.voiceId || bestVoice.id,
      },
      firstMessage: agentDraft.sampleLine || "Hello, how can I help you today?",
      transcriber: {
        provider: "deepgram",
        model: "nova-2",
        language: "en",
      },
      clientMessages: ["transcript", "hang", "function-call", "speech-update", "metadata", "conversation-update"],
      serverMessages: ["end-of-call-report", "status-update", "hang", "function-call"],
      silenceTimeoutSeconds: 30,
      startSpeakingPlan: {
        waitSeconds: 1.2,
      },
      numWordsToInterruptAssistant: 3,
      maxDurationSeconds: 600,
      backgroundSound: "off",
      backchannelingEnabled: false,
      backgroundDenoisingEnabled: true,
      modelOutputInMessagesEnabled: true,
    };

    // If updating, merge with existing config to avoid overwriting unrelated fields
    if (isUpdate && existingAgent) {
      console.log("🔀 Merging with existing agent config");

      // Remove read-only fields that Vapi doesn't accept in PATCH
      const { id, orgId, createdAt, updatedAt, isServerUrlSecretSet, ...cleanExistingAgent } = existingAgent;

      // Preserve existing values for fields we're not explicitly updating
      const mergedPayload = {
        ...cleanExistingAgent,
        ...payload,
        // Deep merge nested objects
        model: { ...existingAgent.model, ...payload.model },
        voice: { ...existingAgent.voice, ...payload.voice },
        transcriber: { ...existingAgent.transcriber, ...payload.transcriber },
        startSpeakingPlan: { ...existingAgent.startSpeakingPlan, ...payload.startSpeakingPlan },
      };
      Object.assign(payload, mergedPayload);
    }

    // ✅ Create/update the assistant using only supported Vapi fields
    const response = await fetch(apiUrl, {
      method: apiMethod,
      headers: {
        Authorization: `Bearer ${VAPI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("❌ Vapi error:", response.status, errorText);
      throw new Error(`Failed to ${isUpdate ? "update" : "create"} assistant: ${response.status}`);
    }

    const data = await response.json();
    console.log(`✅ Voice Agent ${isUpdate ? "updated" : "created"} successfully:`, data.id);

    return new Response(
      JSON.stringify({
        success: true,
        agentId: data.id,
        agent: data,
        voiceProvider: bestVoice.provider,
        voiceId: bestVoice.voiceId || bestVoice.id,
        voiceName: bestVoice.id,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      },
    );
  } catch (error) {
    console.error("Error creating VAPI agent:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
