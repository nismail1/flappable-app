import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Send, Sparkles, Bell, MessageSquare, Upload } from "lucide-react";
import { VibeChips } from "./VibeChips";
import ReactMarkdown from "react-markdown";
import { supabase } from "@/integrations/supabase/client";
import { supabaseFrom } from "@/lib/supabase-helper";
import { toast } from "sonner";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface ChatInterfaceProps {
  onMessagesChange?: (messages: Message[]) => void;
  agentId?: string | null;
  userId?: string | null;
  vapiAgentId?: string | null;
}

export const ChatInterface = ({ onMessagesChange, agentId, userId, vapiAgentId }: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Hi! I'm here to help you design your voice agent. Tell me about what you want to create—what's the vibe, who's it for, and what should it do? Feel free to be casual; I'll ask if I need to know more.",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [isVerified, setIsVerified] = useState(false);
  const [receiveDailyReminders, setReceiveDailyReminders] = useState(false);
  const [receivePostCallSummaries, setReceivePostCallSummaries] = useState(false);
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load profile settings
  useEffect(() => {
    const loadProfile = async () => {
      if (!userId) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('phone_verified, receive_daily_reminders, receive_post_call_summaries')
        .eq('id', userId)
        .single();

      if (data) {
        setIsVerified(data.phone_verified || false);
        setReceiveDailyReminders(data.receive_daily_reminders || false);
        setReceivePostCallSummaries(data.receive_post_call_summaries || false);
      }
    };

    loadProfile();
  }, [userId]);

  // Load conversation history when agentId is provided
  useEffect(() => {
    const loadConversation = async () => {
      if (!agentId || !userId) {
        console.log('⏭️ Skipping conversation load - missing agentId or userId');
        return;
      }

      console.log(`📖 Loading conversation for agent ${agentId}`);
      const { data, error } = await supabaseFrom("agent_conversations")
        .select("*")
        .eq("agent_id", agentId)
        .eq("user_id", userId)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error("❌ Error loading conversation:", error);
        return;
      }

      if (data) {
        setConversationId((data as any).id);
        const loadedMessages = Array.isArray((data as any).messages) ? ((data as any).messages as unknown as Message[]) : [];
        console.log(`✅ Loaded conversation with ${loadedMessages.length} messages`);
        if (loadedMessages.length > 0) {
          setMessages(loadedMessages);
          onMessagesChange?.(loadedMessages);
          const { toast } = await import("sonner");
          toast.success("💬 Restored last chat", { duration: 2000 });
        }
      } else {
        console.log('📭 No existing conversation found');
      }
    };

    loadConversation();
  }, [agentId, userId]);

  // Save conversation to database via edge function
  const saveConversation = async (updatedMessages: Message[]) => {
    if (!agentId || !userId) {
      console.log('⏭️ Skipping conversation save - missing agentId or userId');
      return;
    }

    try {
      console.log(`💾 Saving conversation for agent ${agentId}, ${updatedMessages.length} messages`);
      
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/save-agent-conversation`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session?.access_token}`,
          },
          body: JSON.stringify({
            agent_id: agentId,
            messages: updatedMessages,
          }),
        }
      );

      const result = await response.json();
      
      if (!response.ok) {
        console.error('❌ Error saving conversation:', result.error);
        return;
      }

      if (result.conversation_id && !conversationId) {
        setConversationId(result.conversation_id);
      }
      
      console.log('✅ Conversation saved successfully');
    } catch (error) {
      console.error('❌ Error in saveConversation:', error);
    }
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    onMessagesChange?.(updatedMessages);
    setInput("");

    try {
      const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/vibe-coder-chat`;
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token || import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: updatedMessages }),
      });

      if (!response.ok || !response.body) {
        throw new Error("Failed to start stream");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let textBuffer = "";
      let streamDone = false;
      let assistantContent = "";

      // Create initial assistant message
      const assistantId = (Date.now() + 1).toString();
      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          role: "assistant",
          content: "",
          timestamp: new Date(),
        },
      ]);

      while (!streamDone) {
        const { done, value } = await reader.read();
        if (done) break;
        textBuffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = textBuffer.indexOf("\n")) !== -1) {
          let line = textBuffer.slice(0, newlineIndex);
          textBuffer = textBuffer.slice(newlineIndex + 1);

          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (line.startsWith(":") || line.trim() === "") continue;
          if (!line.startsWith("data: ")) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") {
            streamDone = true;
            break;
          }

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content as string | undefined;
            if (content) {
              assistantContent += content;
              
              // Strip the readiness token from display but keep in full content for state detection
              const displayContent = assistantContent.replace(/<READY_TO_GENERATE_BRIEF>/g, '').trim();
              
              setMessages((prev) => {
                const updated = prev.map((m) =>
                  m.id === assistantId ? { ...m, content: displayContent } : m
                );
                return updated;
              });
            }
          } catch {
            textBuffer = line + "\n" + textBuffer;
            break;
          }
        }
      }

      // Notify parent after streaming is complete with FULL content (including token for state detection)
      console.log('💬 Chat stream completed, content length:', assistantContent.length);
      
      // Check if readiness token is present
      if (assistantContent.includes('<READY_TO_GENERATE_BRIEF>')) {
        console.log('✅ READY TOKEN DETECTED in completed message');
      }
      
      const finalMessages = [...updatedMessages, {
        id: assistantId,
        role: "assistant" as const,
        content: assistantContent, // Keep token for state detection in Index.tsx
        timestamp: new Date(),
      }];
      onMessagesChange?.(finalMessages);
      
      // Save conversation to database
      await saveConversation(finalMessages);
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handleVibeChipSelect = (chip: string, value: string) => {
    const clarifier = `Make the ${chip.toLowerCase()} ${value.toLowerCase()}.`;
    setInput((prev) => (prev ? `${prev} ${clarifier}` : clarifier));
  };

  const handleNotificationChipClick = async (type: 'reminders' | 'summaries') => {
    // Check if user is authenticated
    if (!userId) {
      toast.error("Not available in trial mode");
      return;
    }
    
    // Send a message prompting for phone number
    const message = type === 'reminders'
      ? "To enable daily reminders, please enter your verified phone number (for example, +1 415 555 2671)."
      : "To enable post-call text summaries, please enter your verified phone number (for example, +1 415 555 2671).";
    
    const assistantMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: message,
      timestamp: new Date(),
    };

    const updatedMessages = [...messages, assistantMessage];
    setMessages(updatedMessages);
    onMessagesChange?.(updatedMessages);
    await saveConversation(updatedMessages);
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!vapiAgentId) {
      toast.error("Please create your agent first before uploading files");
      return;
    }

    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
      'text/csv',
      'text/markdown'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast.error("Please upload a PDF, DOCX, TXT, CSV, or Markdown file");
      return;
    }

    setIsUploadingFile(true);
    
    try {
      // Step 1: Upload file to Vapi
      const formData = new FormData();
      formData.append('file', file);

      const uploadResponse = await supabase.functions.invoke('upload-knowledge-file', {
        body: formData,
      });

      if (uploadResponse.error) {
        throw new Error(uploadResponse.error.message);
      }

      const { fileId } = uploadResponse.data;
      console.log('✅ File uploaded:', fileId);

      // Step 2: Create knowledge base tool
      const toolResponse = await supabase.functions.invoke('create-kb-tool', {
        body: {
          fileIds: [fileId],
          kbName: 'uploaded-file-kb',
          kbDescription: 'User-uploaded business information'
        }
      });

      if (toolResponse.error) {
        throw new Error(toolResponse.error.message);
      }

      const { toolId } = toolResponse.data;
      console.log('✅ Tool created:', toolId);

      // Step 3: Attach tool to assistant
      const attachResponse = await supabase.functions.invoke('attach-kb-tool', {
        body: {
          assistantId: vapiAgentId,
          toolId: toolId
        }
      });

      if (attachResponse.error) {
        throw new Error(attachResponse.error.message);
      }

      console.log('✅ Tool attached to assistant');

      // Show success message in chat
      const successMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: "Your agent can now answer questions using the uploaded document.",
        timestamp: new Date(),
      };

      const updatedMessages = [...messages, successMessage];
      setMessages(updatedMessages);
      onMessagesChange?.(updatedMessages);
      await saveConversation(updatedMessages);

      toast.success(`File "${file.name}" uploaded successfully`);

    } catch (error) {
      console.error('❌ File upload error:', error);
      toast.error("Failed to upload file. Please try again.");
    } finally {
      setIsUploadingFile(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <Card
              className={`max-w-[80%] p-4 ${
                message.role === "user"
                  ? "bg-gradient-to-br from-primary to-primary-glow text-primary-foreground"
                  : "bg-card"
              }`}
            >
              {message.role === "assistant" && (
                <Badge variant="secondary" className="mb-2 inline-flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Vibe Coder
                </Badge>
              )}
              <div className="text-sm leading-relaxed prose prose-sm max-w-none dark:prose-invert">
                <ReactMarkdown>
                  {message.content.replace(/<READY_TO_GENERATE_BRIEF>/g, '').trim()}
                </ReactMarkdown>
              </div>
            </Card>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card p-4 space-y-3">
        <div className="flex flex-wrap gap-2 pb-2">
          {!receiveDailyReminders && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleNotificationChipClick('reminders')}
              className="gap-2"
            >
              <Bell className="w-3 h-3" />
              Set up a daily reminder
            </Button>
          )}
          {!receivePostCallSummaries && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleNotificationChipClick('summaries')}
              className="gap-2"
            >
              <MessageSquare className="w-3 h-3" />
              Enable post-call text summary
            </Button>
          )}
        </div>
        
        <VibeChips onSelect={handleVibeChipSelect} />
        
        <div className="flex gap-2 items-end">
          <div className="flex-1">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Describe your voice agent idea..."
              className="resize-none min-h-[80px]"
            />
          </div>
          <div className="flex gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.txt,.csv,.md"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Button
              onClick={() => fileInputRef.current?.click()}
              size="icon"
              variant="outline"
              disabled={isUploadingFile}
              title="Upload business file"
            >
              {isUploadingFile ? (
                <div className="animate-spin">⏳</div>
              ) : (
                <Upload className="w-4 h-4" />
              )}
            </Button>
            <Button
              onClick={handleSend}
              size="icon"
              className="bg-gradient-to-br from-primary to-primary-glow hover:shadow-glow transition-all"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
