import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useLocation } from "react-router-dom";

interface NavigationContextType {
  previousRoute: string | null;
  getBackLabel: () => string;
  shouldShowBack: () => boolean;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

const ROOT_PAGES = ["/dashboard", "/", "/create-agent", "/auth"];

const labelMap: Record<string, string> = {
  "/dashboard": "Back to Dashboard",
  "/settings": "Back to Settings",
  "/configuration": "Back to Configuration",
  "/": "Back to Builder",
};

export const NavigationProvider = ({ children }: { children: ReactNode }) => {
  const location = useLocation();
  const [previousRoute, setPreviousRoute] = useState<string | null>(null);

  useEffect(() => {
    // Update previous route when location changes
    return () => {
      setPreviousRoute(location.pathname);
    };
  }, [location.pathname]);

  const shouldShowBack = () => {
    if (!previousRoute) return false;
    if (ROOT_PAGES.includes(previousRoute)) return false;
    if (window.history.length <= 1) return false;
    return true;
  };

  const getBackLabel = () => {
    if (!shouldShowBack()) return "";
    return labelMap[previousRoute || ""] || "Back";
  };

  return (
    <NavigationContext.Provider value={{ previousRoute, getBackLabel, shouldShowBack }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = () => {
  const context = useContext(NavigationContext);
  if (context === undefined) {
    throw new Error("useNavigation must be used within a NavigationProvider");
  }
  return context;
};
