import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, ArrowLeft, Loader2, Mic, MicOff, PhoneOff } from "lucide-react";
import { toast } from "sonner";
import Vapi from "@vapi-ai/web";
import { useNavigation } from "@/contexts/NavigationContext";

const SharedAgent = () => {
  const { shareId } = useParams();
  const navigate = useNavigate();
  const { getBackLabel, shouldShowBack } = useNavigation();
  const [agent, setAgent] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [callStatus, setCallStatus] = useState<"idle" | "connecting" | "connected" | "ended" | "failed">("idle");
  const [isMuted, setIsMuted] = useState(false);
  const [vapiInstance, setVapiInstance] = useState<any>(null);
  const [callTranscript, setCallTranscript] = useState<Array<{ role: string; content: string }>>([]);

  useEffect(() => {
    const fetchAgent = async () => {
      if (!shareId) {
        setLoading(false);
        return;
      }

      try {
        // Fetch the agent (now includes author_display_name)
        const { data: agentData, error: agentError } = await supabase
          .from("published_agents")
          .select("*")
          .eq("share_id", shareId)
          .eq("is_active", true)
          .maybeSingle();

        if (agentError) {
          console.error("Error fetching agent:", agentError);
          toast.error("Failed to load agent");
          return;
        }

        if (!agentData) {
          toast.error("Agent not found");
          return;
        }

        setAgent(agentData);

        // Increment view count
        await supabase
          .from("published_agents")
          .update({ views_count: (agentData.views_count || 0) + 1 })
          .eq("id", agentData.id);
      } catch (error) {
        console.error("Error:", error);
        toast.error("Something went wrong");
      } finally {
        setLoading(false);
      }
    };

    fetchAgent();
  }, [shareId]);

  const handleStartCall = async () => {
    try {
      setCallStatus("connecting");
      setCallTranscript([]);

      // Call the backend to get agent info and public key
      const { data, error } = await supabase.functions.invoke("start-public-agent-call", {
        body: { share_id: shareId },
      });

      if (error || !data?.agentId || !data?.publicKey) {
        console.error("Error starting call:", { error, data });
        setCallStatus("idle");
        toast.error("Failed to start call");
        return;
      }

      // Initialize VAPI with public key
      const vapi = new Vapi(data.publicKey);
      setVapiInstance(vapi);

      // Use a local array to collect transcript (to avoid stale closure)
      const transcriptMessages: Array<{ role: string; content: string }> = [];

      // Set up event listeners
      vapi.on("call-start", () => {
        console.log("Call started");
        setCallStatus("connected");
        toast.success("Connected! Start talking...");
      });

      vapi.on("message", (message: any) => {
        // Collect transcript messages in both local array and state
        if (message.type === "transcript" && message.transcriptType === "final") {
          const transcriptEntry = {
            role: message.role || "user",
            content: message.transcript || "",
          };
          transcriptMessages.push(transcriptEntry);
          setCallTranscript((prev) => [...prev, transcriptEntry]);
          console.log("📝 Transcript message collected:", transcriptEntry);
        }
      });

      vapi.on("call-end", () => {
        console.log("🔴 Call ended. Transcript length:", transcriptMessages.length);
        setCallTranscript([]);
        setCallStatus("idle");
        toast.info("Call ended");
      });

      vapi.on("error", (error: any) => {
        console.error("VAPI Error:", error);
        setCallStatus("idle");
        toast.error("Call failed. Please try again.");
      });

      // Start the call with the agent ID
      await vapi.start(data.agentId);
    } catch (error) {
      console.error("Error starting call:", error);
      setCallStatus("idle");
      toast.error("Failed to start call — missing agent or public key");
    }
  };

  const handleMuteToggle = () => {
    if (vapiInstance) {
      if (isMuted) {
        vapiInstance.setMuted(false);
        setIsMuted(false);
        toast.info("Microphone unmuted");
      } else {
        vapiInstance.setMuted(true);
        setIsMuted(true);
        toast.info("Microphone muted");
      }
    }
  };

  const handleEndCall = () => {
    if (vapiInstance) {
      vapiInstance.stop();
      setVapiInstance(null);
      // Status will be reset to "idle" by the call-end event
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="p-8 max-w-md text-center">
          <h2 className="text-xl font-bold text-foreground mb-2">Agent Not Found</h2>
          <p className="text-sm text-muted-foreground mb-4">This agent doesn't exist or is no longer available</p>
          {false ? (
            <Button
              onClick={() => {
                if (window.history.length > 1) {
                  navigate(-1);
                } else {
                  navigate("/dashboard");
                }
              }}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              {getBackLabel()}
            </Button>
          ) : (
            <Button onClick={() => navigate("/")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          )}
        </Card>
      </div>
    );
  }

  const agentConfig = agent.agent_config;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto p-4">
          <div className="flex items-start gap-4">
            {agent.logo_url && (
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-card shadow-md">
                  <img
                    src={agent.logo_url}
                    alt={`${agentConfig.name} logo`}
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            )}
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-foreground">{agentConfig.name || "Voice Agent"}</h1>
              {(agentConfig.personality || agent.brief) && (
                <p className="text-sm text-muted-foreground mt-2 italic">
                  {agentConfig.personality || agent.brief?.slice(0, 150) + "..."}
                </p>
              )}
              {agentConfig.sampleLine && (
                <div className="mt-3 pt-3 border-t border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Opener:</p>
                  <p className="text-sm text-foreground">"{agentConfig.sampleLine}"</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto p-6">
        <div className="space-y-6">
          {/* Call Interface */}
          <Card className="p-6 bg-card/80 backdrop-blur-sm border-border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Try the Agent</h3>
            <div className="space-y-4">
              <div className="text-center py-8">
                {agent.logo_url ? (
                  <div className="inline-flex p-2 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 mb-4">
                    <div className="w-24 h-24 rounded-xl overflow-hidden bg-card shadow-lg">
                      <img
                        src={agent.logo_url}
                        alt={`${agentConfig.name} logo`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="inline-flex p-4 rounded-full bg-gradient-to-br from-primary/10 to-accent/10 mb-4">
                    <Phone className="w-12 h-12 text-primary" />
                  </div>
                )}
              </div>

              {callStatus === "idle" ? (
                <Button
                  onClick={handleStartCall}
                  className="w-full gap-2 bg-gradient-to-r from-accent to-primary hover:shadow-lg transition-all h-14 text-base"
                >
                  <Phone className="w-5 h-5" />
                  Start Voice Call
                </Button>
              ) : (
                <div className="space-y-3">
                  <Card className="p-4 bg-secondary/30">
                    <div className="flex items-center justify-center gap-2">
                      <span className="text-sm font-medium">
                        {callStatus === "connecting" && "🎙️ Connecting..."}
                        {callStatus === "connected" && "🟢 Connected - Speak now"}
                        {callStatus === "ended" && "🔴 Call ended"}
                        {callStatus === "failed" && "⚠️ Failed to start call"}
                      </span>
                    </div>
                  </Card>

                  {callStatus === "connected" && (
                    <div className="flex gap-2">
                      <Button onClick={handleMuteToggle} variant="outline" className="flex-1 gap-2">
                        {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        {isMuted ? "Unmute" : "Mute"}
                      </Button>
                      <Button onClick={handleEndCall} variant="destructive" className="flex-1 gap-2">
                        <PhoneOff className="w-4 h-4" />
                        End Call
                      </Button>
                    </div>
                  )}
                </div>
              )}

              <p className="text-xs text-muted-foreground text-center">Views: {agent.views_count || 0}</p>
            </div>
          </Card>

          {/* Author Attribution */}
          <Card className="p-4 bg-card/80 backdrop-blur-sm border-border">
            <div className="text-center text-sm text-muted-foreground">
              Created by <span className="font-medium text-foreground">{agent.author_display_name || "Anonymous"}</span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SharedAgent;
