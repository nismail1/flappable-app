import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      throw new Error('VAPI_API_KEY not configured');
    }

    const { fileIds, kbName, kbDescription } = await req.json();

    if (!fileIds || !Array.isArray(fileIds) || fileIds.length === 0) {
      return new Response(
        JSON.stringify({ error: 'fileIds array is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`🔧 Creating Vapi query tool with ${fileIds.length} file(s)`);

    // Create Vapi query tool
    const toolPayload = {
      type: "query",
      function: {
        name: "search_knowledge_base",
        description: `Search through uploaded documents to answer user questions. Use this tool whenever users ask about information that might be in the uploaded files (${fileIds.length} file(s)). Call this tool with a clear search query based on the user's question.`,
        parameters: {
          type: "object",
          properties: {
            query: {
              type: "string",
              description: "A clear, specific search query to find relevant information in the uploaded documents. Rephrase the user's question as keywords or a focused question."
            }
          },
          required: ["query"]
        }
      },
      knowledgeBases: [
        {
          provider: "google",
          name: kbName || "uploaded-file-kb",
          description: kbDescription || "User-uploaded documents and information",
          fileIds: fileIds
        }
      ]
    };

    const vapiResponse = await fetch('https://api.vapi.ai/tool', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(toolPayload),
    });

    if (!vapiResponse.ok) {
      const errorText = await vapiResponse.text();
      console.error('❌ Vapi tool creation error:', errorText);
      throw new Error(`Vapi tool creation failed: ${vapiResponse.status} - ${errorText}`);
    }

    const vapiData = await vapiResponse.json();
    console.log('✅ Query tool created:', vapiData);

    return new Response(
      JSON.stringify({ 
        toolId: vapiData.id,
        toolData: vapiData
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in create-kb-tool:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
