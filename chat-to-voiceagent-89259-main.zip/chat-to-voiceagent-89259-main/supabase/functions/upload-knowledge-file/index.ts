import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const vapiApiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiApiKey) {
      throw new Error('VAPI_API_KEY not configured');
    }

    // Parse the multipart form data
    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return new Response(
        JSON.stringify({ error: 'No file provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📤 Uploading file to Vapi: ${file.name}, size: ${file.size}`);

    // Create a new FormData for Vapi
    const vapiFormData = new FormData();
    vapiFormData.append('file', file);

    // Upload to Vapi
    const vapiResponse = await fetch('https://api.vapi.ai/file', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${vapiApiKey}`,
      },
      body: vapiFormData,
    });

    if (!vapiResponse.ok) {
      const errorText = await vapiResponse.text();
      console.error('❌ Vapi upload error:', errorText);
      throw new Error(`Vapi upload failed: ${vapiResponse.status} - ${errorText}`);
    }

    const vapiData = await vapiResponse.json();
    console.log('✅ File uploaded to Vapi:', vapiData);

    return new Response(
      JSON.stringify({ 
        fileId: vapiData.id,
        fileName: file.name,
        fileSize: file.size
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ Error in upload-knowledge-file:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
