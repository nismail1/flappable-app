import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_FROM_NUMBER = '+14156505331';

serve(async (req) => {
  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get current time in Pacific Time
    const now = new Date();
    const pacificTime = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Los_Angeles',
      hour: '2-digit',
      hour12: false
    }).format(now);

    console.log(`🕐 Current Pacific Time hour: ${pacificTime}`);

    // Only run at 12 PM Pacific (noon)
    if (pacificTime !== '12') {
      console.log('⏰ Not 12 PM Pacific, skipping...');
      return new Response(JSON.stringify({ message: 'Not time to send yet' }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Get all agents with daily reminders enabled that haven't been sent today
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const { data: agents, error: agentsError } = await supabaseClient
      .from('voice_agent_versions')
      .select(`
        id,
        user_id,
        agent_config,
        daily_reminder_enabled,
        profiles!voice_agent_versions_user_id_fkey (
          phone_number,
          phone_verified
        )
      `)
      .eq('daily_reminder_enabled', true);

    if (agentsError) {
      console.error('❌ Error fetching agents:', agentsError);
      throw agentsError;
    }

    console.log(`📋 Found ${agents?.length || 0} agents with reminders enabled`);

    let sentCount = 0;

    for (const agent of agents || []) {
      const profile = agent.profiles as any;

      // Skip if user doesn't have verified phone
      if (!profile?.phone_number || !profile?.phone_verified) {
        console.log(`⏭️ Skipping agent ${agent.id} - phone not verified`);
        continue;
      }

      // Generate contextual message based on agent config
      let message = "Hey! Ready to pick up where you left off with your voice agent?";
      
      if (agent?.agent_config) {
        const agentName = agent.agent_config.name || 'your voice agent';
        const agentBrief = agent.agent_config.brief || '';
        
        // Customize message based on agent type/brief
        if (agentBrief.toLowerCase().includes('travel')) {
          message = `Hey! Ready to keep planning your trip with ${agentName}?`;
        } else if (agentBrief.toLowerCase().includes('gratitude')) {
          message = `Hey! Want to share something you're grateful for today?`;
        } else if (agentBrief.toLowerCase().includes('fitness') || agentBrief.toLowerCase().includes('workout')) {
          message = `Hey! Time to check in on your fitness goals with ${agentName}!`;
        } else if (agentBrief.toLowerCase().includes('learning') || agentBrief.toLowerCase().includes('study')) {
          message = `Hey! Ready for today's learning session with ${agentName}?`;
        } else {
          message = `Hey! Ready to continue with ${agentName}?`;
        }
      }

      // Send SMS via Twilio
      try {
        const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
        const twilioResponse = await fetch(twilioUrl, {
          method: 'POST',
          headers: {
            'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            To: profile.phone_number,
            From: TWILIO_FROM_NUMBER,
            Body: message,
          }),
        });

        if (!twilioResponse.ok) {
          const errorText = await twilioResponse.text();
          console.error(`❌ Twilio error for agent ${agent.id}:`, errorText);
          continue;
        }

        console.log(`✅ Sent reminder to ${profile.phone_number} for agent ${agent.id}`);
        sentCount++;

      } catch (error) {
        console.error(`❌ Error sending SMS for agent ${agent.id}:`, error);
      }
    }

    console.log(`✅ Invoked send-daily-reminders - sent ${sentCount} reminders`);

    return new Response(
      JSON.stringify({ success: true, sent: sentCount }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Error in send-daily-reminders:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
});
