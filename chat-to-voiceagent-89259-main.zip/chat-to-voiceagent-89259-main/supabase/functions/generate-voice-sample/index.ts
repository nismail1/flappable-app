import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { text, accent } = await req.json();
    const ELEVENLABS_API_KEY = Deno.env.get('ELEVENLABS_API_KEY');

    if (!ELEVENLABS_API_KEY) {
      throw new Error('ELEVENLABS_API_KEY is not configured');
    }

    // Map accent to ElevenLabs voice ID
    const voiceMap: Record<string, string> = {
      'en-US (neutral)': '9BWtsMINqrJLrRacOk9x', // Aria
      'en-US (Midwest)': 'EXAVITQu4vr4xnSDxMaL', // Sarah
      'en-GB (British)': 'CwhRBWXzGAHq8TQ4Fs17', // Roger
      'en-AU (Australian)': 'IKne3meq5aSn9XLyUdCD', // Charlie
      // Legacy mappings
      'neutral (en-US)': '9BWtsMINqrJLrRacOk9x',
      'light Midwest (en-US)': 'EXAVITQu4vr4xnSDxMaL',
      'British (en-GB)': 'CwhRBWXzGAHq8TQ4Fs17',
    };
    
    const selectedVoice = voiceMap[accent] || voiceMap['en-US (neutral)'];

    console.log('Generating voice sample:', { text, accent, selectedVoice });

    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${selectedVoice}/stream`,
      {
        method: 'POST',
        headers: {
          'xi-api-key': ELEVENLABS_API_KEY,
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_multilingual_v2',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
          }
        }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error('ElevenLabs API error:', response.status, errorText);
      
      let userMessage = 'Voice sample generation failed';
      if (response.status === 401 || response.status === 403) {
        userMessage = 'Invalid or expired API key — check your ElevenLabs API key.';
      } else if (response.status === 429) {
        userMessage = 'Rate limit reached — please wait a few seconds.';
      } else if (response.status >= 500) {
        userMessage = 'Service temporarily unavailable — try again later.';
      }
      
      return new Response(JSON.stringify({ 
        error: userMessage,
        statusCode: response.status 
      }), {
        status: response.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const audioBuffer = await response.arrayBuffer();
    const base64Audio = btoa(
      String.fromCharCode(...new Uint8Array(audioBuffer))
    );

    return new Response(JSON.stringify({ 
      audioContent: base64Audio 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error generating voice sample:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error',
      statusCode: 500
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
