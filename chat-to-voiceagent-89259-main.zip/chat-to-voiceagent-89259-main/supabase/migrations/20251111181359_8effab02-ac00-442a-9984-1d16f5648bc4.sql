-- Add reminder_time_local column to voice_agent_versions if it doesn't exist
ALTER TABLE voice_agent_versions 
ADD COLUMN IF NOT EXISTS reminder_time_local TEXT NOT NULL DEFAULT '12:00 PM PT';