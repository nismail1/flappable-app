import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, Share2 } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface BriefDisplayProps {
  brief: string;
  version: string;
  onDownload?: () => void;
  onShare?: () => void;
}

export const BriefDisplay = ({ brief, version, onDownload, onShare }: BriefDisplayProps) => {
  return (
    <Card className="p-6 bg-card border-2 border-primary/20">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-bold">Build Brief</h3>
            <Badge variant="outline">{version}</Badge>
          </div>
          <div className="flex gap-2">
            <Button onClick={onDownload} variant="outline" size="sm" className="gap-2">
              <Download className="w-4 h-4" />
              Download
            </Button>
            <Button onClick={onShare} variant="outline" size="sm" className="gap-2">
              <Share2 className="w-4 h-4" />
              Share to Slack
            </Button>
          </div>
        </div>

        {/* Brief Content */}
        <ScrollArea className="h-[500px] w-full rounded-lg border border-border bg-secondary/30 p-4">
          <div className="prose prose-sm max-w-none">
            <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed text-foreground">
              {brief}
            </pre>
          </div>
        </ScrollArea>

        {/* Confidence Legend */}
        <div className="flex gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <Badge className="bg-green-500/20 text-green-700 dark:text-green-400">High</Badge>
            <span className="text-muted-foreground">Clear requirements</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Badge className="bg-yellow-500/20 text-yellow-700 dark:text-yellow-400">Med</Badge>
            <span className="text-muted-foreground">Some assumptions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Badge className="bg-red-500/20 text-red-700 dark:text-red-400">Low</Badge>
            <span className="text-muted-foreground">Needs clarification</span>
          </div>
        </div>
      </div>
    </Card>
  );
};
