import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_FROM_NUMBER = '+14156505331';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    // For trial mode users, allow the request but skip SMS sending
    const isAuthenticated = !authError && user;

    const { agent_id, summary } = await req.json();
    
    // Trial mode users: return success without sending SMS
    if (!isAuthenticated) {
      console.log('ℹ️ Trial mode user - skipping SMS summary');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Summary generated (SMS not available in trial mode)' 
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!agent_id || !summary) {
      return new Response(
        JSON.stringify({ error: 'Missing agent_id or summary' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get agent settings
    const { data: agentData, error: agentError } = await supabaseClient
      .from('voice_agent_versions')
      .select('agent_config, post_call_summary_enabled, user_id')
      .eq('id', agent_id)
      .single();

    if (agentError || !agentData) {
      console.error('❌ Error fetching agent:', agentError);
      return new Response(
        JSON.stringify({ error: 'Agent not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if summaries are enabled for this agent
    if (!agentData.post_call_summary_enabled) {
      console.log('ℹ️ Post-call summaries not enabled for this agent');
      return new Response(
        JSON.stringify({ success: false, message: 'Summaries not enabled for this agent' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get user profile with phone info
    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('phone_number, phone_verified')
      .eq('id', agentData.user_id)
      .single();

    if (profileError || !profile) {
      console.error('❌ Error fetching profile:', profileError);
      return new Response(
        JSON.stringify({ error: 'Profile not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user has verified phone
    if (!profile.phone_number || !profile.phone_verified) {
      console.log('ℹ️ User does not have a verified phone number');
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'No verified phone number',
          should_prompt: true 
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const agentName = agentData?.agent_config?.name || 'your voice agent';

    // Send SMS via Twilio
    const message = `Here's your quick recap with ${agentName}: ${summary}`;

    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
    const twilioResponse = await fetch(twilioUrl, {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        To: profile.phone_number,
        From: TWILIO_FROM_NUMBER,
        Body: message,
      }),
    });

    if (!twilioResponse.ok) {
      const errorText = await twilioResponse.text();
      console.error('❌ Twilio error:', errorText);
      throw new Error('Failed to send SMS');
    }

    console.log(`✅ Sent summary text to ${profile.phone_number}`);

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Error in send-summary-text:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
