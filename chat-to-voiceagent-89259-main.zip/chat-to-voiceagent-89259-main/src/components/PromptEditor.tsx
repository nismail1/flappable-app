import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";

interface PromptEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentPrompt: string;
  onSave: (newPrompt: string) => Promise<void>;
  isLoading?: boolean;
}

export const PromptEditor = ({
  open,
  onOpenChange,
  currentPrompt,
  onSave,
  isLoading = false,
}: PromptEditorProps) => {
  const [editedPrompt, setEditedPrompt] = useState(currentPrompt);

  const handleSave = async () => {
    await onSave(editedPrompt);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Edit System Prompt</DialogTitle>
          <DialogDescription>
            Modify the system prompt that controls your agent's behavior and personality.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-auto">
          <Textarea
            value={editedPrompt}
            onChange={(e) => setEditedPrompt(e.target.value)}
            className="min-h-[400px] font-mono text-sm"
            placeholder="Enter your system prompt here..."
          />
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={isLoading || editedPrompt === currentPrompt}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              "Save & Redeploy"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
