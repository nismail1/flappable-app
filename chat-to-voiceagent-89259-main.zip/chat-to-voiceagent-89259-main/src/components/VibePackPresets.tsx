import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Heart, Zap, Briefcase, Users, Sparkles } from "lucide-react";

interface VibePack {
  id: string;
  name: string;
  icon: React.ElementType;
  tone: string;
  accent: string;
  warmth: number;
  creativity: number;
  latency: string;
  consent: string;
  sample: string;
  gradient: string;
}

interface VibePackPresetsProps {
  onSelect: (pack: VibePack) => void;
}

export const VibePackPresets = ({ onSelect }: VibePackPresetsProps) => {
  const packs: VibePack[] = [
    {
      id: "therapist-calm",
      name: "Therapist-Calm",
      icon: Heart,
      tone: "warm, empathetic, gentle",
      accent: "en-US neutral",
      warmth: 85,
      creativity: 60,
      latency: "Slow (reflective pacing)",
      consent: "Strict",
      sample: "If you'd like, we can take a minute to name one thing that felt okay today.",
      gradient: "from-blue-500 to-purple-500",
    },
    {
      id: "coach-energetic",
      name: "Coach-Energetic",
      icon: Zap,
      tone: "upbeat, motivating, friendly",
      accent: "en-US neutral",
      warmth: 75,
      creativity: 65,
      latency: "Fast (quick, energetic)",
      consent: "Gentle",
      sample: "Quick win time—what's one thing you're proud of today?",
      gradient: "from-orange-500 to-red-500",
    },
    {
      id: "concierge-polished",
      name: "Concierge-Polished",
      icon: Briefcase,
      tone: "professional, concise, reassuring",
      accent: "en-GB (RP)",
      warmth: 65,
      creativity: 50,
      latency: "Natural (balanced pacing)",
      consent: "Gentle",
      sample: "Good afternoon. May I assist with today's plans or a brief check-in?",
      gradient: "from-slate-600 to-slate-800",
    },
    {
      id: "friend-casual",
      name: "Friend-Casual",
      icon: Users,
      tone: "relaxed, playful, kind",
      accent: "en-US West",
      warmth: 80,
      creativity: 70,
      latency: "Natural (balanced pacing)",
      consent: "Auto-proceed",
      sample: "Hey! Want to share one small good thing from your day?",
      gradient: "from-green-400 to-cyan-500",
    },
    {
      id: "guide-mindful",
      name: "Guide-Mindful",
      icon: Sparkles,
      tone: "reflective, spacious, encouraging",
      accent: "en-US Midwest",
      warmth: 90,
      creativity: 55,
      latency: "Slow (reflective pacing)",
      consent: "Gentle",
      sample: "Let's pause for a breath. What felt nourishing today?",
      gradient: "from-purple-400 to-pink-500",
    },
  ];

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold text-muted-foreground px-1">Preset Vibe Packs</h3>
      <ScrollArea className="w-full">
        <div className="flex gap-4 pb-4">
          {packs.map((pack) => {
            const Icon = pack.icon;
            return (
              <Card
                key={pack.id}
                onClick={() => onSelect(pack)}
                className="flex-shrink-0 w-64 p-4 cursor-pointer hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-br from-card to-secondary border-2 border-transparent hover:border-primary/30"
              >
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className={`p-2 rounded-lg bg-gradient-to-br ${pack.gradient}`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <h4 className="font-semibold text-sm">{pack.name}</h4>
                  </div>
                  
                  <div className="space-y-1.5 text-xs">
                    <div>
                      <span className="text-muted-foreground">Tone:</span>{" "}
                      <span className="font-medium">{pack.tone}</span>
                    </div>
                    <div className="flex gap-4">
                      <div>
                        <span className="text-muted-foreground">Warmth:</span>{" "}
                        <Badge variant="secondary" className="text-xs">{pack.warmth}/100</Badge>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Creative:</span>{" "}
                        <Badge variant="secondary" className="text-xs">{pack.creativity}/100</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-xs italic text-muted-foreground line-clamp-2">"{pack.sample}"</p>
                </div>
              </Card>
            );
          })}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
};
