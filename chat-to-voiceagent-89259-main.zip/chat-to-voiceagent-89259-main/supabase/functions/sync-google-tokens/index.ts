import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    console.log(`🔍 Syncing Google tokens for user: ${user.id}`);

    // Parse request body to get tokens from frontend
    const { access_token, refresh_token } = await req.json();

    if (!access_token || !refresh_token) {
      return new Response(
        JSON.stringify({ error: 'Missing access_token or refresh_token in request body' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Received tokens from frontend');

    // Use Admin API to store tokens
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Store tokens in user_google_tokens table
    const { error: upsertError } = await supabaseAdmin
      .from('user_google_tokens')
      .upsert({
        user_id: user.id,
        access_token,
        refresh_token,
        token_expiry: new Date(Date.now() + 3600 * 1000).toISOString(),
        updated_at: new Date().toISOString(),
      });

    if (upsertError) {
      console.error('Failed to store tokens:', upsertError);
      throw new Error('Failed to store tokens');
    }

    // Update profile to mark calendar as connected
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .update({ google_calendar_connected: true })
      .eq('id', user.id);

    if (profileError) {
      console.error('Failed to update profile:', profileError);
    }

    console.log('✅ Google tokens stored successfully');

    return new Response(
      JSON.stringify({ success: true, message: 'Google tokens synced successfully' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in sync-google-tokens:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
