-- Add voice_provider column to voice_agent_versions table
ALTER TABLE voice_agent_versions 
ADD COLUMN IF NOT EXISTS voice_provider TEXT;