import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { supabaseFrom } from "@/lib/supabase-helper";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Search, Plus, Edit, Copy, LogOut, Calendar, Settings as SettingsIcon, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import type { User, Session } from "@supabase/supabase-js";
import { format } from "date-fns";
import { useNavigation } from "@/contexts/NavigationContext";

interface VoiceAgent {
  id: string;
  version: string;
  created_at: string;
  agent_config: any;
  voice_name: string | null;
  voice_id: string | null;
  prompt: string | null;
  vapi_agent_id: string | null;
  user_id: string;
  logo_url: string | null;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { getBackLabel, shouldShowBack } = useNavigation();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [agents, setAgents] = useState<VoiceAgent[]>([]);
  const [filteredAgents, setFilteredAgents] = useState<VoiceAgent[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session?.user) {
        navigate("/auth");
      }
    });

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (!session?.user) {
        navigate("/auth");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (user) {
      fetchAgents();
    }
  }, [user]);

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredAgents(agents);
    } else {
      const query = searchQuery.toLowerCase();
      setFilteredAgents(
        agents.filter(agent => {
          const name = agent.agent_config?.name?.toLowerCase() || "";
          const version = agent.version.toLowerCase();
          const tone = agent.agent_config?.tone?.toLowerCase() || "";
          return name.includes(query) || version.includes(query) || tone.includes(query);
        })
      );
    }
  }, [searchQuery, agents]);

  const fetchAgents = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabaseFrom("voice_agent_versions")
        .select("*")
        .eq("user_id", user?.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setAgents((data as any[]) || []);
      setFilteredAgents((data as any[]) || []);
    } catch (error) {
      console.error("Error fetching agents:", error);
      toast.error("Failed to load your agents");
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/auth");
    toast.success("Signed out successfully");
  };

  const handleContinueEditing = (agent: VoiceAgent) => {
    navigate("/", { state: { agentData: agent } });
  };

  const handleDuplicateAgent = async (agent: VoiceAgent) => {
    try {
      const config = agent.agent_config || {};
      const originalName = config.name || agent.voice_name || "Untitled Agent";
      const newName = `${originalName} (Copy)`;

      const { error } = await supabaseFrom("voice_agent_versions")
        .insert({
          user_id: user?.id,
          version: `${agent.version} (Copy)`,
          agent_config: {
            ...config,
            name: newName,
          },
          prompt: agent.prompt,
          voice_name: newName,
          logo_url: agent.logo_url,
        });

      if (error) throw error;
      toast.success("Agent duplicated successfully!");
      fetchAgents();
    } catch (error) {
      console.error("Error duplicating agent:", error);
      toast.error("Failed to duplicate agent");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/favicon.png" alt="Flappable" className="w-8 h-8" />
            <div>
              <h1 className="text-lg font-bold text-foreground">Flappable</h1>
              <p className="text-xs text-muted-foreground">Build AI voice agents in minutes</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {false && (
              <Button
                onClick={() => {
                  if (window.history.length > 1) {
                    navigate(-1);
                  } else {
                    navigate("/dashboard");
                  }
                }}
                variant="ghost"
                size="sm"
                className="gap-2 hover:bg-accent/50 transition-all duration-300"
              >
                <ArrowLeft className="w-4 h-4" />
                {getBackLabel()}
              </Button>
            )}
            <Button
              onClick={() => navigate("/")}
              variant="default"
              size="sm"
              className="gap-2 bg-[hsl(270,100%,65%)] hover:bg-[hsl(270,100%,60%)]"
            >
              <Plus className="w-4 h-4" />
              New Agent
            </Button>
            <Button
              onClick={() => navigate("/settings")}
              variant="ghost"
              size="sm"
              className="gap-2"
            >
              <SettingsIcon className="w-4 h-4" />
              Settings
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        <h2 className="text-2xl font-bold text-foreground mb-6">Dashboard</h2>
        
        {/* Search Bar */}
        <div className="mb-8 max-w-2xl mx-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search agents by name, version, or tone..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Agents Grid */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center space-y-4">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="text-muted-foreground">Loading your agents...</p>
            </div>
          </div>
        ) : filteredAgents.length === 0 ? (
          <Card className="max-w-2xl mx-auto p-12 bg-card/60 border border-border rounded-2xl shadow-lg">
            <div className="text-center space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 inline-block">
                <Sparkles className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {searchQuery ? "No agents found" : "You haven't built any agents yet!"}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {searchQuery 
                    ? "Try a different search term" 
                    : "Create your first voice agent to get started"}
                </p>
                {!searchQuery && (
                  <Button
                    onClick={() => navigate("/")}
                    className="gap-2 bg-gradient-to-r from-primary to-accent shadow-sm hover:shadow-md"
                  >
                    <Plus className="w-4 h-4" />
                    Create Your First Agent
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAgents.map((agent) => (
              <Card 
                key={agent.id} 
                className="group hover:shadow-xl transition-all duration-300 overflow-hidden border border-border bg-card/60 rounded-2xl shadow-md"
              >
                <CardHeader className="bg-gradient-to-br from-muted/30 to-muted/10">
                  <div className="flex items-start justify-between gap-3">
                    {agent.logo_url && (
                      <div className="flex-shrink-0">
                        <div className="w-14 h-14 rounded-lg overflow-hidden bg-card shadow-md">
                          <img 
                            src={agent.logo_url} 
                            alt={`${agent.agent_config?.name} logo`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg truncate">
                        {agent.agent_config?.name || "Untitled Agent"}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-1">
                        <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
                          {agent.version}
                        </span>
                        {agent.voice_name && (
                          <span className="text-xs text-muted-foreground">
                            {agent.voice_name}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pt-4 space-y-4">
                  {/* Agent Details */}
                  <div className="space-y-2 text-sm">
                    {agent.agent_config?.tone && (
                      <div>
                        <span className="text-muted-foreground">Tone:</span>{" "}
                        <span className="text-foreground">
                          {Array.isArray(agent.agent_config.tone) 
                            ? agent.agent_config.tone.join(', ') 
                            : agent.agent_config.tone}
                        </span>
                      </div>
                    )}
                    {agent.agent_config?.accent && (
                      <div>
                        <span className="text-muted-foreground">Accent:</span>{" "}
                        <span className="text-foreground">{agent.agent_config.accent}</span>
                      </div>
                    )}
                    {agent.agent_config?.sampleLine && (
                      <div className="pt-2 border-t border-border">
                        <p className="text-xs text-muted-foreground mb-1">Sample Line:</p>
                        <p className="text-sm italic text-foreground line-clamp-2">
                          "{agent.agent_config.sampleLine}"
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Created Date */}
                  <div className="flex items-center gap-1 text-xs text-muted-foreground pt-2 border-t border-border">
                    <Calendar className="w-3 h-3" />
                    <span>Created {format(new Date(agent.created_at), "MMM d, yyyy")}</span>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      onClick={() => handleContinueEditing(agent)}
                      variant="default"
                      size="sm"
                      className="flex-1 gap-1"
                    >
                      <Edit className="w-3 h-3" />
                      Continue
                    </Button>
                    <Button
                      onClick={() => handleDuplicateAgent(agent)}
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      Duplicate
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
