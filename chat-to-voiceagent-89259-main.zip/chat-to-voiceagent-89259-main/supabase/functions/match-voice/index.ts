import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Voice database from "Voice Descriptions.pdf"
const VOICE_DATABASE = [
  { name: "Hana", voiceId: "hana", gender: "female", age: "young", accent: "neutral", tone: "warm friendly energetic", description: "Young, warm, friendly female voice with energetic tone" },
  { name: "Lily", voiceId: "lily", gender: "female", age: "middle", accent: "british", tone: "professional elegant", description: "Professional British female voice with elegant delivery" },
  { name: "Rachel", voiceId: "rachel", gender: "female", age: "middle", accent: "american", tone: "neutral professional", description: "Clear American female voice, professional and neutral" },
  { name: "Sarah", voiceId: "sarah", gender: "female", age: "young", accent: "american", tone: "friendly conversational", description: "Young American female, friendly and conversational" },
  { name: "Charlotte", voiceId: "charlotte", gender: "female", age: "young", accent: "southern", tone: "warm Southern charming", description: "Young Southern female voice, warm and charming" },
  { name: "Jessica", voiceId: "jessica", gender: "female", age: "middle", accent: "american", tone: "confident professional", description: "Confident American female voice, professional tone" },
  { name: "Alice", voiceId: "alice", gender: "female", age: "young", accent: "british", tone: "playful cheerful", description: "Young British female, playful and cheerful" },
  { name: "Matilda", voiceId: "matilda", gender: "female", age: "middle", accent: "british", tone: "sophisticated elegant", description: "Sophisticated British female voice with elegant tone" },
  { name: "Laura", voiceId: "laura", gender: "female", age: "young", accent: "american", tone: "energetic enthusiastic", description: "Energetic young American female, enthusiastic delivery" },
  { name: "Aria", voiceId: "aria", gender: "female", age: "young", accent: "neutral", tone: "gentle soothing", description: "Gentle young female voice, soothing and calm" },
  { name: "George", voiceId: "george", gender: "male", age: "middle", accent: "british", tone: "authoritative confident", description: "Authoritative British male voice, confident delivery" },
  { name: "Callum", voiceId: "callum", gender: "male", age: "young", accent: "british", tone: "friendly approachable", description: "Young British male, friendly and approachable" },
  { name: "Liam", voiceId: "liam", gender: "male", age: "young", accent: "american", tone: "casual relaxed", description: "Young American male, casual and relaxed tone" },
  { name: "Charlie", voiceId: "charlie", gender: "male", age: "middle", accent: "australian", tone: "warm conversational", description: "Australian male voice, warm and conversational" },
  { name: "Daniel", voiceId: "daniel", gender: "male", age: "middle", accent: "british", tone: "professional articulate", description: "Professional British male, clear and articulate" },
  { name: "Brian", voiceId: "brian", gender: "male", age: "middle", accent: "american", tone: "deep authoritative", description: "Deep American male voice, authoritative tone" },
  { name: "Eric", voiceId: "eric", gender: "male", age: "middle", accent: "american", tone: "friendly informative", description: "Friendly American male, informative delivery" },
  { name: "Chris", voiceId: "chris", gender: "male", age: "young", accent: "american", tone: "energetic upbeat", description: "Young American male, energetic and upbeat" },
  { name: "Bill", voiceId: "bill", gender: "male", age: "older", accent: "american", tone: "wise experienced", description: "Older American male, wise and experienced tone" },
  { name: "Will", voiceId: "will", gender: "male", age: "young", accent: "british", tone: "articulate intelligent", description: "Young British male, articulate and intelligent" },
  { name: "River", voiceId: "river", gender: "neutral", age: "young", accent: "neutral", tone: "calm balanced", description: "Gender-neutral voice, calm and balanced" },
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userRequest } = await req.json();
    
    if (!userRequest || typeof userRequest !== 'string') {
      throw new Error("userRequest is required and must be a string");
    }

    console.log("🎤 Matching voice for request:", userRequest);

    const requestLower = userRequest.toLowerCase();
    
    // Simple scoring system for fuzzy matching
    const scoredVoices = VOICE_DATABASE.map(voice => {
      let score = 0;
      
      // Exact name match gets highest priority
      if (requestLower.includes(voice.name.toLowerCase())) {
        score += 100;
      }
      
      // Gender matching
      if (requestLower.includes(voice.gender)) {
        score += 30;
      }
      
      // Age matching
      if (requestLower.includes(voice.age)) {
        score += 20;
      }
      
      // Accent matching
      if (requestLower.includes(voice.accent)) {
        score += 25;
      }
      
      // Tone matching (split tone into keywords and check each)
      const toneKeywords = voice.tone.split(' ');
      toneKeywords.forEach(keyword => {
        if (requestLower.includes(keyword)) {
          score += 15;
        }
      });
      
      // Description matching
      const descWords = voice.description.toLowerCase().split(' ');
      descWords.forEach(word => {
        if (word.length > 3 && requestLower.includes(word)) {
          score += 5;
        }
      });
      
      return { ...voice, score };
    });

    // Sort by score and get best match
    scoredVoices.sort((a, b) => b.score - a.score);
    const bestMatch = scoredVoices[0];
    
    // Calculate confidence (normalize score to 0-1)
    const maxPossibleScore = 100;
    const confidence = Math.min(bestMatch.score / maxPossibleScore, 1);

    console.log("✅ Best match:", bestMatch.name, "with score", bestMatch.score);

    return new Response(
      JSON.stringify({
        matched_voice_name: bestMatch.name,
        voice_id: bestMatch.voiceId,
        confidence: confidence,
        description: bestMatch.description,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error matching voice:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
