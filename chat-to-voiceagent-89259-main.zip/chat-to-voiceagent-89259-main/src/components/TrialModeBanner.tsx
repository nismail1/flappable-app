import { useState } from "react";
import { AlertCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TrialModeBannerProps {
  onCreateAccount: () => void;
}

export const TrialModeBanner = ({ onCreateAccount }: TrialModeBannerProps) => {
  const [dismissed, setDismissed] = useState(false);
  
  if (dismissed) return null;
  
  return (
    <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-3 flex items-center justify-between shadow-md">
      <div className="flex items-center gap-2">
        <AlertCircle className="h-5 w-5 flex-shrink-0" />
        <span className="font-medium text-sm">
          You're in trial mode. Your agent won't be saved permanently.
        </span>
      </div>
      <div className="flex items-center gap-3">
        <Button 
          variant="secondary" 
          size="sm"
          onClick={onCreateAccount}
          className="bg-white text-orange-600 hover:bg-gray-100 font-semibold"
        >
          Create Free Account
        </Button>
        <button 
          onClick={() => setDismissed(true)}
          className="hover:bg-white/20 rounded p-1 transition-colors"
          aria-label="Dismiss"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};
